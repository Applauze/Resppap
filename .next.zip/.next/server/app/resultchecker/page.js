(() => {
var exports = {};
exports.id = 6600;
exports.ids = [6600];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 62150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'resultchecker',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71423)), "C:\\wamp64\\www\\next-app\\app\\resultchecker\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\resultchecker\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/resultchecker/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/resultchecker/page",
        pathname: "/resultchecker",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 28350:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61470))

/***/ }),

/***/ 61470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Store_permission_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57948);
/* harmony import */ var _SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29332);
/* harmony import */ var _SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(42634);
/* harmony import */ var _SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55607);
/* harmony import */ var _Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(56801);
/* harmony import */ var _ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24606);
/* harmony import */ var _ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(71348);
/* harmony import */ var _ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var qrcode_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(27425);
/* harmony import */ var qrcode_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(qrcode_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_to_pdf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41334);
/* harmony import */ var react_to_pdf__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_to_pdf__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var html2pdf_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(92195);
/* harmony import */ var html2pdf_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(html2pdf_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _Images_MaleDummy_jpg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86955);
/* harmony import */ var _Images_FemaleDummy_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1241);
/* harmony import */ var _bootstrap_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(50488);
/* harmony import */ var _bootstrap_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_bootstrap_css__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(44906);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(57237);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(11589);
/* harmony import */ var react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _API_Call_axioscall__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(69294);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(41315);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2129);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(32182);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _Images_schoollogo_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(86544);
/* harmony import */ var _Inputs_FormInputPassword__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(31160);
/* harmony import */ var _Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(73446);
/* __next_internal_client_entry_do_not_use__ default auto */ 































const ResultCheckerComponent = ()=>{
    const [session, setsession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [claz, setclaz] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [term, setterm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [showProcessing, setshowProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [Message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [QRCodeString, setQRCodeString] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [activateSelector, setactivateSelector] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [activateButton, setactivateButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [displayStudents, setdisplayStudents] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [nexttermbegins, setnexttermbegins] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [schoolopens, setschoolopens] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [ePIN, setePIN] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [AllStudents, setAllStudents] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedStudentDetails, setRetrievedStudentDetails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedSubjects, setRetrievedSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedAttributes1, setRetrievedAttributes1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedAttributes2, setRetrievedAttributes2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedAttributes3, setRetrievedAttributes3] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ct_remark, setct_remark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [p_remark, setp_remark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [StdID, setStdID] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [st_id, setst_id] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [ToggleButton, setToggleButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [p_attendance, setp_attendance] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_22___default())();
    const [DisplayCardPanel, setDisplayCardPanel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [DisplayMainCard, setDisplayMainCard] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [displayResult, setdisplayResult] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [Fullname, setFullname] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [DisplayMode, setDisplayMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Print");
    const targetRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const buttonCss = {
        width: "100%"
    };
    const PCtx = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_Store_permission_context__WEBPACK_IMPORTED_MODULE_2__["default"]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setDisplayCardPanel(false);
    }, [
        session,
        claz,
        term,
        ePIN,
        StdID
    ]);
    const GetTheResult = async (e)=>{
        e.preventDefault();
        if (term != "Select" && session != "Select" && claz != "Select" && ePIN != "" && StdID != "") {
            var CryptoJS = __webpack_require__(87683);
            let PIN = "Applause143";
            console.log(PIN);
            let aPIN = CryptoJS.AES.encrypt(ePIN, PIN).toString();
            let CheckerInfo = {
                Session: session,
                Term: term,
                Claz: claz,
                EPIN: aPIN,
                SID: StdID
            };
            let ThisDetails = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z)("get_result_checker_info", CheckerInfo);
            // console.log(ThisDetails);
            if (ThisDetails != "Error") {
                ThisDetails = JSON.parse(ThisDetails);
                if (ThisDetails.responder) {
                    GetThisStudentReport(ThisDetails.StudentDetails);
                } else {
                    (0,_Notification__WEBPACK_IMPORTED_MODULE_15__/* .DisplayNotification */ .g)("Error", `The information supplied are incorrect. Please check and try again`, "danger", "top-center", 5000);
                }
            } else {
                (0,_Notification__WEBPACK_IMPORTED_MODULE_15__/* .DisplayNotification */ .g)("Error", `The information supplied are incorrect. Please check and try again`, "danger", "top-center", 5000);
            }
        } else {
            (0,_Notification__WEBPACK_IMPORTED_MODULE_15__/* .DisplayNotification */ .g)("Error", `All information must be submitted. Kindly check for the missing information`, "danger", "top-center", 5000);
        }
    };
    const GetThisStudentReport = async (element)=>{
        setDisplayCardPanel(false);
        setMessage(`The system is retrieving  ${element.Fullname}'s report`);
        setQRCodeString(`${element.Fullname} + ${session} Session + ${term} Term + ${claz}`);
        setshowProcessing(true);
        setDisplayMainCard(false);
        let ThisStudentParam = {
            student_id: StdID,
            Session: session,
            Term: term,
            Claz: claz
        };
        setst_id(element.student_id);
        let ThisStudentReportInJson = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z)("load_this_student_report", ThisStudentParam);
        // console.log(ThisStudentReportInJson);
        ThisStudentReportInJson = JSON.parse(ThisStudentReportInJson);
        ThisStudentParam = {
            ...ThisStudentParam,
            dob: element.dob,
            sex: element.sex,
            subjectsoffered: ThisStudentReportInJson.ThisStudentScores,
            alltheattributes: ThisStudentReportInJson.ThisStudentAttributes,
            allthecomments: ThisStudentReportInJson.ThisStudentComments,
            termproperties: ThisStudentReportInJson.ThisTermProperties,
            nic: element.nic,
            Fullname: element.Fullname,
            PixUrl: element.pixurl
        };
        setFullname(element.Fullname);
        let PsychoAttributes = ThisStudentReportInJson.ThisStudentAttributes;
        let AllComments = ThisStudentReportInJson.ThisStudentComments;
        let AllTermProp = ThisStudentReportInJson.ThisTermProperties;
        let n = Math.ceil(PsychoAttributes.length / 3) + 1;
        setRetrievedStudentDetails(ThisStudentParam);
        setRetrievedSubjects(ThisStudentReportInJson.ThisStudentScores);
        setRetrievedAttributes1(PsychoAttributes.slice(0, n));
        setRetrievedAttributes2(PsychoAttributes.slice(n, 2 * n));
        setRetrievedAttributes3(PsychoAttributes.slice(2 * n));
        setDisplayMainCard(true);
        setshowProcessing(false);
        setct_remark(AllComments[0][`${term}_term_ctc`] ? AllComments[0][`${term}_term_ctc`] : "");
        setp_remark(AllComments[0][`${term}_term_pc`] ? AllComments[0][`${term}_term_pc`] : "");
        setp_attendance(AllComments[0][`${term}_term_attendance`] ? AllComments[0][`${term}_term_attendance`] : "");
        if (AllTermProp.length > 0) {
            setnexttermbegins(AllTermProp[0]["Resumption"]);
            setschoolopens(AllTermProp[0]["SchoolOpens"]);
        }
        setDisplayCardPanel(true);
    // setRetrievedComments(ThisStudentReportInJson.ThisStudentComments);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (DisplayMode === "PDF") {
            // generatePDF(targetRef, {
            const element = document.getElementById("element-to-print");
            html2pdf_js__WEBPACK_IMPORTED_MODULE_10___default()(element, {
                margin: 0,
                filename: "myfile.pdf",
                image: {
                    type: "jpeg",
                    quality: 1
                },
                html2canvas: {
                    scale: 1
                },
                jsPDF: {
                    unit: "in",
                    format: "a4",
                    orientation: "portrait"
                }
            });
            setDisplayMode("Print");
        }
    }, [
        DisplayMode
    ]);
    const GenerateThePdf = ()=>{
        setDisplayMode("PDF");
    };
    const GetTheStudents = async (e)=>{
        e.preventDefault();
        setMessage(`The system is retrieving the students in ${claz}`);
        setshowProcessing(true);
        let TeacherID = cookies.get("this_staff");
        let Category = cookies.get("this_category");
        let ReportsParam = {
            Session: session,
            Term: term,
            Claz: claz,
            TeacherID: TeacherID ? TeacherID : "Nothing",
            Category: Category ? Category : "Nothing"
        };
        let StudentsInJson = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z)("load_students_for_reports", ReportsParam);
        if (!StudentsInJson.includes("Not Authorized")) {
            if (!StudentsInJson.includes("Error")) {
                StudentsInJson = JSON.parse(StudentsInJson);
                let AllStds = [];
                let NIC = StudentsInJson.AllStudents.length;
                StudentsInJson.AllStudents.forEach((element)=>{
                    AllStds = [
                        ...AllStds,
                        {
                            Fullname: `${element.surname} ${element.firstname} ${element.middlename}`,
                            student_id: element.student_id,
                            dob: element.dob,
                            sex: element.sex,
                            nic: NIC,
                            pixurl: element.picture_directory
                        }
                    ];
                });
                setAllStudents(AllStds);
            } else {
                (0,_Notification__WEBPACK_IMPORTED_MODULE_15__/* .DisplayNotification */ .g)("Error", `No student has been registered in this class`, "danger", "top-center", 5000);
            }
        } else {
            (0,_Notification__WEBPACK_IMPORTED_MODULE_15__/* .DisplayNotification */ .g)("Error", `You are not an authorized teacher for the selected class. Please contact the Administrator`, "danger", "top-center", 7000);
        }
        setshowProcessing(false);
    };
    const StudentDescription = (LABEL, value, colsp)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
            md: colsp,
            lg: colsp,
            xs: 11,
            sm: 11,
            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().DetailsCol),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "small py-0 my-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().mylabel),
                        children: LABEL
                    }),
                    ":",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: LABEL === "NAME" ? (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().myvalueName) : (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().myvalue),
                        children: value
                    })
                ]
            })
        });
    };
    const RotatedHeading = (tam, ThirdText, OtherText)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
            className: DisplayMode === "Print" ? `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().RotatedHeading)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}` : `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().RotatedHeading2)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
            children: tam === "Third" ? ThirdText : OtherText
        });
    };
    const StudentAttributes = (n, ATT, RIndx)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().AttributeRow),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: `py-1 ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)}`,
                    children: ATT[`${term}_term_attribute`]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: `py-0 text-center text-bg ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)}`,
                    children: ATT[`${term}_term_value`]
                })
            ]
        }, RIndx);
    };
    const InfoTable = (left, right)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().InfoTableLeft),
                    children: left
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().InfoTableRight),
                    children: right
                })
            ]
        });
    };
    const PrintTheReport = async ()=>{
        window.print();
        (0,_Notification__WEBPACK_IMPORTED_MODULE_15__/* .DisplayNotification */ .g)("Success", `${Fullname}'s reports have been sent to the Printer`, "success", "top-center", 5000);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        fluid: true,
        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Margin4Print),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_notifications_component__WEBPACK_IMPORTED_MODULE_16__.ReactNotifications, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Hide4Print),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                            md: 12,
                            lg: 12,
                            sm: 11,
                            xs: 11,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "text-center h4",
                                children: "RESULT CHECKER"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                        className: "justify-content-around ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                lg: 3,
                                md: 3,
                                sm: 12,
                                xs: 12,
                                className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Hide4Print),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                    MyStyle: {
                                        borderRadius: "0px"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_27___default()), {
                                        onSubmit: GetTheResult,
                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheForm),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                            className: "justify-content-around",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    md: 12,
                                                    lg: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            className: "text-center h6",
                                                            children: "STUDENT'S DETAILS"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: "mt-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    lg: 12,
                                                    md: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                            Label: "STUDENT ID",
                                                            GetValue: setStdID,
                                                            Owner: StdID,
                                                            Color: "brown"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: "mt-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    lg: 12,
                                                    md: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    className: " ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                            Session: session,
                                                            setSession: setsession,
                                                            Disabled: !activateSelector
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: "mt-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    lg: 12,
                                                    md: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            Term: term,
                                                            setTerm: setterm,
                                                            Disabled: !activateSelector
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: "mt-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    lg: 12,
                                                    md: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            Claz: claz,
                                                            setClaz: setclaz,
                                                            Disabled: !activateSelector
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: "mt-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    lg: 12,
                                                    md: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: [
                                                        ToggleButton ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                            Label: "PIN",
                                                            GetValue: setePIN,
                                                            Owner: ePIN,
                                                            Color: "brown"
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputPassword__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                            Label: "PIN",
                                                            GetValue: setePIN,
                                                            Owner: ePIN,
                                                            Color: "brown"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                            className: "justify-content-end",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                md: 6,
                                                                lg: 6,
                                                                sm: 6,
                                                                className: "d-flex justify-content-end mt-1",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    type: "button",
                                                                    className: "btn btn-danger btn-sm",
                                                                    onClick: ()=>setToggleButton(!ToggleButton),
                                                                    children: ToggleButton ? "Hide PIN" : "Show PIN"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: "mt-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                    lg: 12,
                                                    md: 12,
                                                    sm: 11,
                                                    xs: 11,
                                                    className: "d-flex justify-content-end",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        ButtonType: "submit",
                                                        ButtonName: "CHECK RESULT"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            DisplayCardPanel && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                md: 9,
                                lg: 9,
                                sm: 11,
                                xs: 11,
                                className: ` ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Margin4Print)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().PrintCol)}`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                        ref: targetRef,
                                        id: "element-to-print",
                                        className: `align-items-start d-flex mx-2 p-0 w-100 ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().MainCardContainer)}`,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                md: 12,
                                                lg: 12,
                                                xs: 12,
                                                sm: 11,
                                                className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CardHeader),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                            md: 3,
                                                            lg: 3,
                                                            xs: 3,
                                                            sm: 3,
                                                            className: "d-flex align-items-center justify-content-around ",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                                src: _Images_schoollogo_png__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
                                                                width: 95,
                                                                height: 95,
                                                                alt: "School Logo"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                            md: 7,
                                                            lg: 7,
                                                            xs: 7,
                                                            sm: 7,
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Emmanuel),
                                                                    children: "EMMANUEL ALAYANDE UNIVERSITY OF EDUCATION"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Model),
                                                                    children: "MODEL HIGH SCHOOL, OYO"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Pmb),
                                                                    children: "P.M.B. 1010, ISOKUN, OYO"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tel),
                                                                    children: "Tel: 08033824233 Email: upmosttony@gmail.com"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Report),
                                                                    children: "REPORT CARD"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                md: 12,
                                                lg: 12,
                                                xs: 12,
                                                sm: 11,
                                                className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().RepCardCol),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                md: 10,
                                                                lg: 10,
                                                                xs: 11,
                                                                sm: 11,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                                    children: [
                                                                        StudentDescription("NAME", RetrievedStudentDetails.Fullname, 12),
                                                                        StudentDescription("ADMISSION NO.", "123456789", 4),
                                                                        StudentDescription("DATE OF BIRTH", RetrievedStudentDetails.dob, 4),
                                                                        StudentDescription("SEX", RetrievedStudentDetails.sex, 4),
                                                                        StudentDescription("SESSION", RetrievedStudentDetails.Session, 4),
                                                                        StudentDescription("TERM", RetrievedStudentDetails.Term, 4),
                                                                        StudentDescription("CLASS", RetrievedStudentDetails.Claz, 4),
                                                                        StudentDescription("NO IN CLASS", RetrievedStudentDetails.nic, 4),
                                                                        StudentDescription("TOTAL ATTENDANCE", schoolopens, 4),
                                                                        StudentDescription("NO OF TIMES PRESENT", p_attendance, 4),
                                                                        StudentDescription("NEXT TERM BEGINS ON", nexttermbegins, 12)
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                md: 2,
                                                                lg: 2,
                                                                xs: 6,
                                                                sm: 6,
                                                                className: "d-flex align-self-center",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                                    src: RetrievedStudentDetails.PixUrl === null || RetrievedStudentDetails.PixUrl === "" ? RetrievedStudentDetails.sex === "Male" ? _Images_MaleDummy_jpg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z : _Images_FemaleDummy_jpg__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z : RetrievedStudentDetails.PixUrl,
                                                                    width: 80,
                                                                    height: 80,
                                                                    alt: "StudentID"
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                        className: "justify-content-around",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                            md: 12,
                                                            lg: 12,
                                                            xs: 12,
                                                            sm: 12,
                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().theTableCol),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default()), {
                                                                responsive: true,
                                                                hover: true,
                                                                bordered: true,
                                                                striped: true,
                                                                className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tables),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().rowHead),
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                    className: DisplayMode === "Print" ? `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}` : `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheSubjects)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                    children: "SUBJECTS & SCORES"
                                                                                }),
                                                                                RotatedHeading(term, "1ST SUMM.", "1ST CA"),
                                                                                RotatedHeading(term, "2ND SUMM.", "2ND CA"),
                                                                                RotatedHeading(term, "3RD SUMM.", "EXAM"),
                                                                                RotatedHeading(term, "AVE.", "TOTAL"),
                                                                                RotatedHeading(term, "MAX.", "MAX."),
                                                                                RotatedHeading(term, "MIN.", "MIN."),
                                                                                RotatedHeading(term, "AVE.", "AVE."),
                                                                                claz.includes("JS") && RotatedHeading(term, "POS", "POS"),
                                                                                RotatedHeading(term, "GRDS", "GRDS"),
                                                                                RotatedHeading(term, "RMKS", "RMKS")
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().rowHead),
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: `pl-3 ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheSubjects)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td2)}`,
                                                                                        children: "Marks Obtainable"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: term === "Third" ? "100" : "10"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: term === "Third" ? "100" : "20"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: term === "Third" ? "100" : "70"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "100"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "-"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "-"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "-"
                                                                                    }),
                                                                                    claz.includes("JS") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "-"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "-"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                        children: "-"
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            RetrievedSubjects.map((det, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().rowHead),
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: `pl-3 ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheSubjects)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td2)}`,
                                                                                            children: det.subject_name
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det["first_term_total_score"] === null ? "AB" : det["first_term_total_score"] : det[`${term}_term_ca_score1`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det["second_term_total_score"] === null ? "AB" : det["second_term_total_score"] : det[`${term}_term_ca_score2`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det["third_term_total_score"] === null ? "AB" : det["third_term_total_score"] : det[`${term}_term_exam_score`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td)} `,
                                                                                            style: parseFloat(det["overall_average_score"]) > 49 || parseFloat(det[`${term}_term_total_score`]) > 49 ? {
                                                                                                fontWeight: "bold",
                                                                                                color: "Blue",
                                                                                                fontSize: "13px"
                                                                                            } : {
                                                                                                fontWeight: "bold",
                                                                                                color: "Red",
                                                                                                fontSize: "13px"
                                                                                            },
                                                                                            children: term === "Third" ? det["overall_average_score"] == "0" || det["overall_average_score"] == null ? "AB" : det["overall_average_score"] : det[`${term}_term_total_score`] == 0 || det[`${term}_term_total_score`] == null ? "AB" : det[`${term}_term_total_score`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det["overall_highest_score"] : det[`${term}_term_highest_score`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det["overall_lowest_score"] : det[`${term}_term_lowest_score`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det["general_average_score"] : det[`{term}_term_average_score`]
                                                                                        }),
                                                                                        claz.includes("JS") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det[`overall_position`] : det[`${term}_term_position`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det[`overall_grade`] : det[`${term}_term_grade`]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().scores_td),
                                                                                            children: term === "Third" ? det[`overall_remark`] : det[`${term}_term_remark`]
                                                                                        })
                                                                                    ]
                                                                                }, index))
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                                                className: "p-0 m-0",
                                                                style: {
                                                                    fontSize: "11px",
                                                                    fontWeight: "bold"
                                                                },
                                                                children: "Affective & Psychomotor"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        md: 3,
                                                                        lg: 3,
                                                                        sm: 12,
                                                                        xs: 12,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default()), {
                                                                            responsive: true,
                                                                            hover: true,
                                                                            bordered: true,
                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tables),
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().rowHead),
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                children: "ATTRIBUTES"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                children: "R"
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                                    children: RetrievedAttributes1.map((RAtt, index)=>StudentAttributes(1, RAtt, index))
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        md: 3,
                                                                        lg: 3,
                                                                        sm: 12,
                                                                        xs: 12,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default()), {
                                                                            responsive: true,
                                                                            hover: true,
                                                                            bordered: true,
                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tables),
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().rowHead),
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                children: "ATTRIBUTES"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                children: "R"
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                                    children: RetrievedAttributes2.map((RAtt, index)=>StudentAttributes(2, RAtt, index))
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        md: 3,
                                                                        lg: 3,
                                                                        sm: 12,
                                                                        xs: 12,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                                    md: 12,
                                                                                    lg: 12,
                                                                                    sm: 12,
                                                                                    xs: 12,
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default()), {
                                                                                        responsive: true,
                                                                                        hover: true,
                                                                                        bordered: true,
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tables),
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().rowHead),
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                            className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                            children: "ATTRIBUTES"
                                                                                                        }),
                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                            className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                            children: "R"
                                                                                                        })
                                                                                                    ]
                                                                                                })
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                                                children: RetrievedAttributes3.map((RAtt, index)=>StudentAttributes(2, RAtt, index))
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                                    md: 12,
                                                                                    lg: 12,
                                                                                    sm: 12,
                                                                                    xs: 12,
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default()), {
                                                                                        responsive: true,
                                                                                        hover: true,
                                                                                        bordered: true,
                                                                                        striped: true,
                                                                                        className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tables),
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        colSpan: "2",
                                                                                                        className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                        children: "GRADES DISTRIBUTION"
                                                                                                    })
                                                                                                })
                                                                                            }),
                                                                                            claz.includes("JS") ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                                children: [
                                                                                                    InfoTable("70-100", "A"),
                                                                                                    InfoTable("60-69", "B"),
                                                                                                    InfoTable("50-59", "C"),
                                                                                                    InfoTable("40-49", "D"),
                                                                                                    InfoTable("0-39", "F")
                                                                                                ]
                                                                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                                children: [
                                                                                                    InfoTable("75-100", "A1"),
                                                                                                    InfoTable("70-74", "B2"),
                                                                                                    InfoTable("65-69", "B3"),
                                                                                                    InfoTable("60-64", "C4"),
                                                                                                    InfoTable("55-59", "C5"),
                                                                                                    InfoTable("50-54", "C6"),
                                                                                                    InfoTable("45-49", "D7"),
                                                                                                    InfoTable("40-44", "E8"),
                                                                                                    InfoTable("0-39", "F9")
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        md: 3,
                                                                        lg: 3,
                                                                        sm: 12,
                                                                        xs: 12,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_28___default()), {
                                                                            responsive: true,
                                                                            hover: true,
                                                                            bordered: true,
                                                                            striped: true,
                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Tables),
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                children: "KEYS"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                className: `${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().TheAttributes)} ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().BoldTableHeading)}`,
                                                                                                children: "ATTRIBUTES RATINGS"
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                    children: [
                                                                                        InfoTable(5, "Maintains an excellent degree of observa traits"),
                                                                                        InfoTable(4, "Maintains high level of observable traits of observable traits"),
                                                                                        InfoTable(3, "Acceptable level of observable traits"),
                                                                                        InfoTable(2, "Shows minimal regards for observable traits"),
                                                                                        InfoTable(1, "Has no regards for the observable traits")
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                                                className: "m-0 p-0",
                                                                style: {
                                                                    fontSize: "12px",
                                                                    fontWeight: "bold"
                                                                },
                                                                children: "Remarks"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        lg: 5,
                                                                        md: 5,
                                                                        xs: 11,
                                                                        sm: 11,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CommentParagraph),
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Comment),
                                                                                    children: `"${ct_remark}"`
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CommenterDivider)
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Commenter),
                                                                                    children: "MR OLADIPO A.A"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CommenterStatus),
                                                                                    children: "CLASS TEACHER"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CommenterStatus),
                                                                                    children: "08033824233"
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        lg: 2,
                                                                        md: 2,
                                                                        xs: 11,
                                                                        sm: 11,
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((qrcode_react__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                            value: QRCodeString
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                        lg: 5,
                                                                        md: 5,
                                                                        xs: 11,
                                                                        sm: 11,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CommentParagraph),
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Comment),
                                                                                    children: `"${p_remark}"`
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().CommenterDivider)
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Commenter),
                                                                                    children: "THE PRINCIPAL"
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                                        className: "justify-content-around m-0 p-0",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                            lg: 12,
                                                            md: 12,
                                                            xs: 11,
                                                            sm: 11,
                                                            className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Applause),
                                                            children: "Software developed by: Applause Infotech | 08033824233"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_26___default()), {
                                        className: `"justify-content-around p-3" ${(_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().Hide4Print)}`,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                lg: 4,
                                                md: 4,
                                                xs: 11,
                                                sm: 11,
                                                className: "text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                    ButtonName: "PRINT",
                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().SubmitButton),
                                                    ButtonAction: PrintTheReport,
                                                    ButtonCss: buttonCss
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                lg: 4,
                                                md: 4,
                                                xs: 11,
                                                sm: 11,
                                                className: "text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                    ButtonName: "PDF",
                                                    className: (_ResultCheckerComponent_module_css__WEBPACK_IMPORTED_MODULE_25___default().SubmitButton),
                                                    ButtonAction: GenerateThePdf,
                                                    ButtonCss: buttonCss
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ResultCheckerComponent);


/***/ }),

/***/ 71348:
/***/ ((module) => {

// Exports
module.exports = {
	"mylabel": "ResultCheckerComponent_mylabel__PyvDE",
	"myvalue": "ResultCheckerComponent_myvalue__R4bnZ",
	"myvalueName": "ResultCheckerComponent_myvalueName__YDtnq",
	"Tables": "ResultCheckerComponent_Tables__pXdwa",
	"RotatedHeading": "ResultCheckerComponent_RotatedHeading__STi3N",
	"RotatedHeading2": "ResultCheckerComponent_RotatedHeading2__l_pvk",
	"TheSubjects": "ResultCheckerComponent_TheSubjects__BlqJ8",
	"theTableCol": "ResultCheckerComponent_theTableCol__Ffw2S",
	"TheAttributes": "ResultCheckerComponent_TheAttributes__YhzQK",
	"BoldTableHeading": "ResultCheckerComponent_BoldTableHeading___VRkt",
	"BoldTableHeading_pdf": "ResultCheckerComponent_BoldTableHeading_pdf__wzMdJ",
	"rowHead": "ResultCheckerComponent_rowHead__hWjVY",
	"scores_td": "ResultCheckerComponent_scores_td__BRMQe",
	"scores_td2": "ResultCheckerComponent_scores_td2__ocjgF",
	"scores_td_pdf": "ResultCheckerComponent_scores_td_pdf__PIFKu",
	"scores_td2_pdf": "ResultCheckerComponent_scores_td2_pdf__w2FyN",
	"InfoTableRight": "ResultCheckerComponent_InfoTableRight__Swr_m",
	"InfoTableLeft": "ResultCheckerComponent_InfoTableLeft__Wpp_F",
	"InfoTableRight_pdf": "ResultCheckerComponent_InfoTableRight_pdf__nKmaF",
	"InfoTableLeft_pdf": "ResultCheckerComponent_InfoTableLeft_pdf__xAA9b",
	"PlusButton": "ResultCheckerComponent_PlusButton__chFHY",
	"CommentsGroupHolder": "ResultCheckerComponent_CommentsGroupHolder__jnUlB",
	"ClassTeacherName": "ResultCheckerComponent_ClassTeacherName__jDRcL",
	"ClassTeacherName_pdf": "ResultCheckerComponent_ClassTeacherName_pdf__aYFmy",
	"SubmitButton": "ResultCheckerComponent_SubmitButton__P7swE",
	"ListHeading": "ResultCheckerComponent_ListHeading__wJNsO",
	"MainCardContainer": "ResultCheckerComponent_MainCardContainer__y0qBU",
	"PanelContainer": "ResultCheckerComponent_PanelContainer__eaUJ1",
	"CommentParagraph": "ResultCheckerComponent_CommentParagraph__eQmbW",
	"CommentParagraph_pdf": "ResultCheckerComponent_CommentParagraph_pdf__Rllv1",
	"Comment": "ResultCheckerComponent_Comment__ZOQlx",
	"Commenter": "ResultCheckerComponent_Commenter__GGGUn",
	"CommenterStatus": "ResultCheckerComponent_CommenterStatus__IhKV_",
	"Comment_pdf": "ResultCheckerComponent_Comment_pdf__IOcl_",
	"Commenter_pdf": "ResultCheckerComponent_Commenter_pdf___AKcN",
	"CommenterStatus_pdf": "ResultCheckerComponent_CommenterStatus_pdf__po6ju",
	"CommenterDivider": "ResultCheckerComponent_CommenterDivider__0RJuK",
	"Applause": "ResultCheckerComponent_Applause__dK2Tu",
	"CardLayout": "ResultCheckerComponent_CardLayout__jZitX",
	"CardHeader": "ResultCheckerComponent_CardHeader___oM6Q",
	"RepCardCol": "ResultCheckerComponent_RepCardCol__NG_vI",
	"Emmanuel": "ResultCheckerComponent_Emmanuel__GhSnr",
	"Model": "ResultCheckerComponent_Model__YK5Ds",
	"Pmb": "ResultCheckerComponent_Pmb__chGg5",
	"Tel": "ResultCheckerComponent_Tel__kk_io",
	"Report": "ResultCheckerComponent_Report__r8FnR",
	"scaleDown": "ResultCheckerComponent_scaleDown__yJIQG",
	"TheForm": "ResultCheckerComponent_TheForm__Orsjr",
	"Margin4Print": "ResultCheckerComponent_Margin4Print__M5bF8",
	"Hide4Print": "ResultCheckerComponent_Hide4Print__Xd_fr",
	"PrintCol": "ResultCheckerComponent_PrintCol__T0gBp",
	"AttributeRow": "ResultCheckerComponent_AttributeRow__T68D1",
	"TheAttributes_pdf": "ResultCheckerComponent_TheAttributes_pdf__Kvusr",
	"AttributeRow_pdf": "ResultCheckerComponent_AttributeRow_pdf__piutK"
};


/***/ }),

/***/ 71423:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./app/api/getallnames.js
var getallnames = __webpack_require__(21109);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/ResultCheckerComponent.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\ResultCheckerComponent.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const ResultCheckerComponent = (__default__);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/resultchecker/page.js





const ResultChecker = async ()=>{
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    //   return Stat ? <Promote_Students /> : <Login_Page Redirection={true} />;
    return /*#__PURE__*/ jsx_runtime_.jsx(ResultCheckerComponent, {});
};
/* harmony default export */ const page = (ResultChecker);


/***/ }),

/***/ 86544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/schoollogo.3c051509.png","height":70,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAFVBMVEUVFRVCQkIoKCghISE4ODdPT09iYmJvUV4kAAAACXBIWXMAAAsSAAALEgHS3X78AAAAMElEQVR4nC2LQQoAMAyDYpLu/08eHfMkiJJiPXygKwNgKeM53sr4NwYkpYU2eyeOLg8CAHZ0eNdaAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 50488:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,1934,7341,1335,1589,1687,2195,1334,4232,8505,8804,5528,1109,541,3446], () => (__webpack_exec__(62150)));
module.exports = __webpack_exports__;

})();