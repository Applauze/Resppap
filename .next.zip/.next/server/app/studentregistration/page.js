(() => {
var exports = {};
exports.id = 8290;
exports.ids = [8290];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 96289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'studentregistration',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79848)), "C:\\wamp64\\www\\next-app\\app\\studentregistration\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\studentregistration\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/studentregistration/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/studentregistration/page",
        pathname: "/studentregistration",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 40049:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76995))

/***/ }),

/***/ 76995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_StudentRegistration)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Store/permission-context.js
var permission_context = __webpack_require__(57948);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 53 modules
var axios = __webpack_require__(21145);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/index.js
var dist = __webpack_require__(85307);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/theme.css
var theme = __webpack_require__(2129);
// EXTERNAL MODULE: ./components/ModalsAndAlerts/OK_Modal.jsx
var OK_Modal = __webpack_require__(41129);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Container.js
var Container = __webpack_require__(46887);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Row.js
var Row = __webpack_require__(44906);
var Row_default = /*#__PURE__*/__webpack_require__.n(Row);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Col.js
var Col = __webpack_require__(57237);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Form.js
var Form = __webpack_require__(39486);
var Form_default = /*#__PURE__*/__webpack_require__.n(Form);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Button.js
var Button = __webpack_require__(93780);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Spinner.js
var Spinner = __webpack_require__(27093);
var Spinner_default = /*#__PURE__*/__webpack_require__.n(Spinner);
// EXTERNAL MODULE: ./components/Cards/BorderedCardNoHover.jsx
var BorderedCardNoHover = __webpack_require__(32182);
// EXTERNAL MODULE: ./components/Inputs/FormInputText.jsx
var FormInputText = __webpack_require__(73446);
// EXTERNAL MODULE: ./components/StudentRegistration.module.css
var StudentRegistration_module = __webpack_require__(6988);
var StudentRegistration_module_default = /*#__PURE__*/__webpack_require__.n(StudentRegistration_module);
// EXTERNAL MODULE: ./components/Inputs/FormInputSelect.jsx
var FormInputSelect = __webpack_require__(46707);
// EXTERNAL MODULE: ./node_modules/react-multi-date-picker/build/index.js
var build = __webpack_require__(68662);
;// CONCATENATED MODULE: ./components/Inputs/FormInputDate.jsx



const FormInputDate = (props)=>{
    const [Date, setDate] = (0,react_.useState)("");
    const setValue = (val)=>{
        setDate(val);
        props.GetValue(val.toString());
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
        style: {
            color: props.Color,
            fontWeight: "bold",
            display: "inline-block"
        },
        children: [
            props.Label,
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx(build/* default */.ZP, {
                value: Date,
                editable: false,
                style: {
                    height: "35px",
                    paddingLeft: "10px",
                    marginTop: "8px",
                    width: "100%"
                },
                onChange: (dateObjects)=>{
                    setValue(dateObjects);
                },
                format: "MMM DD, YYYY",
                shadow: true
            })
        ]
    });
};
/* harmony default export */ const Inputs_FormInputDate = (FormInputDate);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-image-file-resizer/build/index.js
var react_image_file_resizer_build = __webpack_require__(84929);
var build_default = /*#__PURE__*/__webpack_require__.n(react_image_file_resizer_build);
// EXTERNAL MODULE: ./node_modules/universal-cookie/cjs/index.js
var cjs = __webpack_require__(18284);
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);
// EXTERNAL MODULE: ./components/Notification.jsx
var Notification = __webpack_require__(41315);
;// CONCATENATED MODULE: ./components/StudentRegistration.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






















const StudentRegistration = ()=>{
    const cookies = new (cjs_default())();
    const [Surname, setSurname] = (0,react_.useState)("");
    const [Firstname, setFirstname] = (0,react_.useState)("");
    const [Middlename, setMiddlename] = (0,react_.useState)("");
    const [Dob, setDob] = (0,react_.useState)("");
    const [SessionAdmitted, setSessionAdmitted] = (0,react_.useState)("Select");
    const [ClassAdmitted, setClassAdmitted] = (0,react_.useState)("Select");
    const [TermAdmitted, setTermAdmitted] = (0,react_.useState)("Select");
    const [Sex, setSex] = (0,react_.useState)("Select");
    const [pictureSelected, setpictureSelected] = (0,react_.useState)(null);
    const [PictureDirectory, setPictureDirectory] = (0,react_.useState)("");
    const [Modal_Title, setModal_Title] = (0,react_.useState)("");
    const [Button_Title, setButton_Title] = (0,react_.useState)("");
    const [Modal_Message, setModal_Message] = (0,react_.useState)("");
    const [Show_Modal, setShow_Modal] = (0,react_.useState)(false);
    const [Saving, setSaving] = (0,react_.useState)(false);
    const TheColor = "brown";
    const PCtx = (0,react_.useContext)(permission_context["default"]);
    (0,react_.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    const AfterEvent = ()=>{
        setShow_Modal(false);
        setSurname("");
        setFirstname("");
        setMiddlename("");
        setSex("Select");
        setSessionAdmitted("Select");
        setClassAdmitted("Select");
        setTermAdmitted("Select");
    };
    const CapitalizeFirstLetter = (str)=>{
        return str != "" ? str[0].toUpperCase() + str.slice(1).toLowerCase() : "";
    };
    const GetSurname = (str)=>{
        setSurname(str.toUpperCase());
    };
    const GetMiddlename = (str)=>{
        setMiddlename(CapitalizeFirstLetter(str));
    };
    const GetFirstname = (str)=>{
        setFirstname(CapitalizeFirstLetter(str));
    };
    const SaveStudentInformation = async (e)=>{
        e.preventDefault();
        let fmdata = new FormData();
        let StudentD = {
            Surname: Surname,
            Firstname: Firstname,
            Middlename: Middlename,
            Dob: Dob,
            SessionAdmitted: SessionAdmitted,
            TermAdmitted: TermAdmitted,
            ClassAdmitted: ClassAdmitted,
            Sex: Sex
        };
        let StudentData = JSON.stringify(StudentD);
        fmdata.append("StudentData", StudentData);
        pictureSelected != null && fmdata.append("pictureSelected", pictureSelected, Surname);
        setSaving(true);
        try {
            const response = await axios/* default */.Z.post("/api/save_new_students", fmdata);
            console.log("Image uploaded successfully:", response.data);
        } catch (error) {
            console.error("Image upload failed:", error);
        }
        setSaving(false);
        setModal_Title("Success");
        setModal_Message(Firstname + "'s data saved succesfully!");
        setButton_Title("Ok, Thank you!");
        setShow_Modal(true);
    };
    const compressImage = (file, targetSizeInKb)=>{
        return new Promise((resolve, reject)=>{
            build_default().imageFileResizer(file, 100, 120, "JPEG", targetSizeInKb, 0, (uri)=>{
                resolve(uri);
            }, "base64");
        });
    };
    const base64ToBlob = (base64)=>{
        const parts = base64.split(";base64,");
        const contentType = parts[0].split(":")[1];
        const byteCharacters = atob(parts[1]);
        const byteArrays = [];
        for(let i = 0; i < byteCharacters.length; i++){
            byteArrays.push(byteCharacters.charCodeAt(i));
        }
        const blob = new Blob([
            new Uint8Array(byteArrays)
        ], {
            type: contentType
        });
        return blob;
    };
    const changePicture = async (event)=>{
        console.log("Exceeded");
        let namP = event.target.name;
        let valP = event.target.files[0];
        var FileSize = valP.size / 1024;
        // console.log(FileSize);
        //   var FileSize = valP.size / 1048576; // in MBin MB
        //   var FileSize = valP.size / 1073741824; // in KBin KB
        if (FileSize > 400) {
            valP = null;
            // alert("Picture size exceeds 200kb");
            (0,Notification/* DisplayNotification */.g)("Error", "Picture size exceeds 400KB", "danger", "top-center", 5000);
        } else {
            let str = event.target.value;
            if (str.endsWith("jpg") || str.endsWith("JPG") || str.endsWith("jpeg") || str.endsWith("JPEG")) {
                valP = await compressImage(valP, 50);
                setPictureDirectory(URL.createObjectURL(base64ToBlob(valP)));
                setpictureSelected(base64ToBlob(valP));
            } else {
                (0,Notification/* DisplayNotification */.g)("Error", "Only picture in jpg or jpeg format is accepted", "danger", "top-center", 5000);
            // console.log("Only picture in jpg or jpeg format is accepted");
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
        fluid: true,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist.ReactNotifications, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                className: "justify-content-around",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                        lg: 10,
                        md: 10,
                        sm: 11,
                        xs: 11,
                        className: "my-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(BorderedCardNoHover/* default */.Z, {
                            MyStyle: {
                                backgroundColor: "#eeeeee",
                                padding: "0px",
                                margin: "0px"
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                                        md: 5,
                                        lg: 5,
                                        sm: 12,
                                        xs: 12,
                                        className: `p-5 ${(StudentRegistration_module_default()).FormFirstDivision}`,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: '"text-center',
                                                children: "Please read Carefully before filling this form"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: "The surname and firstname are compulsory. The middle name may be left blank if the student has none."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: "Student Passport should be in jpeg format and should not exceed 400kb in size"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: "Ensure that the information entered in all fields are correct before submision as their may not be room for editing after submission"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: "Direct any question or information that is not clear to the Admin before saving this form."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                        md: 7,
                                        lg: 7,
                                        sm: 12,
                                        xs: 12,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()), {
                                            className: "pt-2 mb-4",
                                            onSubmit: SaveStudentInformation,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                                                    className: "justify-content-around my-1",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                        lg: 12,
                                                        md: 12,
                                                        xs: 12,
                                                        sm: 12,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "h4 text-center mb-3",
                                                            children: "New Student Registration Form"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: (StudentRegistration_module_default()).formDivider
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                                                    className: "justify-content-around",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                        md: 3,
                                                        lg: 3,
                                                        sm: 10,
                                                        xs: 10,
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                                    md: 12,
                                                                    lg: 12,
                                                                    sm: 12,
                                                                    xs: 12,
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                        height: 100,
                                                                        width: 100,
                                                                        src: PictureDirectory,
                                                                        alt: "Student Image"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()).Group, {
                                                                        controlId: "formfile",
                                                                        className: "mb-3",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Label, {
                                                                                style: {
                                                                                    color: "brown",
                                                                                    fontWeight: "bold"
                                                                                },
                                                                                children: "Select Picture"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                                                                type: "file",
                                                                                name: "Pix4",
                                                                                value: null,
                                                                                onChange: changePicture
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                ";",
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: (StudentRegistration_module_default()).formDivider
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputText/* default */.Z, {
                                                                Label: "Surname",
                                                                GetValue: GetSurname,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Surname,
                                                                Compulsory: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                            className: (StudentRegistration_module_default()).formDivider
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputText/* default */.Z, {
                                                                Label: "Firstname",
                                                                GetValue: GetFirstname,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Firstname,
                                                                Compulsory: true
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputText/* default */.Z, {
                                                                Label: "Middlename",
                                                                GetValue: GetMiddlename,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Middlename
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                            className: (StudentRegistration_module_default()).formDivider
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Inputs_FormInputDate, {
                                                                Label: "Date of Birth",
                                                                GetValue: setDob,
                                                                Color: TheColor
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputSelect/* default */.Z, {
                                                                Data: [
                                                                    "20222023",
                                                                    "20232024",
                                                                    "20242025",
                                                                    "20252026"
                                                                ],
                                                                Label: "Session Admitted",
                                                                GetValue: setSessionAdmitted,
                                                                Color: TheColor,
                                                                Owner: SessionAdmitted,
                                                                Compulsory: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                            className: (StudentRegistration_module_default()).formDivider
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputSelect/* default */.Z, {
                                                                Data: [
                                                                    "JS1",
                                                                    "JS2",
                                                                    "JS3",
                                                                    "SS1",
                                                                    "SS2",
                                                                    "SS3"
                                                                ],
                                                                Label: "Class on Admission",
                                                                GetValue: setClassAdmitted,
                                                                Color: TheColor,
                                                                Owner: ClassAdmitted,
                                                                Compulsory: true
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputSelect/* default */.Z, {
                                                                Data: [
                                                                    "First",
                                                                    "Second",
                                                                    "Third"
                                                                ],
                                                                Label: "Term Admitted",
                                                                GetValue: setTermAdmitted,
                                                                Color: TheColor,
                                                                Owner: TermAdmitted,
                                                                Compulsory: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                            className: (StudentRegistration_module_default()).formDivider
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FormInputSelect/* default */.Z, {
                                                                Data: [
                                                                    "Male",
                                                                    "Female"
                                                                ],
                                                                Label: "Sex",
                                                                GetValue: setSex,
                                                                Color: TheColor,
                                                                Owner: Sex
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                    className: "justify-content-around align-items-end",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 4,
                                                            lg: 4,
                                                            sm: 6,
                                                            xs: 6,
                                                            className: "text-center",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                                variant: "danger",
                                                                className: "btn_small px-md-4 mt-3",
                                                                disabled: Saving,
                                                                onClick: AfterEvent,
                                                                children: "Clear"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                            md: 4,
                                                            lg: 4,
                                                            sm: 6,
                                                            xs: 6,
                                                            className: "text-center",
                                                            children: Saving ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Button_default()), {
                                                                variant: "success",
                                                                className: "btn_small px-md-4 mt-3",
                                                                disabled: true,
                                                                type: "submit",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx((Spinner_default()), {
                                                                        as: "span",
                                                                        animation: "border",
                                                                        size: "sm",
                                                                        role: "status",
                                                                        "aria-hidden": "true"
                                                                    }),
                                                                    "Saving..."
                                                                ]
                                                            }) : /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                                variant: "success",
                                                                className: "btn_small px-md-4 mt-3",
                                                                type: "submit",
                                                                children: "Save"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    Show_Modal && /*#__PURE__*/ jsx_runtime_.jsx(OK_Modal/* default */.Z, {
                        title: Modal_Title,
                        message: Modal_Message,
                        ShowModal: Show_Modal,
                        buttontitle: Button_Title,
                        AfterEvent: AfterEvent,
                        variant: "success",
                        size: "sm"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_StudentRegistration = (StudentRegistration);


/***/ }),

/***/ 6988:
/***/ ((module) => {

// Exports
module.exports = {
	"formDivider": "StudentRegistration_formDivider___e9gH",
	"FormFirstDivision": "StudentRegistration_FormFirstDivision__x9gfL"
};


/***/ }),

/***/ 79848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/StudentRegistration.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\StudentRegistration.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const StudentRegistration = (__default__);
// EXTERNAL MODULE: ./app/api/getallnames.js
var getallnames = __webpack_require__(21109);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/studentregistration/page.js





const StudentsRegistration = async ()=>{
    const getStudentsNames = async ()=>{
        const All_StudentsNames = await (0,getallnames/* default */.Z)();
        return All_StudentsNames;
    };
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    let StudentsNames = "{}";
    if (Stat) {
        StudentsNames = await getStudentsNames();
    }
    return Stat ? /*#__PURE__*/ jsx_runtime_.jsx(StudentRegistration, {
        StudentsNames: StudentsNames
    }) : /*#__PURE__*/ jsx_runtime_.jsx(Login_Page/* default */.ZP, {
        Redirection: true
    });
};
/* harmony default export */ const page = (StudentsRegistration);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,1934,7341,1827,6110,4232,8505,8804,1109,3446], () => (__webpack_exec__(96289)));
module.exports = __webpack_exports__;

})();