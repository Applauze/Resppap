"use strict";
(() => {
var exports = {};
exports.id = 6417;
exports.ids = [6417];
exports.modules = {

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 41808:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 57310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 35276:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/save_new_teacher/route.js
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(42394);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(69692);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-kind.js
var route_kind = __webpack_require__(19513);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(89335);
// EXTERNAL MODULE: ./db/createtable.js
var createtable = __webpack_require__(32201);
;// CONCATENATED MODULE: ./app/api/save_new_teacher/route.js


async function POST(request, response) {
    const body = await request.json();
    const connect = await (0,createtable/* connectDatabase */.TR)();
    const { TeachersID, Title, Gateway, Surname, Firstname, Middlename, Category } = body.dataFromCaller;
    var CryptoJS = __webpack_require__(37055);
    let eGateway = CryptoJS.AES.encrypt(Gateway, "Applause143").toString();
    //   let SID = Date.now() + Math.floor(Math.random() * 100 + 0);
    //   SID = SID.toString();
    //   SID = SID.substring(2);
    //   let Student_Id = "STD_" + SID;
    const create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT,teacher_id VARCHAR(30), title VARCHAR(30),  gateway VARCHAR(30), surname VARCHAR(30), firstname VARCHAR(30), middlename VARCHAR(30),  category VARCHAR(20),  UNIQUE (teacher_id)";
    const sql = `INSERT into teachers_details (teacher_id, title, gateway,  surname, firstname, middlename, Category) VALUES ?`;
    const params = [
        [
            TeachersID,
            Title,
            eGateway,
            Surname,
            Firstname,
            Middlename,
            Category
        ]
    ];
    await (0,createtable/* createTable */.W_)(connect, "teachers_details", create_sql);
    const result = await (0,createtable/* insertTable */.Mw)(connect, sql, params);
    return result === 1 ? next_response/* default */.Z.json({
        message: "Saved Successfully",
        success: true
    }) : next_response/* default */.Z.json({
        message: "Failed woefully",
        success: true
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fsave_new_teacher%2Froute&name=app%2Fapi%2Fsave_new_teacher%2Froute&pagePath=private-next-app-dir%2Fapi%2Fsave_new_teacher%2Froute.js&appDir=C%3A%5Cwamp64%5Cwww%5Cnext-app%5Capp&appPaths=%2Fapi%2Fsave_new_teacher%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

// @ts-ignore this need to be imported from next/dist to be external


// @ts-expect-error - replaced by webpack/turbopack loader

const AppRouteRouteModule = app_route_module.AppRouteRouteModule;
// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = ""
const routeModule = new AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/save_new_teacher/route",
        pathname: "/api/save_new_teacher",
        filename: "route",
        bundlePath: "app/api/save_new_teacher/route"
    },
    resolvedPagePath: "C:\\wamp64\\www\\next-app\\app\\api\\save_new_teacher\\route.js",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { requestAsyncStorage , staticGenerationAsyncStorage , serverHooks , headerHooks , staticGenerationBailout  } = routeModule;
const originalPathname = "/api/save_new_teacher/route";


//# sourceMappingURL=app-route.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,5501,7055,4232], () => (__webpack_exec__(35276)));
module.exports = __webpack_exports__;

})();