"use strict";
(() => {
var exports = {};
exports.id = 4879;
exports.ids = [4879];
exports.modules = {

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 41808:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 57310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 99738:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/load_broadsheet/route.js
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(42394);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(69692);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-kind.js
var route_kind = __webpack_require__(19513);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(89335);
// EXTERNAL MODULE: ./db/createtable.js
var createtable = __webpack_require__(32201);
;// CONCATENATED MODULE: ./app/api/load_broadsheet/route.js


async function POST(request, response) {
    const body = await request.json();
    const connect = await (0,createtable/* connectDatabase */.TR)();
    const { Session, Term, Claz } = body.dataFromCaller;
    let select_sql = "";
    let AllSubjects = [];
    let theData = null;
    select_sql = `SELECT DISTINCT subject_name FROM ${Session}_subjects_registered WHERE Class = '${Claz}'`;
    let result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
    if (result && result.length > 0) {
        AllSubjects = result;
        let AllStudents = [];
        select_sql = `SELECT DISTINCT A.student_id , A.surname, A.firstname, A.middlename, A.sex FROM students_details A, ${Session}_subjects_registered B  WHERE A.student_id = B.student_id AND B.class = '${Claz}' ORDER BY A.surname`;
        result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
        AllStudents = result;
        let AllBroadSheetInfo = [];
        let Info = [];
        Info[0] = "Student_ID";
        Info[1] = "Names of Students";
        let n = 2;
        AllSubjects.forEach((element)=>{
            Info[n] = element.subject_name;
            n++;
        });
        Info[n] = "TOTAL";
        Info[n + 1] = "NO OFFERED";
        Info[n + 2] = "NO PASSED";
        Info[n + 3] = "NO FAILED";
        Info[n + 4] = "REMARKS";
        AllBroadSheetInfo.push(Info);
        n = 0;
        for(n = 0; n < AllStudents.length; n++){
            let Info = [];
            let No_Offered = 0;
            let No_Passed = 0;
            let No_Failed = 0;
            let Total_Sum = 0;
            Info[0] = AllStudents[n].student_id;
            Info[1] = `${AllStudents[n].surname} ${AllStudents[n].firstname} ${AllStudents[n].middlename}`;
            let p = 2;
            for(var k = 0; k < AllSubjects.length; k++){
                if (Term === "Third") {
                    select_sql = `SELECT overall_average_score FROM ${Session}_subjects_registered WHERE student_id = '${AllStudents[n].student_id}' AND subject_name = '${AllSubjects[k].subject_name}' `;
                } else {
                    select_sql = `SELECT ${Term}_term_total_score FROM ${Session}_subjects_registered WHERE student_id = '${AllStudents[n].student_id}' AND subject_name = '${AllSubjects[k].subject_name}' `;
                }
                result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
                if (result.length < 1) {
                    Info[p] = "-";
                } else {
                    let Res = result[0];
                    if (Term === "Third") {
                        if (Res["overall_average_score"] == null || Res["overall_average_score"] == undefined) {
                            Info[p] = "-";
                        } else {
                            let Mark = parseFloat(Res["overall_average_score"]);
                            No_Offered++;
                            Total_Sum += Mark;
                            if (Mark >= 50) {
                                No_Passed++;
                            } else {
                                No_Failed++;
                            }
                            Info[p] = Res["overall_average_score"];
                        }
                    } else {
                        if (Res[`${Term}_term_total_score`] && Res[`${Term}_term_total_score`] != 0) {
                            let Mark = parseFloat(Res[`${Term}_term_total_score`]);
                            No_Offered++;
                            Total_Sum += Mark;
                            if (Mark >= 40) {
                                No_Passed++;
                            } else {
                                No_Failed++;
                            }
                            Info[p] = Res[`${Term}_term_total_score`];
                        } else {
                            Info[p] = "-";
                        }
                    }
                }
                p++;
            }
            Info[p] = Total_Sum;
            Info[p + 1] = No_Offered;
            Info[p + 2] = No_Passed;
            Info[p + 3] = No_Failed;
            Info[p + 4] = "";
            AllBroadSheetInfo.push(Info);
        }
        theData = JSON.stringify(AllBroadSheetInfo);
    } else {
        theData = "No result";
    }
    connect.end();
    return theData === "No result" ? next_response/* default */.Z.json({
        message: "Error",
        success: true
    }) : next_response/* default */.Z.json({
        message: theData,
        success: true
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fload_broadsheet%2Froute&name=app%2Fapi%2Fload_broadsheet%2Froute&pagePath=private-next-app-dir%2Fapi%2Fload_broadsheet%2Froute.js&appDir=C%3A%5Cwamp64%5Cwww%5Cnext-app%5Capp&appPaths=%2Fapi%2Fload_broadsheet%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

// @ts-ignore this need to be imported from next/dist to be external


// @ts-expect-error - replaced by webpack/turbopack loader

const AppRouteRouteModule = app_route_module.AppRouteRouteModule;
// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = ""
const routeModule = new AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/load_broadsheet/route",
        pathname: "/api/load_broadsheet",
        filename: "route",
        bundlePath: "app/api/load_broadsheet/route"
    },
    resolvedPagePath: "C:\\wamp64\\www\\next-app\\app\\api\\load_broadsheet\\route.js",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { requestAsyncStorage , staticGenerationAsyncStorage , serverHooks , headerHooks , staticGenerationBailout  } = routeModule;
const originalPathname = "/api/load_broadsheet/route";


//# sourceMappingURL=app-route.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,5501,4232], () => (__webpack_exec__(99738)));
module.exports = __webpack_exports__;

})();