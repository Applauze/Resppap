"use strict";
(() => {
var exports = {};
exports.id = 3317;
exports.ids = [3317];
exports.modules = {

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 41808:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 57310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 76219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/save_all_results/route.js
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(42394);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(69692);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-kind.js
var route_kind = __webpack_require__(19513);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(89335);
// EXTERNAL MODULE: ./db/createtable.js
var createtable = __webpack_require__(32201);
;// CONCATENATED MODULE: ./app/api/save_all_results/route.js


async function POST(request, response) {
    const body = await request.json();
    const { Session, Term, Claz, Subject, Results } = body.dataFromCaller;
    let result = 1;
    const connect = await (0,createtable/* connectDatabase */.TR)();
    if (Results.length > 0) {
        Results.forEach(async (res)=>{
            let totalScore = res.TotalScore;
            let grade = res.Grade;
            let remark = res.Remark;
            let position = "";
            if (res.EXAMScore < 1 || "ABab".includes(res.EXAMScore)) {
                totalScore = 0;
                grade = "";
                remark = "";
                position = "";
            }
            let update_params = [
                res.CA1Score.toUpperCase(),
                res.CA2Score.toUpperCase(),
                res.EXAMScore.toUpperCase(),
                totalScore,
                grade,
                position,
                remark,
                res.Divisor,
                res.StdNum,
                Subject,
                Claz
            ];
            const update_sql = `Update ${Session}_subjects_registered SET ${Term}_term_ca_score1 = ?, ${Term}_term_ca_score2 = ?, ${Term}_term_exam_score = ?, ${Term}_term_total_score = ?, ${Term}_term_grade = ?, ${Term}_term_position = ?, ${Term}_term_remark = ?, divisor = ? WHERE student_id = ? AND subject_name = ? AND class = ?`;
            const update_result = await (0,createtable/* updateTable */.T0)(connect, update_sql, update_params);
            result = update_result === 1 ? 1 : 0;
        });
        let claz = Claz.slice(0, 3);
        const select_sql = `SELECT student_id, ${Term}_term_total_score FROM ${Session}_subjects_registered WHERE ${Term}_term_total_score > 0 AND  class LIKE '%${claz}%' AND subject_name = '${Subject}' ORDER BY ${Term}_term_total_score DESC`;
        let AllTotalScores = await (0,createtable/* selectTable */.jM)(connect, select_sql);
        const getminimum = (tot, considerator)=>{
            let min = 0;
            for(var i = tot.length - 1; i >= 0; i--){
                if (parseFloat(tot[i][considerator]) > 0) {
                    min = tot[i][considerator];
                    break;
                }
            }
            return min;
        };
        const getaverage = (tot, considerator)=>{
            let sumtot = 0;
            let n = 0;
            let av = 0;
            tot.forEach((element)=>{
                if (!isNaN(element[considerator]) && element[considerator] > 0) {
                    n++;
                    sumtot += parseFloat(element[considerator]);
                }
            });
            if (n > 0) {
                av = Math.ceil(sumtot / n);
            }
            return av;
        };
        const max_score = AllTotalScores[0][`${Term}_term_total_score`];
        const min_score = getminimum(AllTotalScores, `${Term}_term_total_score`);
        const average_score = getaverage(AllTotalScores, `${Term}_term_total_score`);
        const getPosMinMax = (ATS, max, min, ave, considerator)=>{
            const nth = (n)=>{
                return [
                    "st",
                    "nd",
                    "rd"
                ][((n + 90) % 100 - 10) % 10 - 1] || "th";
            };
            let pos = 1;
            let prev = 0;
            let increament = 0;
            ATS = ATS.map((element)=>{
                let ele = {};
                if (parseFloat(element[considerator]) === parseFloat(prev)) {
                    ele = {
                        ...element,
                        position: pos + nth(pos),
                        max_score: max,
                        min_score: min,
                        ave_score: ave
                    };
                    increament++;
                } else {
                    pos += increament;
                    ele = {
                        ...element,
                        position: pos + nth(pos),
                        max_score: max,
                        min_score: min,
                        ave_score: ave
                    };
                    increament = 1;
                }
                prev = element[considerator];
                return ele;
            });
            return ATS;
        };
        AllTotalScores = getPosMinMax(AllTotalScores, max_score, min_score, average_score, `${Term}_term_total_score`);
        AllTotalScores.forEach(async (res)=>{
            let update_params = [
                res.max_score,
                res.min_score,
                res.ave_score,
                res.position,
                res.student_id,
                Subject
            ];
            const update_sql = `Update ${Session}_subjects_registered SET ${Term}_term_highest_score = ?, ${Term}_term_lowest_score = ?, ${Term}_term_average_score = ?, ${Term}_term_position = ? WHERE student_id = ? AND subject_name = ? AND class LIKE '%${claz}%'`;
            const update_result = await (0,createtable/* updateTable */.T0)(connect, update_sql, update_params);
            result = update_result === 1 ? 1 : 0;
        });
        if (Term === "Third") {
            const GetJuniorGrade = (sc)=>{
                let grd = "";
                let rmk = "";
                sc = parseFloat(sc);
                if (sc >= 0 && sc < 40) {
                    grd = "F";
                    rmk = "WEAK";
                }
                if (sc >= 40 && sc < 45) {
                    grd = "E";
                    rmk = "PASS";
                }
                if (sc >= 45 && sc < 50) {
                    grd = "D";
                    rmk = "PASS";
                }
                if (sc >= 50 && sc < 60) {
                    grd = "C";
                    rmk = "CREDIT";
                }
                if (sc >= 60 && sc < 70) {
                    grd = "B";
                    rmk = "GOOD";
                }
                if (sc >= 70 && sc <= 100) {
                    grd = "A";
                    rmk = "EXCELLENT";
                }
                let grdrmk = {
                    grade: grd,
                    remark: rmk
                };
                return grdrmk;
            };
            const GetSeniorGrade = (sc)=>{
                let grd = "";
                let rmk = "";
                sc = parseFloat(sc);
                if (sc >= 0 && sc < 40) {
                    grd = "F9";
                    rmk = "WEAK";
                }
                if (sc >= 40 && sc < 45) {
                    grd = "E8";
                    rmk = "PASS";
                }
                if (sc >= 45 && sc < 50) {
                    grd = "D7";
                    rmk = "PASS";
                }
                if (sc >= 50 && sc < 55) {
                    grd = "C6";
                    rmk = "CREDIT";
                }
                if (sc >= 55 && sc < 60) {
                    grd = "C5";
                    rmk = "CREDIT";
                }
                if (sc >= 60 && sc < 65) {
                    grd = "C4";
                    rmk = "CREDIT";
                }
                if (sc >= 65 && sc < 70) {
                    grd = "B3";
                    rmk = "GOOD";
                }
                if (sc >= 70 && sc < 75) {
                    grd = "B2";
                    rmk = "VERY GOOD";
                }
                if (sc >= 70 && sc <= 100) {
                    grd = "A1";
                    rmk = "DISTINCTION";
                }
                let grdrmk = {
                    grade: grd,
                    remark: rmk
                };
                return grdrmk;
            };
            const getoveralltotalandaverage = (overall)=>{
                overall = overall.map((ovr)=>{
                    let el = {};
                    let ov1 = ovr.first_term_total_score === null || ovr.first_term_total_score === "" ? 0 : ovr.first_term_total_score;
                    let ov2 = ovr.second_term_total_score === null || ovr.second_term_total_score === "" ? 0 : ovr.second_term_total_score;
                    let ov3 = ovr.third_term_total_score === null || ovr.third_term_total_score === "" ? 0 : ovr.third_term_total_score;
                    let ovsum = ov1 + ov2 + ov3;
                    let ovave = Math.ceil(ovsum / ovr.divisor);
                    let grdrmk = Claz.includes("JS") ? GetJuniorGrade(ovave) : GetSeniorGrade(ovave);
                    el = {
                        ...ovr,
                        overall_total: ovsum,
                        overall_average: ovave,
                        overall_grade: grdrmk.grade,
                        overall_remark: grdrmk.remark
                    };
                    return el;
                });
                return overall;
            };
            const select_sql = `SELECT student_id, first_term_total_score, second_term_total_score, third_term_total_score, divisor FROM ${Session}_subjects_registered WHERE class  = '${Claz}' AND subject_name = '${Subject}'`;
            let CumTotalScores = await (0,createtable/* selectTable */.jM)(connect, select_sql);
            let OverAllDetails = getoveralltotalandaverage(CumTotalScores);
            OverAllDetails.forEach(async (ovr)=>{
                let update_params = [
                    ovr.overall_total,
                    ovr.overall_average,
                    ovr.overall_grade,
                    ovr.overall_remark,
                    ovr.student_id,
                    Subject,
                    Claz
                ];
                const update_sql = `Update ${Session}_subjects_registered SET overall_total_score = ?, overall_average_score = ?, overall_grade = ?, overall_remark = ? WHERE student_id = ? AND subject_name = ? AND class = ?`;
                const update_result = await (0,createtable/* updateTable */.T0)(connect, update_sql, update_params);
                result = update_result === 1 ? 1 : 0;
            });
            const select_sql2 = `SELECT student_id, overall_total_score, overall_average_score FROM ${Session}_subjects_registered WHERE  overall_total_score > 0 AND  class LIKE '%${claz}%' AND subject_name = '${Subject}' ORDER BY overall_average_score DESC`;
            let AllOverallTotalScores = await (0,createtable/* selectTable */.jM)(connect, select_sql2);
            const o_max_score = AllOverallTotalScores[0].overall_average_score;
            const o_min_score = getminimum(AllOverallTotalScores, "overall_average_score");
            const gen_ave_score = getaverage(AllOverallTotalScores, "overall_average_score");
            AllOverallTotalScores = getPosMinMax(AllOverallTotalScores, o_max_score, o_min_score, gen_ave_score, "overall_average_score");
            AllOverallTotalScores.forEach(async (res)=>{
                let update_params = [
                    res.max_score,
                    res.min_score,
                    res.ave_score,
                    res.position,
                    res.student_id,
                    Subject
                ];
                const update_sql = `Update ${Session}_subjects_registered SET overall_highest_score = ?, overall_lowest_score = ?, general_average_score = ?, overall_position = ? WHERE student_id = ? AND subject_name = ? AND class LIKE '%${claz}%'`;
                const update_result = await (0,createtable/* updateTable */.T0)(connect, update_sql, update_params);
                result = update_result === 1 ? 1 : 0;
            });
        }
    }
    //   connect.end();
    return result > 0 ? next_response/* default */.Z.json({
        message: "Saved Successfully",
        success: true
    }) : next_response/* default */.Z.json({
        message: "Failed woefully",
        success: true
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fsave_all_results%2Froute&name=app%2Fapi%2Fsave_all_results%2Froute&pagePath=private-next-app-dir%2Fapi%2Fsave_all_results%2Froute.js&appDir=C%3A%5Cwamp64%5Cwww%5Cnext-app%5Capp&appPaths=%2Fapi%2Fsave_all_results%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

// @ts-ignore this need to be imported from next/dist to be external


// @ts-expect-error - replaced by webpack/turbopack loader

const AppRouteRouteModule = app_route_module.AppRouteRouteModule;
// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = ""
const routeModule = new AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/save_all_results/route",
        pathname: "/api/save_all_results",
        filename: "route",
        bundlePath: "app/api/save_all_results/route"
    },
    resolvedPagePath: "C:\\wamp64\\www\\next-app\\app\\api\\save_all_results\\route.js",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { requestAsyncStorage , staticGenerationAsyncStorage , serverHooks , headerHooks , staticGenerationBailout  } = routeModule;
const originalPathname = "/api/save_all_results/route";


//# sourceMappingURL=app-route.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,5501,4232], () => (__webpack_exec__(76219)));
module.exports = __webpack_exports__;

})();