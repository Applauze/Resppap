"use strict";
(() => {
var exports = {};
exports.id = 4327;
exports.ids = [4327];
exports.modules = {

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 41808:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 57310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 71733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/promote_the_students/route.js
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(42394);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(69692);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-kind.js
var route_kind = __webpack_require__(19513);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(89335);
// EXTERNAL MODULE: ./db/createtable.js
var createtable = __webpack_require__(32201);
;// CONCATENATED MODULE: ./app/api/promote_the_students/route.js


async function POST(request, response) {
    const body = await request.json();
    const { Session, Status } = body.dataFromCaller;
    let msg = "";
    let AllStudents = [];
    let UniqueInfo = [];
    let NewClass = [
        "JS1",
        "JS2",
        "JS3",
        "SS1",
        "SS2",
        "SS3"
    ];
    if (Status === "Check") {
        var result = [];
        const connect = await (0,createtable/* connectDatabase */.TR)();
        result = await (0,createtable/* checkTableExistence */.nQ)(connect, Session);
        msg = result.length > 0 ? true : false;
        let theData = "";
    } else {
        if (Status === "Promote") {
            const connect = await (0,createtable/* connectDatabase */.TR)();
            let prevSession = (parseInt(Session) - 10001).toString();
            const select_sql = `SELECT  student_id, subject_name, class FROM ${prevSession}_subjects_registered WHERE class LIKE '%JS1%' OR class LIKE '%JS2%' OR class LIKE '%SS1%' OR class LIKE '%SS2%' `;
            var result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
            AllStudents = result;
            let create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT,student_id VARCHAR(30), subject_name VARCHAR(40), subject_type VARCHAR(30), class VARCHAR(10), teacher_id VARCHAR(20), date_registered VARCHAR(20), first_term_ca_score1 VARCHAR(10) DEFAULT 'AB', first_term_ca_score2 VARCHAR(10) DEFAULT 'AB', first_term_exam_score VARCHAR(10) DEFAULT 'AB', first_term_total_score INT(10), first_term_highest_score VARCHAR(10), first_term_lowest_score VARCHAR(10), first_term_average_score VARCHAR(10), first_term_position VARCHAR(10), first_term_grade VARCHAR(10), first_term_remark VARCHAR(10), second_term_ca_score1 VARCHAR(10) DEFAULT 'AB', second_term_ca_score2 VARCHAR(10) DEFAULT 'AB', second_term_exam_score VARCHAR(10) DEFAULT 'AB', second_term_total_score INT(10), second_term_highest_score VARCHAR(10), second_term_lowest_score VARCHAR(10), second_term_average_score VARCHAR(10), second_term_position VARCHAR(10), second_term_grade VARCHAR(10), second_term_remark VARCHAR(10), third_term_ca_score1 VARCHAR(10) DEFAULT 'AB', third_term_ca_score2 VARCHAR(10) DEFAULT 'AB', third_term_exam_score VARCHAR(10) DEFAULT 'AB', third_term_total_score INT(10), third_term_highest_score VARCHAR(10), third_term_lowest_score VARCHAR(10), third_term_average_score VARCHAR(10), third_term_position VARCHAR(10), third_term_grade VARCHAR(10), third_term_remark VARCHAR(10),  divisor INT(10) DEFAULT '3', overall_total_score INT(10), overall_highest_score VARCHAR(10), overall_lowest_score VARCHAR(10), overall_average_score VARCHAR(10), overall_position VARCHAR(10), overall_grade VARCHAR(10), overall_remark VARCHAR(10), general_average_score INT (10), promotion_status VARCHAR(30) DEFAULT 'Not decided', status VARCHAR(10) DEFAULT 'Active', UNIQUE (student_id, subject_name, class)";
            await (0,createtable/* createTable */.W_)(connect, Session + "_subjects_registered", create_sql);
            create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT, attributes VARCHAR(50)";
            await (0,createtable/* createTable */.W_)(connect, "all_psycomotor_attributes", create_sql);
            create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT, Session VARCHAR(10), Term VARCHAR(10), SchoolOpens VARCHAR(10), Resumption VARCHAR(10)";
            await (0,createtable/* createTable */.W_)(connect, "Term_Properties", create_sql);
            create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT, student_id VARCHAR(30),  class VARCHAR(5), first_term_attribute VARCHAR(200), first_term_value VARCHAR(4), second_term_attribute VARCHAR(200), second_term_value VARCHAR(4), third_term_attribute VARCHAR(200), third_term_value VARCHAR(4)";
            await (0,createtable/* createTable */.W_)(connect, Session + "_psycomotor_ratings", create_sql);
            create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT, student_id VARCHAR(30),  class VARCHAR(5), first_term_ctc VARCHAR(1000), first_term_pc VARCHAR(1000), first_term_attendance  VARCHAR(5), second_term_ctc VARCHAR(1000), second_term_pc VARCHAR(1000), second_term_attendance  VARCHAR(5), third_term_ctc VARCHAR(1000), third_term_pc VARCHAR(1000), third_term_attendance  VARCHAR(5),   UNIQUE (student_id, class)";
            await (0,createtable/* createTable */.W_)(connect, Session + "_all_comments_and_attendance", create_sql);
            create_sql = "ssn INT PRIMARY KEY AUTO_INCREMENT, student_id VARCHAR(30),  session VARCHAR(20), term VARCHAR(10), class VARCHAR(20), gate VARCHAR(200), status VARCHAR(20)";
            await (0,createtable/* createTable */.W_)(connect, `${Session}_resultchecker`, create_sql);
            let TheValues = [];
            AllStudents.forEach((element)=>{
                let OClaz = element.class;
                let C1 = OClaz.substring(0, 3);
                let Arm = OClaz.substring(OClaz.length - 1);
                let OldInd = NewClass.indexOf(C1);
                let Claz = NewClass[OldInd + 1] + Arm;
                let TheVal = [
                    element.student_id,
                    element.subject_name,
                    Claz
                ];
                TheValues = [
                    ...TheValues,
                    TheVal
                ];
                let newElement = {
                    student_id: element.student_id,
                    class: element.class
                };
                if (!UniqueInfo.some((obj)=>JSON.stringify(obj) === JSON.stringify(newElement))) {
                    UniqueInfo.push(newElement);
                }
            });
            let sql = `INSERT into ${Session}_subjects_registered (student_id, subject_name, class) VALUES ?`;
            const params = TheValues;
            result = await (0,createtable/* insertTable */.Mw)(connect, sql, params);
            for(var m = 0; m < UniqueInfo.length; m++){
                let element = UniqueInfo[m];
                // UniqueInfo.forEach(element => {
                let SID = element.student_id;
                let OClaz = element.class;
                let C1 = OClaz.substring(0, 3);
                let Arm = OClaz.substring(OClaz.length - 1);
                let OldInd = NewClass.indexOf(C1);
                let Claz = NewClass[OldInd + 1] + Arm;
                const CreatePsychomotor = async ()=>{
                    let select_sql = "SELECT attributes FROM all_psycomotor_attributes";
                    result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
                    let response = result;
                    if (result.length < 1) {
                        let params = [
                            [
                                "Attentiveness in Class"
                            ],
                            [
                                "Reliability"
                            ],
                            [
                                "Fluency"
                            ],
                            [
                                "Drawing, Painting & Craft"
                            ],
                            [
                                "Games, Sports & Gymnastics"
                            ],
                            [
                                "Handling of Tools in the Lab/Shop"
                            ],
                            [
                                "Handwriting"
                            ],
                            [
                                "Honesty"
                            ],
                            [
                                "Initiative"
                            ],
                            [
                                "Musical Skills"
                            ],
                            [
                                "Neatness"
                            ],
                            [
                                "Obedience"
                            ],
                            [
                                "Organisation Ability"
                            ],
                            [
                                " Perseverance/ Industry"
                            ],
                            [
                                "Politeness"
                            ],
                            [
                                "Promptness in Completing work"
                            ],
                            [
                                "Punctuality, Attendance in Class"
                            ],
                            [
                                "Relationship with other Students"
                            ],
                            [
                                "Self Control"
                            ],
                            [
                                "Self of Responsibility"
                            ],
                            [
                                "Spirit of Cooperation"
                            ],
                            [
                                "Trustworthiness"
                            ]
                        ];
                        const sql = `INSERT into all_psycomotor_attributes (attributes) VALUES ?`;
                        result = await (0,createtable/* insertTable */.Mw)(connect, sql, params);
                        CreatePsychomotor();
                    } else {
                        let select_sql = `SELECT student_id FROM ${Session}_psycomotor_ratings WHERE student_id = '${SID}' `;
                        result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
                        if (result.length < 1) {
                            let TheValuz = [];
                            response.forEach((att)=>{
                                let TheVal = [
                                    SID,
                                    Claz,
                                    `${att.attributes}`,
                                    `${att.attributes}`,
                                    `${att.attributes}`
                                ];
                                TheValuz = [
                                    ...TheValuz,
                                    TheVal
                                ];
                            });
                            const sql = `INSERT into ${Session}_psycomotor_ratings (student_id, class, first_term_attribute, second_term_attribute, third_term_attribute) VALUES ?`;
                            result = await (0,createtable/* insertTable */.Mw)(connect, sql, TheValuz);
                        }
                    }
                };
                CreatePsychomotor();
                let select_sql = `SELECT student_id FROM ${Session}_all_comments_and_attendance WHERE student_id = '${SID}' `;
                result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
                if (result.length < 1) {
                    let Prmz = [
                        [
                            SID,
                            Claz
                        ]
                    ];
                    const sql2 = `INSERT into ${Session}_all_comments_and_attendance (student_id, class) VALUES ?`;
                    result = await (0,createtable/* insertTable */.Mw)(connect, sql2, Prmz);
                }
                let TheTerms = [
                    "First",
                    "Second",
                    "Third"
                ];
                var CryptoJS = __webpack_require__(37055);
                for(var i = 0; i < TheTerms.length; i++){
                    let aPIN = Date.now().toString().slice(-4) + Math.floor(1000 + Math.random() * 9000).toString() + Math.floor(1000 + Math.random() * 9000).toString() + Math.floor(1000 + Math.random() * 9000).toString();
                    let PIN = process.env.mypin;
                    aPIN = aPIN.toString();
                    aPIN = CryptoJS.AES.encrypt(aPIN, PIN).toString();
                    let theval = [
                        [
                            SID,
                            Session,
                            TheTerms[i],
                            Claz,
                            aPIN
                        ]
                    ];
                    let sql = `INSERT into ${Session}_resultchecker (student_id, session, term, class, gate) VALUES ?`;
                    const params = theval;
                    result = await (0,createtable/* insertTable */.Mw)(connect, sql, params);
                }
                select_sql = `SELECT class FROM students_class_track WHERE student_id = '${SID}' AND session =  '${Session}'`;
                result = await (0,createtable/* selectTable */.jM)(connect, select_sql);
                if (result.length < 1) {
                    let Track = [
                        [
                            SID,
                            Session,
                            Claz
                        ]
                    ];
                    const sql3 = `INSERT into students_class_track (student_id, session, class) VALUES ?`;
                    result = await (0,createtable/* insertTable */.Mw)(connect, sql3, Track);
                }
            }
            msg = "success";
        }
    }
    return next_response/* default */.Z.json({
        message: msg,
        success: true
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fpromote_the_students%2Froute&name=app%2Fapi%2Fpromote_the_students%2Froute&pagePath=private-next-app-dir%2Fapi%2Fpromote_the_students%2Froute.js&appDir=C%3A%5Cwamp64%5Cwww%5Cnext-app%5Capp&appPaths=%2Fapi%2Fpromote_the_students%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

// @ts-ignore this need to be imported from next/dist to be external


// @ts-expect-error - replaced by webpack/turbopack loader

const AppRouteRouteModule = app_route_module.AppRouteRouteModule;
// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = ""
const routeModule = new AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/promote_the_students/route",
        pathname: "/api/promote_the_students",
        filename: "route",
        bundlePath: "app/api/promote_the_students/route"
    },
    resolvedPagePath: "C:\\wamp64\\www\\next-app\\app\\api\\promote_the_students\\route.js",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { requestAsyncStorage , staticGenerationAsyncStorage , serverHooks , headerHooks , staticGenerationBailout  } = routeModule;
const originalPathname = "/api/promote_the_students/route";


//# sourceMappingURL=app-route.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,5501,7055,4232], () => (__webpack_exec__(71733)));
module.exports = __webpack_exports__;

})();