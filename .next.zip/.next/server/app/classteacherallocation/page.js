(() => {
var exports = {};
exports.id = 4711;
exports.ids = [4711];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 10817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'classteacherallocation',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 20739)), "C:\\wamp64\\www\\next-app\\app\\classteacherallocation\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\classteacherallocation\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/classteacherallocation/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/classteacherallocation/page",
        pathname: "/classteacherallocation",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 76827:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86144))

/***/ }),

/***/ 86144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Store_permission_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57948);
/* harmony import */ var _API_Call_axioscall__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(69294);
/* harmony import */ var _SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29332);
/* harmony import */ var _SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(42634);
/* harmony import */ var _SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55607);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(41315);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2129);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _ModalsAndAlerts_OK_Modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41129);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(46887);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(44906);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(57237);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(32182);
/* harmony import */ var _ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(24606);
/* harmony import */ var rsuite__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(22350);
/* harmony import */ var rsuite_dist_rsuite_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85546);
/* harmony import */ var rsuite_dist_rsuite_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(rsuite_dist_rsuite_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_13__);
/* __next_internal_client_entry_do_not_use__ default auto */ 





















const Class_Allocation = (props)=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_13___default())();
    const [session, setsession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [claz, setclaz] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [term, setterm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [Teachername, setTeachername] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [LoadedTeachers, setLoadedTeachers] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllTheTeachers, setAllTheTeachers] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllTheTeachersID, setAllTheTeachersID] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [activateSelector, setactivateSelector] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [activateButton, setactivateButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showProcessing, setshowProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [Message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const PCtx = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_Store_permission_context__WEBPACK_IMPORTED_MODULE_2__["default"]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const AllTeachers = JSON.parse(props.TeachersNames);
        setLoadedTeachers(AllTeachers);
        setAllTheTeachersID(AllTeachers.AllTeachersID);
        setAllTheTeachers(AllTeachers.AllTeachersNames);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const activateTheButton = ()=>{
            if (session != "Select" && claz != "Select" && term != "Select") {
                setactivateButton(true);
            } else {
                setactivateButton(false);
            }
        };
        activateTheButton();
    }, [
        session,
        claz,
        term
    ]);
    const AuthorizeTeacher = async (e)=>{
        e.preventDefault();
        setshowProcessing(true);
        setMessage(`The system is authorizing ${Teachername}`);
        let m = AllTheTeachers.indexOf(Teachername);
        console.log(m);
        let AllIDs = [
            ...AllTheTeachersID
        ];
        let Allocation = {
            TeacherID: AllIDs[m],
            Session: session,
            Term: term,
            Claz: claz
        };
        let SaveTheAllocation = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)("save_class_teacher_allocation", Allocation);
        if (SaveTheAllocation === "Saved Successfully") {
            setshowProcessing(false);
            (0,_Notification__WEBPACK_IMPORTED_MODULE_7__/* .DisplayNotification */ .g)("Success", `${Teachername} successfully authorized for  ${claz}, ${term} Term, ${session} Session`, "success", "top-center", 5000);
            setTeachername("");
            setterm("Select");
            setsession("Select");
            setclaz("Select");
        }
    };
    const getTeachernameSelection = async (it)=>{
        setTeachername(it);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_15___default()), {
        fluid: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_notifications_component__WEBPACK_IMPORTED_MODULE_6__.ReactNotifications, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default()), {
                className: "justify-content-around",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                    lg: 12,
                    md: 12,
                    sm: 11,
                    xs: 11,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        MyStyle: {
                            backgroundColor: "#eeeeee",
                            paddingLeft: "40px",
                            paddingRight: "40px",
                            margin: "0px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                    md: 12,
                                    lg: 12,
                                    sm: 11,
                                    xs: 11,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "text-center h4",
                                        children: "CLASS TEACHER'S AUTHORIZATION"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default()), {
                                className: "justify-content-around",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                    md: 6,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_18___default().Group), {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_18___default().Label), {
                                                style: {
                                                    color: "brown"
                                                },
                                                children: "Teacher's Name"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(rsuite__WEBPACK_IMPORTED_MODULE_19__/* .AutoComplete */ .Qc, {
                                                data: AllTheTeachers,
                                                value: Teachername,
                                                onChange: setTeachername,
                                                onSelect: getTeachernameSelection
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default()), {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_18___default()), {
                                    onSubmit: AuthorizeTeacher,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default()), {
                                            className: "justify-content-around",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                    lg: 4,
                                                    md: 4,
                                                    sm: 11,
                                                    xs: 11,
                                                    className: " ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                        Session: session,
                                                        setSession: setsession,
                                                        Disabled: !activateSelector
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                    lg: 4,
                                                    md: 4,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        Term: term,
                                                        setTerm: setterm,
                                                        Disabled: !activateSelector
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                    className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                    lg: 4,
                                                    md: 4,
                                                    sm: 11,
                                                    xs: 11,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        Claz: claz,
                                                        setClaz: setclaz,
                                                        Disabled: !activateSelector
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_16___default()), {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                lg: 3,
                                                md: 3,
                                                sm: 11,
                                                xs: 11,
                                                className: "mt-2 col-offset-9",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20___default()), {
                                                    variance: "info",
                                                    type: "submit",
                                                    disabled: !activateButton,
                                                    children: "Authorize"
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Class_Allocation);


/***/ }),

/***/ 55607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Term = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: [
            "First",
            "Second",
            "Third"
        ],
        Label: "Term",
        GetValue: props.setTerm,
        Color: "brown",
        Owner: props.Term,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Term);


/***/ }),

/***/ 7046:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89335);
/* harmony import */ var _db_createtable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32201);


const GetAllNames = async (request, response)=>{
    const connect = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabase */ .TR)();
    const select_sql = " SELECT teacher_id, surname, firstname, middlename FROM teachers_details";
    const result = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_1__/* .selectTable */ .jM)(connect, select_sql);
    let AllNames = [];
    let AllTIDs = [];
    let AllTeachersDetails = {};
    result.forEach((Teacher)=>{
        AllNames = [
            ...AllNames,
            Teacher.surname + " " + Teacher.firstname + " " + Teacher.middlename
        ];
        AllTIDs = [
            ...AllTIDs,
            Teacher.teacher_id
        ];
    });
    AllTeachersDetails = {
        AllTeachersNames: AllNames,
        AllTeachersID: AllTIDs
    };
    const theData = JSON.stringify(AllTeachersDetails);
    connect.end();
    return theData;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetAllNames);


/***/ }),

/***/ 20739:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/Class_Allocation.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\Class_Allocation.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Class_Allocation = (__default__);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./app/api/getallteachersname.js
var getallteachersname = __webpack_require__(7046);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/classteacherallocation/page.js





const ClassAllocation = async ()=>{
    // const getSubjects = async () => {
    //   const All_Subjects = await GetAllSubjects();
    //   return All_Subjects;
    // };
    const getTeachersNames = async ()=>{
        const All_TeachersNames = await (0,getallteachersname/* default */.Z)();
        return All_TeachersNames;
    };
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    let TeachersNames = "{}";
    if (Stat) {
        TeachersNames = await getTeachersNames();
    }
    return Stat ? /*#__PURE__*/ jsx_runtime_.jsx(Class_Allocation, {
        TeachersNames: TeachersNames
    }) : /*#__PURE__*/ jsx_runtime_.jsx(Login_Page/* default */.ZP, {
        Redirection: true
    });
};
/* harmony default export */ const page = (ClassAllocation);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,2284,9335,1934,7341,1335,1608,4232,8505,8804,5528], () => (__webpack_exec__(10817)));
module.exports = __webpack_exports__;

})();