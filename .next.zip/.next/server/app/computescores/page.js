(() => {
var exports = {};
exports.id = 6747;
exports.ids = [6747];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 70401:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'computescores',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50745)), "C:\\wamp64\\www\\next-app\\app\\computescores\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\computescores\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/computescores/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/computescores/page",
        pathname: "/computescores",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 87741:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68763))

/***/ }),

/***/ 68763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Compute_Scores)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Store/permission-context.js
var permission_context = __webpack_require__(57948);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Row.js
var Row = __webpack_require__(44906);
var Row_default = /*#__PURE__*/__webpack_require__.n(Row);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Col.js
var Col = __webpack_require__(57237);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Tabs.js
var Tabs = __webpack_require__(5091);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Tab.js
var Tab = __webpack_require__(25005);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/index.js
var dist = __webpack_require__(85307);
// EXTERNAL MODULE: ./components/SessionTermClass/Session.jsx
var Session = __webpack_require__(29332);
// EXTERNAL MODULE: ./components/SessionTermClass/Class.jsx
var Class = __webpack_require__(42634);
// EXTERNAL MODULE: ./components/SessionTermClass/Term.jsx
var Term = __webpack_require__(55607);
// EXTERNAL MODULE: ./components/SessionTermClass/Subjects.jsx
var Subjects = __webpack_require__(67109);
// EXTERNAL MODULE: ./components/ModalsAndAlerts/OK_Modal.jsx
var OK_Modal = __webpack_require__(41129);
// EXTERNAL MODULE: ./components/ModalsAndAlerts/Processing_Modal.jsx
var Processing_Modal = __webpack_require__(24606);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Form.js
var Form = __webpack_require__(39486);
var Form_default = /*#__PURE__*/__webpack_require__.n(Form);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Button.js
var Button = __webpack_require__(93780);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Table.js
var Table = __webpack_require__(11589);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./components/API_Call/axioscall.js
var axioscall = __webpack_require__(69294);
// EXTERNAL MODULE: ./components/Notification.jsx
var Notification = __webpack_require__(41315);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/theme.css
var theme = __webpack_require__(2129);
// EXTERNAL MODULE: ./node_modules/react-excel-renderer/build/index.js
var build = __webpack_require__(37208);
// EXTERNAL MODULE: ./node_modules/universal-cookie/cjs/index.js
var cjs = __webpack_require__(18284);
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);
// EXTERNAL MODULE: ./node_modules/react-html-table-to-excel/index.js
var react_html_table_to_excel = __webpack_require__(55245);
;// CONCATENATED MODULE: ./components/Import_Scores_File.jsx






















const Import_Scores_File = (props)=>{
    const [session, setsession] = (0,react_.useState)("Select");
    const [claz, setclaz] = (0,react_.useState)("Select");
    const [term, setterm] = (0,react_.useState)("Select");
    const [LoadedSubjects, setLoadedSubjects] = (0,react_.useState)([]);
    const [AllServerSubjects, setAllServerSubjects] = (0,react_.useState)([]);
    const [pickedSubject, setpickedSubject] = (0,react_.useState)("Select");
    const [activateSelector, setactivateSelector] = (0,react_.useState)(true);
    const [activateButton, setactivateButton] = (0,react_.useState)(false);
    const [ConcernedStudents, setConcernedStudents] = (0,react_.useState)([]);
    const [showProcessing, setshowProcessing] = (0,react_.useState)(false);
    const [displayStudents, setdisplayStudents] = (0,react_.useState)(false);
    const [dataready, setdataready] = (0,react_.useState)(false);
    const [FileDirectory, setFileDirectory] = (0,react_.useState)("");
    const [Modal_Message, setModal_Message] = (0,react_.useState)("");
    const [Message, setMessage] = (0,react_.useState)("");
    const [Modal_Title, setModal_Title] = (0,react_.useState)("");
    const [Show_Modal, setShow_Modal] = (0,react_.useState)(false);
    const [Button_Title, setButton_Title] = (0,react_.useState)("");
    const [Cols, setCols] = (0,react_.useState)([]);
    const [Rows, setRows] = (0,react_.useState)([]);
    const [JSONdataArray, setJSONdataArray] = (0,react_.useState)({});
    const cookies = new (cjs_default())();
    (0,react_.useEffect)(()=>{
        const AllSubs = JSON.parse(props.Subjects);
        setAllServerSubjects(AllSubs);
    }, []);
    (0,react_.useEffect)(()=>{
        if (claz.includes("JS")) {
            setLoadedSubjects(GetClassSubjects("Junior"));
        } else {
            setLoadedSubjects(GetClassSubjects("Senior"));
        }
    }, [
        claz
    ]);
    (0,react_.useEffect)(()=>{
        const activateTheButton = ()=>{
            if (session != "Select" && claz != "Select" && pickedSubject != "Select" && term != "Select") {
                setactivateButton(true);
            } else {
                setactivateButton(false);
            }
        };
        setFileDirectory("");
        setdataready(false);
        setdisplayStudents(false);
        activateTheButton();
    }, [
        session,
        claz,
        term,
        pickedSubject
    ]);
    const AfterEvent = ()=>{
        setShow_Modal(false);
    };
    const GetClassSubjects = (clx)=>{
        let DisplayedSubjects = [];
        let AllRSub = AllServerSubjects.filter((el)=>el.subject_type === "All" || el.subject_type === clx);
        AllRSub.forEach((element)=>{
            DisplayedSubjects = [
                ...DisplayedSubjects,
                element.subject_name
            ];
        });
        return DisplayedSubjects;
    };
    const GetJuniorGrade = (sc)=>{
        let grd = "";
        let rmk = "";
        sc = parseFloat(sc);
        if (sc >= 0 && sc < 40) {
            grd = "F";
            rmk = "WEAK";
        }
        if (sc >= 40 && sc < 45) {
            grd = "E";
            rmk = "PASS";
        }
        if (sc >= 45 && sc < 50) {
            grd = "D";
            rmk = "PASS";
        }
        if (sc >= 50 && sc < 60) {
            grd = "C";
            rmk = "CREDIT";
        }
        if (sc >= 60 && sc < 70) {
            grd = "B";
            rmk = "GOOD";
        }
        if (sc >= 70 && sc <= 100) {
            grd = "A";
            rmk = "EXCELLENT";
        }
        let grdrmk = {
            grade: grd,
            remark: rmk
        };
        return grdrmk;
    };
    const GetSeniorGrade = (sc)=>{
        let grd = "";
        let rmk = "";
        sc = parseFloat(sc);
        if (sc >= 0 && sc < 40) {
            grd = "F9";
            rmk = "WEAK";
        }
        if (sc >= 40 && sc < 45) {
            grd = "E8";
            rmk = "PASS";
        }
        if (sc >= 45 && sc < 50) {
            grd = "D7";
            rmk = "PASS";
        }
        if (sc >= 50 && sc < 55) {
            grd = "C6";
            rmk = "CREDIT";
        }
        if (sc >= 55 && sc < 60) {
            grd = "C5";
            rmk = "CREDIT";
        }
        if (sc >= 60 && sc < 65) {
            grd = "C4";
            rmk = "CREDIT";
        }
        if (sc >= 65 && sc < 70) {
            grd = "B3";
            rmk = "GOOD";
        }
        if (sc >= 70 && sc < 75) {
            grd = "B2";
            rmk = "VERY GOOD";
        }
        if (sc >= 70 && sc <= 100) {
            grd = "A1";
            rmk = "DISTINCTION";
        }
        let grdrmk = {
            grade: grd,
            remark: rmk
        };
        return grdrmk;
    };
    const ScoreCheck = (scr, limit, AfStd, Sorc)=>{
        let AB = "ABab";
        let Error = "Error";
        let Msg = "";
        if (Sorc === "DIVISOR") {
            AfStd["Divisor"] = scr;
        } else {
            switch(Sorc){
                case "CA1":
                    Msg = "First CA Test";
                    break;
                case "CA2":
                    Msg = "Second CA Test";
                    break;
                case "EXAM":
                    Msg = "Exam";
                    break;
            }
            if (scr > limit && !isNaN(scr)) {
                (0,Notification/* DisplayNotification */.g)("Error", `${Msg} Score cannot be more than ${limit} Marks`, "danger", "top-center", 5000);
                AfStd[Sorc + "Score"] = "Error";
                AfStd["BackG" + Sorc] = "red";
            } else {
                if (Error.includes(scr)) {
                    AfStd["BackG" + Sorc] = "red";
                    AfStd[Sorc + "Score"] = scr;
                } else {
                    AfStd["BackG" + Sorc] = "white";
                    AfStd[Sorc + "Score"] = scr;
                }
            }
            let ca1score = "ABab".includes(AfStd.CA1Score) || "Error".includes(AfStd.CA1Score) || AfStd.CA1Score === "" ? 0 : AfStd.CA1Score;
            let ca2score = "ABab".includes(AfStd.CA2Score) || "Error".includes(AfStd.CA2Score) || AfStd.CA2Score === "" ? 0 : AfStd.CA2Score;
            let examscore = "ABab".includes(AfStd.EXAMScore) || "Error".includes(AfStd.EXAMScore) || AfStd.EXAMScore === "" ? 0 : AfStd.EXAMScore;
            AfStd.TotalScore = parseFloat(ca1score) + parseFloat(ca2score) + parseFloat(examscore);
            let GRDRMK = claz.includes("JS") ? GetJuniorGrade(AfStd.TotalScore) : GetSeniorGrade(AfStd.TotalScore);
            AfStd["Grade"] = GRDRMK.grade;
            AfStd["Remark"] = GRDRMK.remark;
        }
        return AfStd;
    };
    const GetTheStudents = async (e)=>{
        e.preventDefault();
        setMessage(`The system is retrieving the students offering ${pickedSubject} in ${claz}`);
        let TeacherID = cookies.get("this_staff");
        let Category = cookies.get("this_category");
        setshowProcessing(true);
        let ScoreDetails = {
            Session: session,
            Term: term,
            Claz: claz,
            PickedSubject: pickedSubject,
            TeacherID: TeacherID ? TeacherID : "Nothing",
            Category: Category ? Category : "Nothing"
        };
        let RegisteredStudents = await (0,axioscall/* default */.Z)("get_subjects_registered_students", ScoreDetails);
        if (!RegisteredStudents.includes("Not Authorized")) {
            if (!RegisteredStudents.includes("Error")) {
                let AllNamesAndNumbers = [];
                RegisteredStudents = JSON.parse(RegisteredStudents);
                const AS = RegisteredStudents.AllStudents;
                AS.forEach((element)=>{
                    let divider = 1;
                    if (element.first_term_total_score && element.first_term_total_score > 0) {
                        divider++;
                    }
                    if (element.second_term_total_score && element.second_term_total_score > 0) {
                        divider++;
                    }
                    AllNamesAndNumbers = [
                        ...AllNamesAndNumbers,
                        {
                            StdNum: element["student_id"],
                            StdName: `${element.surname} ${element.firstname} ${element.middlename}`,
                            CA1Score: element[term + "_term_ca_score1"],
                            CA2Score: element[term + "_term_ca_score2"],
                            EXAMScore: element[term + "_term_exam_score"],
                            TotalScore: element[term + "_term_total_score"] && element[term + "_term_total_score"] > 0 ? element[term + "_term_total_score"] : 0,
                            HighestScore: element[term + "_term_highest_score"] ? element[term + "_term_total_score"] : 0,
                            LowestScore: element[term + "_term_lowest_score"] ? element[term + "_term_total_score"] : 0,
                            AverageScore: element[term + "_term_average_score"],
                            Position: element[term + "_term_position"],
                            Grade: element[term + "_term_grade"],
                            Remark: element[term + "_term_remark"],
                            StdNum: element.student_id,
                            BackGCA1: "white",
                            BackGCA2: "white",
                            BackGEXAM: "white",
                            Divisor: divider
                        }
                    ];
                });
                setConcernedStudents(AllNamesAndNumbers);
                setdisplayStudents(true);
                setdataready(true);
            } else {
                props.Notify(`There was a problem in retrieving the students. Please ensure that the students have been registered for ${pickedSubject} in ${session} Session`);
            }
        } else {
            props.Notify(`You are not an authorized teacher for the selected class. Please contact the Administrator`);
        }
        setshowProcessing(false);
    };
    const PickFile = (event)=>{
        let str = event.target.value;
        if (str.endsWith("xlsx") || str.endsWith("xls")) {
            let namP = event.target.name;
            let valP = event.target.files[0];
            ProcessFile(valP);
            // setFileObject(valP);
            setFileDirectory(str);
        // Use the ExcelRenderer to parse the file
        } else {
            // console.log("Only picture in jpg or jpeg format is accepted");
            // PCtx.displayAlert("ERROR", "This is not an Excel File", "danger");
            (0,Notification/* DisplayNotification */.g)("Error", `This is not an Excel File`, "danger", "top-center", 7000);
        }
    };
    const CheckScoreValidity = (Data)=>{
        let NoError = true;
        let Culprits = [];
        let Cul = [];
        for(var i = 0; i < Data.length; i++){
            let C1 = isNaN(parseFloat(Data[i]["1ST CA (10)"].toString().replace(/\s+/g, ""))) ? Data[i]["1ST CA (10)"].toString() : parseFloat(Data[i]["1ST CA (10)"].toString().replace(/\s+/g, ""));
            let C2 = isNaN(parseFloat(Data[i]["2ND CA (20)"].toString().replace(/\s+/g, ""))) ? Data[i]["2ND CA (20)"].toString() : parseFloat(Data[i]["2ND CA (20)"].toString().replace(/\s+/g, ""));
            let E1 = isNaN(parseFloat(Data[i]["EXAM (70)"].toString().replace(/\s+/g, ""))) ? Data[i]["EXAM (70)"].toString() : parseFloat(Data[i]["EXAM (70)"].toString().replace(/\s+/g, ""));
            if (!isNaN(C1) && C1 > 10) {
                NoError = false;
                if (!Cul.includes(i)) {
                    Cul.push(i);
                    Culprits.push(Data[i]["STUDENTS NAMES"]);
                }
            } else {
                if (isNaN(C1) && !"ABab".includes(C1.toString().toUpperCase())) {
                    NoError = false;
                    if (!Cul.includes(i)) {
                        Cul.push(i);
                        Culprits.push(Data[i]["STUDENTS' NAMES"]);
                    }
                }
            }
            if (!isNaN(C2) && C2 > 20) {
                NoError = false;
                if (!Cul.includes(i)) {
                    Cul.push(i);
                    Culprits.push(Data[i]["STUDENTS' NAMES"]);
                }
            } else {
                if (isNaN(C2) && !"ABab".includes(C2.toString().toUpperCase())) {
                    NoError = false;
                    if (!Cul.includes(i)) {
                        Cul.push(i);
                        Culprits.push(Data[i]["STUDENTS' NAMES"]);
                    }
                }
            }
            if (!isNaN(E1) && E1 > 70) {
                NoError = false;
                if (!Cul.includes(i)) {
                    Cul.push(i);
                    Culprits.push(Data[i]["STUDENTS' NAMES"]);
                }
            } else {
                if (isNaN(E1) && !"ABab".includes(E1.toString().toUpperCase())) {
                    NoError = false;
                    if (!Cul.includes(i)) {
                        Cul.push(i);
                        Culprits.push(Data[i]["STUDENTS' NAMES"]);
                    }
                }
            }
        }
        if (NoError) {
            console.log("No Error");
        } else {
            let Cul = Culprits.join(", ");
            setModal_Title("Error");
            setModal_Message(`There is/are Error(s) with scores of \n ${Cul}`);
            setButton_Title("Ok, I will Check!");
            setShow_Modal(true);
        }
        return NoError;
    };
    const ProcessFile = async (FileObject)=>{
        setMessage(`The system is processing the Deduction File submitted...`);
        // setshowProcessing(true);
        let ERows = [];
        let NewJsonArray = [];
        await (0,build.ExcelRenderer)(FileObject, (err, resp)=>{
            if (err) {
                console.log(err);
            } else {
                setCols(resp.cols);
                setRows(resp.rows);
                ERows = resp.rows;
            }
        });
        const keys = ERows[0];
        ERows.slice(1).map((rw)=>{
            let obj = {};
            rw.forEach((cell, index)=>{
                obj[keys[index]] = cell;
            });
            NewJsonArray.push(obj);
        });
        if (NewJsonArray[0]["SUBJECT"].toUpperCase() != pickedSubject.toUpperCase() || NewJsonArray[0]["SESSION"] != session || NewJsonArray[0]["TERM"].toUpperCase() != term.toUpperCase() || NewJsonArray[0]["CLASS"].toUpperCase() != claz.toUpperCase()) {
            (0,Notification/* DisplayNotification */.g)("Error", "This file cannot be uploaded because the uploaded students' properties did not match the Selected students' properties. Please Check the Session, Term, Class and Subject picked", "danger", "top-center", 10000);
        } else {
            if (CheckScoreValidity(NewJsonArray)) {
                // console.log(ConcernedStudents);
                // console.log(NewJsonArray);
                // iF ALL INPUTS ARE CORRECT, THEN DO THE FOLLOWING
                let ProcessedConcernedStudents = [];
                ConcernedStudents.forEach((element)=>{
                    const TreatedStudent = NewJsonArray.find((item)=>item["SID"] === element.StdNum && item["SESSION"].toString() === session.toString() && item["CLASS"] === claz && item["SUBJECT"] === pickedSubject);
                    // console.log(TreatedStudent);
                    if (TreatedStudent && TreatedStudent != undefined) {
                        let cat1 = TreatedStudent["1ST CA (10)"].toString().replace(/\s+/g, "");
                        let cat2 = TreatedStudent["2ND CA (20)"].toString().replace(/\s+/g, "");
                        let ex = TreatedStudent["EXAM (70)"].toString().replace(/\s+/g, "");
                        let ct1 = isNaN(cat1) ? 0 : parseFloat(cat1);
                        let ct2 = isNaN(cat2) ? 0 : parseFloat(cat2);
                        let x1 = isNaN(ex) ? 0 : parseFloat(ex);
                        let ts = ct1 + ct2 + x1;
                        let gmk = claz.includes("JS") ? GetJuniorGrade(ts) : GetSeniorGrade(ts);
                        element = {
                            ...element,
                            CA1Score: "AB".includes(cat1.toUpperCase()) ? "AB" : cat1,
                            CA2Score: "AB".includes(cat2.toUpperCase()) ? "AB" : cat2,
                            EXAMScore: "AB".includes(ex.toUpperCase()) ? "AB" : ex,
                            TotalScore: ts,
                            Grade: gmk.grade,
                            Remark: gmk.remark
                        };
                        ProcessedConcernedStudents.push(element);
                    } else {
                        console.log("Each Uploaded Details does not match Selected Details");
                    }
                });
                if (ProcessedConcernedStudents.length > 0) {
                    SaveAllResults(ProcessedConcernedStudents);
                // console.log(ProcessedConcernedStudents);
                } else {
                    (0,Notification/* DisplayNotification */.g)("Success", "This file cannot be uploaded because the uploaded students' properties did not match the Selected students' properties. Please Check the Session, Term, Class and Subject picked", "danger", "top-center", 7000);
                }
            }
        }
        setJSONdataArray(NewJsonArray);
    };
    const SaveAllResults = async (ConcStd)=>{
        setMessage(`The system is saving the students scores into the database`);
        setshowProcessing(true);
        // let Proceed = "true";
        // let AB = "ABab";
        // ConcernedStudents.forEach((element) => {
        //   if (
        //     element.BackGCA1 === "red" ||
        //     element.BackGCA2 === "red" ||
        //     element.BackGEXAM === "red"
        //   ) {
        //     Proceed = false;
        //   }
        // });
        let TheResultsDetails = {
            Session: session,
            Term: term,
            Claz: claz,
            Subject: pickedSubject,
            Results: ConcStd
        };
        let SaveTheScores = await (0,axioscall/* default */.Z)("save_all_results", TheResultsDetails);
        if (SaveTheScores === "Saved Successfully") {
            setdisplayStudents(false);
            setshowProcessing(false);
            (0,Notification/* DisplayNotification */.g)("Success", `The students scores have been succesfully ranked and saved`, "success", "top-center", 7000);
        }
    // } else {
    //   DisplayNotification(
    //     "Error",
    //     "Scores cannot be saved. Please check the scored highlighted in Red Colour for correction",
    //     "danger",
    //     "top-center",
    //     7000
    //   );
    // }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist.ReactNotifications, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                md: 12,
                lg: 12,
                sm: 12,
                xs: 12,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()), {
                            onSubmit: GetTheStudents,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                    className: "justify-content-around",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            md: 11,
                                            lg: 11,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "text-center h6",
                                                children: "Please fill in the details of the scores to be computed below"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            className: " ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Session/* default */.Z, {
                                                Session: session,
                                                setSession: setsession,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Term/* default */.Z, {
                                                Term: term,
                                                setTerm: setterm,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Class/* default */.Z, {
                                                Claz: claz,
                                                setClaz: setclaz,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Subjects/* default */.Z, {
                                                Subject: pickedSubject,
                                                setSubject: setpickedSubject,
                                                Disabled: !activateSelector,
                                                TheSubjects: LoadedSubjects
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                    className: "justify-content-around",
                                    children: [
                                        dataready && /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            className: "mt-2 text-left",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_html_table_to_excel/* default */.Z, {
                                                id: "exportbutton",
                                                className: "btn btn-sm btn-info",
                                                table: "ScoreSheet",
                                                filename: `${session.toUpperCase()} ${term.toUpperCase()} TERM ${claz.toUpperCase()} ${pickedSubject.toUpperCase()} SCORESHEET`.toUpperCase(),
                                                sheet: pickedSubject.toUpperCase(),
                                                buttonText: "Download Score Templates"
                                            })
                                        }),
                                        dataready && /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            className: "text-left",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()).Group, {
                                                controlId: "formfile",
                                                className: "mb-3 d-inline-block",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Label, {
                                                        style: {
                                                            color: "brown",
                                                            fontWeight: "bold"
                                                        },
                                                        children: "Upload Score Sheet"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                                        type: "file",
                                                        name: "Pix1",
                                                        value: FileDirectory,
                                                        onChange: (e)=>PickFile(e)
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                                    className: "d-flex justify-content-sm-around justify-content-md-end",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                        lg: 3,
                                        md: 3,
                                        sm: 11,
                                        xs: 11,
                                        className: "mt-2 text-right text-end mt-2 pt-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            variance: "info",
                                            type: "submit",
                                            disabled: !activateButton,
                                            children: "Load Students"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    displayStudents && /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                        className: "d-none",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                            md: 12,
                            lg: 12,
                            sm: 12,
                            xs: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                                striped: true,
                                bordered: true,
                                hover: true,
                                responsive: true,
                                id: "ScoreSheet",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "SN"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "SESSION"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "TERM"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "SUBJECT"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "CLASS"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "SID"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "STUDENTS' NAMES"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "1ST CA (10)"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "2ND CA (20)"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "text-center",
                                                    children: "EXAM (70)"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        children: ConcernedStudents.map((Student, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "text-center py-auto",
                                                        children: index + 1
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "py-auto",
                                                        children: session
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "py-auto",
                                                        children: term
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "py-auto",
                                                        children: pickedSubject
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "py-auto",
                                                        children: claz
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "py-auto",
                                                        children: Student.StdNum
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "py-auto",
                                                        children: Student.StdName
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "text-center py-auto",
                                                        children: Student.CA1Score
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "text-center py-auto",
                                                        children: Student.CA2Score
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "text-center py-auto",
                                                        children: Student.EXAMScore
                                                    })
                                                ]
                                            }, index))
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            Show_Modal && /*#__PURE__*/ jsx_runtime_.jsx(OK_Modal/* default */.Z, {
                title: Modal_Title,
                message: Modal_Message,
                ShowModal: Show_Modal,
                buttontitle: Button_Title,
                AfterEvent: AfterEvent,
                variant: "success",
                size: "sm"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Processing_Modal/* default */.Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const components_Import_Scores_File = (Import_Scores_File);

;// CONCATENATED MODULE: ./components/Inputs/InputTextWithoutLabel.jsx





const FormInputText = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Group, {
        className: "mb-0 d-inline-block",
        children: /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
            type: "text",
            value: props.TheValue,
            onChange: (e)=>props.GetTheValue(props.Index, e.target.value, props.Source),
            required: true,
            readOnly: props.readonly,
            style: {
                width: "90px",
                height: "35px",
                display: "inline-block",
                backgroundColor: props.BackGrd
            }
        })
    });
};
/* harmony default export */ const InputTextWithoutLabel = (FormInputText);

;// CONCATENATED MODULE: ./components/Inputs/Divisor_Select.jsx



const Divisor_Select = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()).Select, {
            value: props.Value,
            onChange: (e)=>props.GetTheValue(props.Index, e.target.value, props.Source),
            disabled: props.Disabled,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                    children: " Select"
                }),
                props.Data.map((cat, index)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                        value: cat,
                        children: cat
                    }, index))
            ]
        })
    });
};
/* harmony default export */ const Inputs_Divisor_Select = (Divisor_Select);

;// CONCATENATED MODULE: ./components/Enter_Scores.jsx





















const Enter_Scores = (props)=>{
    const [session, setsession] = (0,react_.useState)("Select");
    const [claz, setclaz] = (0,react_.useState)("Select");
    const [term, setterm] = (0,react_.useState)("Select");
    const [LoadedSubjects, setLoadedSubjects] = (0,react_.useState)([]);
    const [AllServerSubjects, setAllServerSubjects] = (0,react_.useState)([]);
    const [pickedSubject, setpickedSubject] = (0,react_.useState)("Select");
    const [activateSelector, setactivateSelector] = (0,react_.useState)(true);
    const [activateButton, setactivateButton] = (0,react_.useState)(false);
    const [ConcernedStudents, setConcernedStudents] = (0,react_.useState)([]);
    const [showProcessing, setshowProcessing] = (0,react_.useState)(false);
    const [displayStudents, setdisplayStudents] = (0,react_.useState)(false);
    const [Message, setMessage] = (0,react_.useState)("");
    const cookies = new (cjs_default())();
    (0,react_.useEffect)(()=>{
        const AllSubs = JSON.parse(props.Subjects);
        setAllServerSubjects(AllSubs);
    }, []);
    (0,react_.useEffect)(()=>{
        if (claz.includes("JS")) {
            setLoadedSubjects(GetClassSubjects("Junior"));
        } else {
            setLoadedSubjects(GetClassSubjects("Senior"));
        }
    }, [
        claz
    ]);
    (0,react_.useEffect)(()=>{
        console.log("Activating UseEffect...");
        const activateTheButton = ()=>{
            if (session != "Select" && claz != "Select" && pickedSubject != "Select" && term != "Select") {
                setactivateButton(true);
            } else {
                setactivateButton(false);
            }
        };
        setdisplayStudents(false);
        activateTheButton();
    }, [
        session,
        claz,
        term,
        pickedSubject
    ]);
    const GetClassSubjects = (clx)=>{
        let DisplayedSubjects = [];
        let AllRSub = AllServerSubjects.filter((el)=>el.subject_type === "All" || el.subject_type === clx);
        AllRSub.forEach((element)=>{
            DisplayedSubjects = [
                ...DisplayedSubjects,
                element.subject_name
            ];
        });
        return DisplayedSubjects;
    };
    const GetJuniorGrade = (sc)=>{
        let grd = "";
        let rmk = "";
        sc = parseFloat(sc);
        if (sc >= 0 && sc < 40) {
            grd = "F";
            rmk = "WEAK";
        }
        if (sc >= 40 && sc < 45) {
            grd = "E";
            rmk = "PASS";
        }
        if (sc >= 45 && sc < 50) {
            grd = "D";
            rmk = "PASS";
        }
        if (sc >= 50 && sc < 60) {
            grd = "C";
            rmk = "CREDIT";
        }
        if (sc >= 60 && sc < 70) {
            grd = "B";
            rmk = "GOOD";
        }
        if (sc >= 70 && sc <= 100) {
            grd = "A";
            rmk = "EXCELLENT";
        }
        let grdrmk = {
            grade: grd,
            remark: rmk
        };
        return grdrmk;
    };
    const GetSeniorGrade = (sc)=>{
        let grd = "";
        let rmk = "";
        sc = parseFloat(sc);
        if (sc >= 0 && sc < 40) {
            grd = "F9";
            rmk = "WEAK";
        }
        if (sc >= 40 && sc < 45) {
            grd = "E8";
            rmk = "PASS";
        }
        if (sc >= 45 && sc < 50) {
            grd = "D7";
            rmk = "PASS";
        }
        if (sc >= 50 && sc < 55) {
            grd = "C6";
            rmk = "CREDIT";
        }
        if (sc >= 55 && sc < 60) {
            grd = "C5";
            rmk = "CREDIT";
        }
        if (sc >= 60 && sc < 65) {
            grd = "C4";
            rmk = "CREDIT";
        }
        if (sc >= 65 && sc < 70) {
            grd = "B3";
            rmk = "GOOD";
        }
        if (sc >= 70 && sc < 75) {
            grd = "B2";
            rmk = "VERY GOOD";
        }
        if (sc >= 70 && sc <= 100) {
            grd = "A1";
            rmk = "DISTINCTION";
        }
        let grdrmk = {
            grade: grd,
            remark: rmk
        };
        return grdrmk;
    };
    const ScoreCheck = (scr, limit, AfStd, Sorc)=>{
        let AB = "ABab";
        let Error = "Error";
        let Msg = "";
        if (Sorc === "DIVISOR") {
            AfStd["Divisor"] = scr;
        } else {
            switch(Sorc){
                case "CA1":
                    Msg = "First CA Test";
                    break;
                case "CA2":
                    Msg = "Second CA Test";
                    break;
                case "EXAM":
                    Msg = "Exam";
                    break;
            }
            if (scr > limit && !isNaN(scr)) {
                (0,Notification/* DisplayNotification */.g)("Error", `${Msg} Score cannot be more than ${limit} Marks`, "danger", "top-center", 5000);
                AfStd[Sorc + "Score"] = "Error";
                AfStd["BackG" + Sorc] = "red";
            } else {
                if (Error.includes(scr)) {
                    AfStd["BackG" + Sorc] = "red";
                    AfStd[Sorc + "Score"] = scr;
                } else {
                    AfStd["BackG" + Sorc] = "white";
                    AfStd[Sorc + "Score"] = scr;
                }
            }
            let ca1score = "ABab".includes(AfStd.CA1Score) || "Error".includes(AfStd.CA1Score) || AfStd.CA1Score === "" ? 0 : AfStd.CA1Score;
            let ca2score = "ABab".includes(AfStd.CA2Score) || "Error".includes(AfStd.CA2Score) || AfStd.CA2Score === "" ? 0 : AfStd.CA2Score;
            let examscore = "ABab".includes(AfStd.EXAMScore) || "Error".includes(AfStd.EXAMScore) || AfStd.EXAMScore === "" ? 0 : AfStd.EXAMScore;
            AfStd.TotalScore = parseFloat(ca1score) + parseFloat(ca2score) + parseFloat(examscore);
            let GRDRMK = claz.includes("JS") ? GetJuniorGrade(AfStd.TotalScore) : GetSeniorGrade(AfStd.TotalScore);
            AfStd["Grade"] = GRDRMK.grade;
            AfStd["Remark"] = GRDRMK.remark;
        }
        return AfStd;
    };
    const UpdateRecords = (index, score, source)=>{
        let AB = "ABab";
        let Error = "Error";
        if (!isNaN(score) || AB.includes(score) || Error.includes(score)) {
            let TempScores = [
                ...ConcernedStudents
            ];
            let AffectedStudents = {
                ...TempScores[index]
            };
            switch(source){
                case "CA1":
                    AffectedStudents = ScoreCheck(score, 10, AffectedStudents, "CA1");
                    break;
                case "CA2":
                    AffectedStudents = ScoreCheck(score, 20, AffectedStudents, "CA2");
                    break;
                case "EXAM":
                    AffectedStudents = ScoreCheck(score, 70, AffectedStudents, "EXAM");
                    break;
                case "DIVISOR":
                    AffectedStudents = ScoreCheck(score, 0, AffectedStudents, "DIVISOR");
                    break;
            }
            TempScores[index] = AffectedStudents;
            setConcernedStudents(TempScores);
        }
    };
    const GetTheStudents = async (e)=>{
        e.preventDefault();
        setMessage(`The system is retrieving the students offering ${pickedSubject} in ${claz}`);
        let TeacherID = cookies.get("this_staff");
        let Category = cookies.get("this_category");
        setshowProcessing(true);
        let ScoreDetails = {
            Session: session,
            Term: term,
            Claz: claz,
            PickedSubject: pickedSubject,
            TeacherID: TeacherID ? TeacherID : "Nothing",
            Category: Category ? Category : "Nothing"
        };
        let RegisteredStudents = await (0,axioscall/* default */.Z)("get_subjects_registered_students", ScoreDetails);
        if (!RegisteredStudents.includes("Not Authorized")) {
            if (!RegisteredStudents.includes("Error")) {
                let AllNamesAndNumbers = [];
                RegisteredStudents = JSON.parse(RegisteredStudents);
                const AS = RegisteredStudents.AllStudents;
                AS.forEach((element)=>{
                    let divider = 1;
                    if (element.first_term_total_score && element.first_term_total_score > 0) {
                        divider++;
                    }
                    if (element.second_term_total_score && element.second_term_total_score > 0) {
                        divider++;
                    }
                    AllNamesAndNumbers = [
                        ...AllNamesAndNumbers,
                        {
                            StdName: `${element.surname} ${element.firstname} ${element.middlename}`,
                            CA1Score: element[term + "_term_ca_score1"],
                            CA2Score: element[term + "_term_ca_score2"],
                            EXAMScore: element[term + "_term_exam_score"],
                            TotalScore: element[term + "_term_total_score"] && element[term + "_term_total_score"] > 0 ? element[term + "_term_total_score"] : 0,
                            HighestScore: element[term + "_term_highest_score"] ? element[term + "_term_total_score"] : 0,
                            LowestScore: element[term + "_term_lowest_score"] ? element[term + "_term_total_score"] : 0,
                            AverageScore: element[term + "_term_average_score"],
                            Position: element[term + "_term_position"],
                            Grade: element[term + "_term_grade"],
                            Remark: element[term + "_term_remark"],
                            StdNum: element.student_id,
                            BackGCA1: "white",
                            BackGCA2: "white",
                            BackGEXAM: "white",
                            Divisor: divider
                        }
                    ];
                });
                setConcernedStudents(AllNamesAndNumbers);
                setdisplayStudents(true);
            } else {
                props.Notify(`There was a problem in retrieving the students. Please ensure that the students have been registered for ${pickedSubject} in ${session} Session`);
            }
        } else {
            props.Notify(`You are not an authorized teacher for the selected class. Please contact the Administrator`);
        }
        setshowProcessing(false);
    };
    const SaveAllResults = async ()=>{
        setMessage(`The system is saving the students scores into the database`);
        setshowProcessing(true);
        let Proceed = "true";
        let AB = "ABab";
        ConcernedStudents.forEach((element)=>{
            if (element.BackGCA1 === "red" || element.BackGCA2 === "red" || element.BackGEXAM === "red") {
                Proceed = false;
            }
        });
        if (Proceed) {
            let TheResultsDetails = {
                Session: session,
                Term: term,
                Claz: claz,
                Subject: pickedSubject,
                Results: ConcernedStudents
            };
            let SaveTheScores = await (0,axioscall/* default */.Z)("save_all_results", TheResultsDetails);
            if (SaveTheScores === "Saved Successfully") {
                setdisplayStudents(false);
                setshowProcessing(false);
                (0,Notification/* DisplayNotification */.g)("Success", `The students scores have been succesfully ranked and saved`, "success", "top-center", 7000);
            }
        } else {
            (0,Notification/* DisplayNotification */.g)("Error", "Scores cannot be saved. Please check the scored highlighted in Red Colour for correction", "danger", "top-center", 7000);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist.ReactNotifications, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                md: 12,
                lg: 12,
                sm: 12,
                xs: 12,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()), {
                            onSubmit: GetTheStudents,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                    className: "justify-content-around",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            md: 11,
                                            lg: 11,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "text-center h6",
                                                children: "Please fill in the details of the scores to be computed below"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            className: " ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Session/* default */.Z, {
                                                Session: session,
                                                setSession: setsession,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Term/* default */.Z, {
                                                Term: term,
                                                setTerm: setterm,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Class/* default */.Z, {
                                                Claz: claz,
                                                setClaz: setclaz,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Subjects/* default */.Z, {
                                                Subject: pickedSubject,
                                                setSubject: setpickedSubject,
                                                Disabled: !activateSelector,
                                                TheSubjects: LoadedSubjects
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                                    className: "d-flex justify-content-sm-around justify-content-md-end",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                        lg: 3,
                                        md: 3,
                                        sm: 11,
                                        xs: 11,
                                        className: "mt-2 text-right text-end my-2 py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            variance: "info",
                                            type: "submit",
                                            disabled: !activateButton,
                                            children: "Load Students"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    displayStudents && /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 12,
                                lg: 12,
                                sm: 12,
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                                    striped: true,
                                    bordered: true,
                                    hover: true,
                                    responsive: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "SN"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "STUDENTS' NAMES"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "1ST CA"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "2ND CA"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "EXAM"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "TOTAL"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "GRADE"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "POS"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "REMARK"
                                                    }),
                                                    term === "Third" && /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        className: "text-center",
                                                        children: "DIVISOR"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                            children: ConcernedStudents.map((Student, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: index + 1
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "py-auto",
                                                            children: Student.StdName
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(InputTextWithoutLabel, {
                                                                TheValue: Student.CA1Score,
                                                                GetTheValue: UpdateRecords,
                                                                Index: index,
                                                                Source: "CA1",
                                                                BackGrd: Student.BackGCA1
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(InputTextWithoutLabel, {
                                                                TheValue: Student.CA2Score,
                                                                GetTheValue: UpdateRecords,
                                                                Index: index,
                                                                Source: "CA2",
                                                                BackGrd: Student.BackGCA2
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(InputTextWithoutLabel, {
                                                                TheValue: Student.EXAMScore,
                                                                GetTheValue: UpdateRecords,
                                                                Index: index,
                                                                Source: "EXAM",
                                                                BackGrd: Student.BackGEXAM
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: Student.TotalScore
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: Student.Grade
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: Student.Position
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: Student.Remark
                                                        }),
                                                        term === "Third" && /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-center py-auto",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Inputs_Divisor_Select, {
                                                                Data: [
                                                                    3,
                                                                    2,
                                                                    1
                                                                ],
                                                                Index: index,
                                                                Value: Student.Divisor,
                                                                GetTheValue: UpdateRecords,
                                                                Source: "DIVISOR"
                                                            })
                                                        })
                                                    ]
                                                }, index))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                className: "text-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    variant: "success",
                                    className: "btn btn-bg",
                                    onClick: SaveAllResults,
                                    children: "SAVE ALL SCORES"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Processing_Modal/* default */.Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const components_Enter_Scores = (Enter_Scores);

// EXTERNAL MODULE: ./components/Cards/BorderedCard.jsx
var BorderedCard = __webpack_require__(40895);
;// CONCATENATED MODULE: ./components/Compute_Scores.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 













const Compute_Scores = (props)=>{
    const cookies = new (cjs_default())();
    const PCtx = (0,react_.useContext)(permission_context["default"]);
    (0,react_.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    const displayN = (msg)=>{
        (0,Notification/* DisplayNotification */.g)("Error", msg, "danger", "top-center", 7000);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
        className: "p-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist.ReactNotifications, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                md: 12,
                lg: 12,
                sm: 12,
                xs: 12,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                        className: "d-flex justify-content-center align-items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                            md: 12,
                            lg: 12,
                            sm: 12,
                            xs: 12,
                            className: "h-100",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(BorderedCard/* default */.Z, {
                                MyStyle: {
                                    width: "100%"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-center h3 mt-2",
                                    children: "SCORES COMPUTATION"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                            md: 12,
                            lg: 12,
                            sm: 12,
                            xs: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Tabs_default()), {
                                defaultActiveKey: "Upload",
                                id: "uncontrolled-tab-example",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                        eventKey: "Enter",
                                        title: "Enter Scores",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Enter_Scores, {
                                            Subjects: props.Subjects,
                                            Notify: displayN
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                        eventKey: "Upload",
                                        title: "Upload a File",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Import_Scores_File, {
                                            Subjects: props.Subjects,
                                            Notify: displayN
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Compute_Scores = (Compute_Scores);


/***/ }),

/***/ 67109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Subjects = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: props.TheSubjects,
        Label: "Subject",
        GetValue: props.setSubject,
        Color: "brown",
        Owner: props.Subject,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Subjects);


/***/ }),

/***/ 55607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Term = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: [
            "First",
            "Second",
            "Third"
        ],
        Label: "Term",
        GetValue: props.setTerm,
        Color: "brown",
        Owner: props.Term,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Term);


/***/ }),

/***/ 46735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _db_createtable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32201);
// import { NextResponse } from "next/server";

const GetAllSubjects = async ()=>{
    const connect = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_0__/* .connectDatabase */ .TR)();
    const select_sql = " SELECT subject_name, subject_type FROM registered_subjects ORDER BY subject_name ASC";
    const result = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_0__/* .selectTable */ .jM)(connect, select_sql);
    const theData = JSON.stringify(result);
    connect.end();
    return theData;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetAllSubjects);


/***/ }),

/***/ 50745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/Compute_Scores.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\Compute_Scores.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Compute_Scores = (__default__);
// EXTERNAL MODULE: ./app/api/getallsubjects.js
var getallsubjects = __webpack_require__(46735);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/computescores/page.js





const metadata = {
    title: "SCORES",
    description: "Compute Scores, Enter students scores, Scores computetion"
};
const getSubjects = async ()=>{
    const All_Subjects = await (0,getallsubjects/* default */.Z)();
    return All_Subjects;
};
const ComputeScores = async ()=>{
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    let Subjects = "{}";
    if (Stat) {
        Subjects = await getSubjects();
    }
    return Stat ? /*#__PURE__*/ jsx_runtime_.jsx(Compute_Scores, {
        Subjects: Subjects
    }) : /*#__PURE__*/ jsx_runtime_.jsx(Login_Page/* default */.ZP, {
        Redirection: true
    });
};
/* harmony default export */ const page = (ComputeScores);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,7515,1934,7341,1589,1767,4232,8505,8804,5528], () => (__webpack_exec__(70401)));
module.exports = __webpack_exports__;

})();