"use strict";
exports.id = 1109;
exports.ids = [1109];
exports.modules = {

/***/ 21109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89335);
/* harmony import */ var _db_createtable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32201);


const GetAllNames = async (request, response)=>{
    const connect = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabase */ .TR)();
    const select_sql = " SELECT student_id, surname, firstname, middlename, picture_directory FROM students_details";
    const result = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_1__/* .selectTable */ .jM)(connect, select_sql);
    let AllNames = [];
    let AllSIDs = [];
    let AllPixUrl = [];
    let AllStudentsDetails = {};
    result.forEach((Std)=>{
        AllNames = [
            ...AllNames,
            Std.surname + " " + Std.firstname + " " + Std.middlename
        ];
        AllSIDs = [
            ...AllSIDs,
            Std.student_id
        ];
        AllPixUrl = [
            ...AllPixUrl,
            Std.picture_directory
        ];
    });
    AllStudentsDetails = {
        AllStudentsNames: AllNames,
        AllSttudentsID: AllSIDs,
        AllPictureUrl: AllPixUrl
    };
    const theData = JSON.stringify(AllStudentsDetails);
    connect.end();
    return theData;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetAllNames);


/***/ })

};
;