exports.id = 588;
exports.ids = [588];
exports.modules = {

/***/ 42257:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 37806))

/***/ }),

/***/ 37806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Store_permission_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57948);
/* harmony import */ var rsuite__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(22350);
/* harmony import */ var rsuite_dist_rsuite_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(85546);
/* harmony import */ var rsuite_dist_rsuite_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rsuite_dist_rsuite_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _API_Call_axioscall__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(69294);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41315);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2129);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Subjects_Registration_module_css__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(98109);
/* harmony import */ var _Subjects_Registration_module_css__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_Subjects_Registration_module_css__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(29332);
/* harmony import */ var _SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(42634);
/* harmony import */ var _ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(24606);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(46887);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(44906);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(57237);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_bootstrap_Badge__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(76007);
/* harmony import */ var react_bootstrap_Badge__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Badge__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_11__);
/* __next_internal_client_entry_do_not_use__ default auto */ 




















const Subjects_Registration = (props)=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_11___default())();
    const [Message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [AllStds, setAllStds] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllStdsIds, setAllStdsIds] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllStdsPixUrls, setAllStdsPixUrls] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllSubjects, setAllSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllPreviouslyRegisteredSubjects, setAllPreviouslyRegisteredSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ActivePreviouslyRegisteredSubjects, setActivePreviouslyRegisteredSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [InactivePreviouslyRegisteredSubjects, setInactivePreviouslyRegisteredSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [SuggestedSubjects, setSuggestedSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [PickedStudentName, setPickedStudentName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [PickedStudentSid, setPickedStudentSid] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [PixUrl, setPixUrl] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [session, setsession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [claz, setclaz] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [activateSelector, setactivateSelector] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [activateButton, setactivateButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showProcessing, setshowProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [displaySubjects, setdisplaySubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [PickedSubjectsNumber, setPickedSubjectsNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [PickedSubjects, setPickedSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const TheColor = "brown";
    const PCtx = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_Store_permission_context__WEBPACK_IMPORTED_MODULE_2__["default"]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const activateTheButton = ()=>{
            if (session != "Select" && claz != "Select") {
                setactivateButton(true);
            } else {
                setactivateButton(false);
            }
            setPickedSubjects([]);
            setdisplaySubjects(false);
        };
        activateTheButton();
    }, [
        session,
        claz
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const AllNms = JSON.parse(props.Stds);
        setAllStds(AllNms.AllStudentsNames);
        setAllStdsIds(AllNms.AllSttudentsID);
        setAllStdsPixUrls(AllNms.AllPictureUrl);
        const AllSubs = JSON.parse(props.Subjects);
        setAllSubjects(AllSubs);
    }, []);
    const getStudentPicked = (snm)=>{
        setPickedStudentName(snm);
        setPickedStudentSid(AllStdsIds[AllStds.indexOf(snm)]);
        setPixUrl(AllStdsPixUrls[AllStds.indexOf(snm)]);
        if (AllStds.includes(snm)) {
            setactivateSelector(true);
        } else {
            setactivateSelector(false);
            setsession("Select");
            setclaz("Select");
            setPickedSubjects([]);
            setdisplaySubjects(false);
        }
    };
    const BringOutSubjects = async (e)=>{
        e.preventDefault();
        setMessage(`The system is loading ${PickedStudentName}'s subjects`);
        setshowProcessing(true);
        let AllAlreadyRegistered = [];
        let AlreadyRegistered = [];
        let InactiveAlreadyRegistered = [];
        let StData = {
            SID: PickedStudentSid,
            Session: session,
            Claz: claz
        };
        const AlreadyRegisteredString = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)("load_students_registered_subjects", StData);
        if (AlreadyRegisteredString != "Error") {
            const AR = JSON.parse(AlreadyRegisteredString);
            const AlreadyReg = AR.AlreadyRegistered;
            AlreadyReg.forEach((element)=>{
                AllAlreadyRegistered = [
                    ...AllAlreadyRegistered,
                    element.subject_name
                ];
                if (element.status === "Active") {
                    AlreadyRegistered = [
                        ...AlreadyRegistered,
                        element.subject_name
                    ];
                } else {
                    InactiveAlreadyRegistered = [
                        ...InactiveAlreadyRegistered,
                        element.subject_name
                    ];
                }
            });
            setAllPreviouslyRegisteredSubjects(AllAlreadyRegistered);
            setActivePreviouslyRegisteredSubjects(AlreadyRegistered);
            setPickedSubjects(AlreadyRegistered);
            setInactivePreviouslyRegisteredSubjects(InactiveAlreadyRegistered);
        }
        let SSub = [];
        if (claz.includes("JS")) {
            SSub = AllSubjects.filter((sub)=>sub.subject_type === "All" || sub.subject_type === "Junior");
        } else {
            SSub = AllSubjects.filter((sub)=>sub.subject_type === "All" || sub.subject_type === "Senior");
        }
        SSub = SSub.map((sj)=>({
                ...sj,
                status: AlreadyRegistered.includes(sj.subject_name) ? true : false
            }));
        var m = 0;
        var alrdpkd = [];
        SSub.forEach(async (element)=>{
            if (element.status) {
                m++;
                alrdpkd = [
                    ...alrdpkd,
                    element
                ];
            }
        });
        setPickedSubjectsNumber(m);
        setSuggestedSubjects(SSub);
        setdisplaySubjects(true);
        setshowProcessing(false);
    };
    const SaveRegisteredSubjects = async ()=>{
        setMessage(`The system is saving ${PickedStudentName}'s registered subjects`);
        setshowProcessing(true);
        let AddedSubjects = [];
        let DeletedSubjects = [];
        let RetainedSubjects = [];
        let InactiveMadeActive = [];
        RetainedSubjects = ActivePreviouslyRegisteredSubjects.filter((el)=>PickedSubjects.includes(el));
        InactiveMadeActive = PickedSubjects.filter((el)=>InactivePreviouslyRegisteredSubjects.includes(el));
        DeletedSubjects = ActivePreviouslyRegisteredSubjects.filter((el)=>!PickedSubjects.includes(el));
        AddedSubjects = PickedSubjects.filter((el)=>!AllPreviouslyRegisteredSubjects.includes(el));
        let RegisteredDetails = {
            SID: PickedStudentSid,
            Session: session,
            Claz: claz,
            RegisteredSubjects: PickedSubjects,
            AddedSubjects: AddedSubjects,
            DeletedSubjects: DeletedSubjects,
            RetainedSubjects: RetainedSubjects,
            InactiveMadeActive: InactiveMadeActive
        };
        let response = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)("save_registered_subjects", RegisteredDetails);
        if (response === "Saved Successfully") {
            setshowProcessing(false);
            (0,_Notification__WEBPACK_IMPORTED_MODULE_4__/* .DisplayNotification */ .g)("Success", PickedStudentName + "'s registered subjects saved succesfully!", "success", "top-center", 5000);
            setdisplaySubjects(false);
            setPickedStudentName("");
            setactivateSelector(false);
            setsession("Select");
            setclaz("Select");
        } else {
            if (response === "Failed woefully") {
                setshowProcessing(false);
                (0,_Notification__WEBPACK_IMPORTED_MODULE_4__/* .DisplayNotification */ .g)("Error", PickedStudentName + "'s has been registered before. You can only add or delete subjects or change the student's class under the Change Class Menu", "danger", "top-center", 7000);
            }
        }
    };
    const ChangeCheckboxStatus = (e, ind)=>{
        let val = e.target.checked;
        let newArray = [
            ...SuggestedSubjects
        ];
        let nj = {
            ...newArray[ind],
            status: val
        };
        newArray[ind] = nj;
        setSuggestedSubjects(newArray);
        if (val) {
            setPickedSubjectsNumber((prevPickedSubjectsNumber)=>prevPickedSubjectsNumber + 1);
            setPickedSubjects([
                ...PickedSubjects,
                SuggestedSubjects[ind].subject_name
            ]);
        } else {
            if (PickedSubjectsNumber > 0) {
                setPickedSubjectsNumber((prevPickedSubjectsNumber)=>prevPickedSubjectsNumber - 1);
                let sb = PickedSubjects.filter((s)=>s != SuggestedSubjects[ind].subject_name);
                setPickedSubjects(sb);
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_notifications_component__WEBPACK_IMPORTED_MODULE_5__.ReactNotifications, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                        md: 12,
                        lg: 12,
                        sm: 12,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                className: "justify-content-around",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                    md: 12,
                                    sm: 12,
                                    lg: 12,
                                    xs: 12,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "text-center",
                                        children: " Subject Registration"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default()), {
                                onSubmit: BringOutSubjects,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                        className: "justify-content-around",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                            lg: 6,
                                            md: 6,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default().Group), {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default().Label), {
                                                        style: {
                                                            color: "brown"
                                                        },
                                                        children: "Student's Name"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(rsuite__WEBPACK_IMPORTED_MODULE_17__/* .AutoComplete */ .Qc, {
                                                        data: AllStds,
                                                        value: PickedStudentName,
                                                        onChange: getStudentPicked,
                                                        onSelect: getStudentPicked,
                                                        style: {
                                                            border: "1px solid brown",
                                                            backgroundColor: "#b3ff66",
                                                            borderRadius: "3px"
                                                        }
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                        className: "justify-content-around",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                lg: 3,
                                                md: 3,
                                                sm: 11,
                                                xs: 11,
                                                className: "align-items-center text-center ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    Session: session,
                                                    setSession: setsession,
                                                    Disabled: !activateSelector
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                lg: 3,
                                                md: 3,
                                                sm: 11,
                                                xs: 11,
                                                className: "align-items-center text-center ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                    Claz: claz,
                                                    setClaz: setclaz,
                                                    Disabled: !activateSelector
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                lg: 3,
                                                md: 3,
                                                sm: 11,
                                                xs: 11,
                                                className: "text-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default().Label), {
                                                        style: {
                                                            color: props.Color,
                                                            fontWeight: "bold",
                                                            visibility: "hidden",
                                                            display: "block"
                                                        },
                                                        children: "Load Subject"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                        variance: "info",
                                                        type: "submit",
                                                        disabled: !activateButton,
                                                        children: "Load Subjects"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                            displaySubjects && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                className: "justify-content-around",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                    md: 12,
                                    lg: 12,
                                    sm: 12,
                                    xs: 12,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                            className: "justify-content-around",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                md: 12,
                                                lg: 12,
                                                sm: 12,
                                                xs: 12,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                    className: `text-center h6 mb-1  ${(_Subjects_Registration_module_css__WEBPACK_IMPORTED_MODULE_19___default().subjectCheckBox)}`,
                                                    children: [
                                                        "Please pick the courses to be offered by",
                                                        " ",
                                                        PickedStudentName
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default()), {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                    md: 9,
                                                                    lg: 9,
                                                                    xs: 12,
                                                                    sm: 12,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                                        children: SuggestedSubjects.map((sbj, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                                lg: 3,
                                                                                md: 3,
                                                                                sm: 11,
                                                                                xs: 11,
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_16___default().Check) // prettier-ignore
                                                                                , {
                                                                                    type: "checkbox",
                                                                                    label: sbj.subject_name,
                                                                                    checked: sbj.status ? sbj.status : false,
                                                                                    className: (_Subjects_Registration_module_css__WEBPACK_IMPORTED_MODULE_19___default().subjectCheckBox),
                                                                                    onChange: (e)=>ChangeCheckboxStatus(e, index)
                                                                                })
                                                                            }, index))
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                    md: 3,
                                                                    lg: 3,
                                                                    xs: 12,
                                                                    sm: 12,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                                        className: "justify-content-around",
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                            md: 6,
                                                                            lg: 6,
                                                                            xs: 12,
                                                                            sm: 12,
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                                                    src: PixUrl,
                                                                                    width: 100,
                                                                                    height: 120,
                                                                                    alt: "StudentID"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    className: (_Subjects_Registration_module_css__WEBPACK_IMPORTED_MODULE_19___default().DisplayedName),
                                                                                    children: PickedStudentName
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        className: "justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                md: 4,
                                                                lg: 4,
                                                                sm: 12,
                                                                xs: 12,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                    className: "h6",
                                                                    children: [
                                                                        "Number of registered subject =",
                                                                        " ",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Badge__WEBPACK_IMPORTED_MODULE_20___default()), {
                                                                            bg: "danger",
                                                                            children: PickedSubjectsNumber
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                md: 4,
                                                                lg: 4,
                                                                sm: 12,
                                                                xs: 12,
                                                                className: "text-right",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                                    variant: "success",
                                                                    className: "btn",
                                                                    onClick: SaveRegisteredSubjects,
                                                                    children: [
                                                                        "Save ",
                                                                        PickedSubjectsNumber,
                                                                        " Subjects"
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        Show: showProcessing,
                        message: Message,
                        variant: "success",
                        size: "sm"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Subjects_Registration);


/***/ }),

/***/ 98109:
/***/ ((module) => {

// Exports
module.exports = {
	"subjectCheckBox": "Subjects_Registration_subjectCheckBox__9Mipk",
	"DisplayedName": "Subjects_Registration_DisplayedName__JS8Wh"
};


/***/ }),

/***/ 46735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _db_createtable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32201);
// import { NextResponse } from "next/server";

const GetAllSubjects = async ()=>{
    const connect = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_0__/* .connectDatabase */ .TR)();
    const select_sql = " SELECT subject_name, subject_type FROM registered_subjects ORDER BY subject_name ASC";
    const result = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_0__/* .selectTable */ .jM)(connect, select_sql);
    const theData = JSON.stringify(result);
    connect.end();
    return theData;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetAllSubjects);


/***/ }),

/***/ 56431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\wamp64\www\next-app\components\Subjects_Registration.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;