exports.id = 8505;
exports.ids = [8505];
exports.modules = {

/***/ 39023:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57948));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22218));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82200))

/***/ }),

/***/ 36510:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 52987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 56926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 44282, 23))

/***/ }),

/***/ 57948:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PermissionContextProvider: () => (/* binding */ PermissionContextProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ PermissionContextProvider,default auto */ 




const PermissionContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    MenuClicked: false,
    setMenuClicked: ()=>{}
});
const PermissionContextProvider = (props)=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_3___default())();
    const [AxiosError, setAxiosError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [MenuClicked, setMenuClicked] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const context = {
        MenuClicked: MenuClicked,
        setMenuClicked: setMenuClicked
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PermissionContext.Provider, {
        value: context,
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PermissionContext);


/***/ }),

/***/ 26130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   X$: () => (/* binding */ roboto_serif),
/* harmony export */   g7: () => (/* binding */ pt_Sans),
/* harmony export */   js: () => (/* binding */ shadows_Into_Light),
/* harmony export */   kg: () => (/* binding */ rubik)
/* harmony export */ });
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_Rubik_arguments_subsets_latin_display_swap_variable_font_rubik_weight_300_400_500_600_variableName_rubik_init___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52598);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_Rubik_arguments_subsets_latin_display_swap_variable_font_rubik_weight_300_400_500_600_variableName_rubik_init___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_util_fonts_js_import_Rubik_arguments_subsets_latin_display_swap_variable_font_rubik_weight_300_400_500_600_variableName_rubik_init___WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_Roboto_Serif_arguments_subsets_latin_display_swap_variable_roboto_serif_weight_300_400_500_600_variableName_roboto_serif_init___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87835);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_Roboto_Serif_arguments_subsets_latin_display_swap_variable_roboto_serif_weight_300_400_500_600_variableName_roboto_serif_init___WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_util_fonts_js_import_Roboto_Serif_arguments_subsets_latin_display_swap_variable_roboto_serif_weight_300_400_500_600_variableName_roboto_serif_init___WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_Shadows_Into_Light_arguments_subsets_latin_display_swap_variable_shadows_Into_Light_weight_400_variableName_shadows_Into_Light_init___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35141);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_Shadows_Into_Light_arguments_subsets_latin_display_swap_variable_shadows_Into_Light_weight_400_variableName_shadows_Into_Light_init___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_util_fonts_js_import_Shadows_Into_Light_arguments_subsets_latin_display_swap_variable_shadows_Into_Light_weight_400_variableName_shadows_Into_Light_init___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_PT_Sans_arguments_subsets_latin_display_swap_variable_pt_Sans_init_weight_400_variableName_pt_Sans_init___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61961);
/* harmony import */ var next_font_google_target_css_path_app_util_fonts_js_import_PT_Sans_arguments_subsets_latin_display_swap_variable_pt_Sans_init_weight_400_variableName_pt_Sans_init___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_util_fonts_js_import_PT_Sans_arguments_subsets_latin_display_swap_variable_pt_Sans_init_weight_400_variableName_pt_Sans_init___WEBPACK_IMPORTED_MODULE_3__);




const rubik = (next_font_google_target_css_path_app_util_fonts_js_import_Rubik_arguments_subsets_latin_display_swap_variable_font_rubik_weight_300_400_500_600_variableName_rubik_init___WEBPACK_IMPORTED_MODULE_0___default().className);
const roboto_serif = (next_font_google_target_css_path_app_util_fonts_js_import_Roboto_Serif_arguments_subsets_latin_display_swap_variable_roboto_serif_weight_300_400_500_600_variableName_roboto_serif_init___WEBPACK_IMPORTED_MODULE_1___default().className);
const shadows_Into_Light = (next_font_google_target_css_path_app_util_fonts_js_import_Shadows_Into_Light_arguments_subsets_latin_display_swap_variable_shadows_Into_Light_weight_400_variableName_shadows_Into_Light_init___WEBPACK_IMPORTED_MODULE_2___default().className);
const pt_Sans = (next_font_google_target_css_path_app_util_fonts_js_import_PT_Sans_arguments_subsets_latin_display_swap_variable_pt_Sans_init_weight_400_variableName_pt_Sans_init___WEBPACK_IMPORTED_MODULE_3___default().className);






/***/ }),

/***/ 69294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21145);

const axioscall = async (url, dataFromCaller)=>{
    var response;
    await (0,axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`/api/${url}`, {
        method: "POST",
        data: {
            dataFromCaller
        },
        headers: {
            "Content-Type": "application/json"
        }
    }).then((dat)=>{
        let resp = dat.data;
        response = resp.message;
    }).catch((error)=>{
        response = "Error";
        console.log(error);
    });
    return response;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axioscall);


/***/ }),

/***/ 54797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _axioscall__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(69294);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_0__);


const LogoutFunction = async ()=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_0___default())();
    cookies.remove("this_staff", {
        path: "/"
    });
    cookies.remove("this_category", {
        path: "/"
    });
    cookies.remove("this_fullname", {
        path: "/"
    });
    cookies.remove("Logged", {
        path: "/"
    });
    let Ex = await (0,_axioscall__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)("loose_access", {
        WayOut: "WayOut"
    });
    console.log(Ex);
    if (Ex === "Success") {
        return true;
    } else {
        return false;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoutFunction);


/***/ }),

/***/ 40895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _BorderedCard_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68886);
/* harmony import */ var _BorderedCard_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_BorderedCard_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BorderedCard = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_BorderedCard_module_css__WEBPACK_IMPORTED_MODULE_2___default().cardcss),
        style: props.MyStyle,
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BorderedCard);


/***/ }),

/***/ 32182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _BorderedCardNoHover_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68635);
/* harmony import */ var _BorderedCardNoHover_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_BorderedCardNoHover_module_css__WEBPACK_IMPORTED_MODULE_2__);



const BorderedCardNoHover = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_BorderedCardNoHover_module_css__WEBPACK_IMPORTED_MODULE_2___default().cardcss),
        style: props.MyStyle,
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BorderedCardNoHover);


/***/ }),

/***/ 56801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2__);




const ButtonBackground = (props)=>{
    const buttonBackground = {
        backgroundColor: "#003152",
        boxShadow: "0 5px 8px 0 rgba(0, 0, 0, 0.2) "
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
            variance: "info",
            type: props.ButtonType,
            onClick: props.ButtonAction,
            style: {
                ...buttonBackground,
                ...props.ButtonCss
            },
            disabled: props.ButtonDisable,
            children: props.ButtonName
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonBackground);


/***/ }),

/***/ 31160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _FormInputText_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21306);
/* harmony import */ var _FormInputText_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_FormInputText_module_css__WEBPACK_IMPORTED_MODULE_3__);





const FormInputPassword = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
        className: "mb-0",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                style: {
                    color: props.Color,
                    fontWeight: "bold"
                },
                children: [
                    props.Label,
                    props.Compulsory && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_FormInputText_module_css__WEBPACK_IMPORTED_MODULE_3___default().CompulsoryItem),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("sup", {
                            children: "*"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                type: "password",
                value: props.Owner,
                onChange: (e)=>props.GetValue(e.target.value),
                name: "Password",
                required: true,
                readOnly: props.readonly
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormInputPassword);


/***/ }),

/***/ 97274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Login_Page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Store/permission-context.js
var permission_context = __webpack_require__(57948);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./components/API_Call/axioscall.js
var axioscall = __webpack_require__(69294);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/index.js
var dist = __webpack_require__(85307);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/theme.css
var theme = __webpack_require__(2129);
// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-free-solid/index.js
var fontawesome_free_solid = __webpack_require__(94496);
// EXTERNAL MODULE: ./node_modules/@fortawesome/react-fontawesome/index.js
var react_fontawesome = __webpack_require__(52196);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Row.js
var Row = __webpack_require__(44906);
var Row_default = /*#__PURE__*/__webpack_require__.n(Row);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Col.js
var Col = __webpack_require__(57237);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Form.js
var Form = __webpack_require__(39486);
var Form_default = /*#__PURE__*/__webpack_require__.n(Form);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Button.js
var Button = __webpack_require__(93780);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Card.js
var Card = __webpack_require__(97886);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./components/Cards/BorderedCardNoHover.jsx
var BorderedCardNoHover = __webpack_require__(32182);
// EXTERNAL MODULE: ./components/Login_Page.module.css
var Login_Page_module = __webpack_require__(80700);
var Login_Page_module_default = /*#__PURE__*/__webpack_require__.n(Login_Page_module);
// EXTERNAL MODULE: ./components/Inputs/FormInputPassword.jsx
var FormInputPassword = __webpack_require__(31160);
// EXTERNAL MODULE: ./components/Notification.jsx
var Notification = __webpack_require__(41315);
// EXTERNAL MODULE: ./node_modules/universal-cookie/cjs/index.js
var cjs = __webpack_require__(18284);
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);
;// CONCATENATED MODULE: ./components/Images/MainImage.jpg
/* harmony default export */ const MainImage = ({"src":"/_next/static/media/MainImage.d5013ed5.jpg","height":500,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAEAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAcEAABBQADAAAAAAAAAAAAAAACAAEDBBESISL/xAAVAQEBAAAAAAAAAAAAAAAAAAACBP/EABgRAAMBAQAAAAAAAAAAAAAAAAABAiED/9oADAMBAAIRAxEAPwCaFOvYkPlEIvEHlwbM7ZERKJTnUTdapVjP/9k=","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./components/MenuDisplayPage.jsx + 10 modules
var MenuDisplayPage = __webpack_require__(77253);
// EXTERNAL MODULE: ./components/ModalsAndAlerts/Processing_Modal.jsx
var Processing_Modal = __webpack_require__(24606);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./app/util/fonts.js
var fonts = __webpack_require__(26130);
;// CONCATENATED MODULE: ./components/Login_Page.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

























const Login_Page = (props)=>{
    const [TeacherID, setTeacherID] = (0,react_.useState)("");
    const [Gateway, setGateway] = (0,react_.useState)("");
    var CryptoJS = __webpack_require__(87683);
    const router = (0,navigation.useRouter)();
    const [Saving, setSaving] = (0,react_.useState)(false);
    const [showProcessing, setshowProcessing] = (0,react_.useState)(false);
    const [loggedIn, setloggedIn] = (0,react_.useState)(false);
    const [Message, setMessage] = (0,react_.useState)("");
    const cookies = new (cjs_default())();
    const TheColor = "#400000";
    const PCtx = (0,react_.useContext)(permission_context["default"]);
    (0,react_.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    const buttonBackground = {
        backgroundColor: "#003152",
        boxShadow: "0 5px 8px 0 rgba(0, 0, 0, 0.2) "
    };
    const GetTeacherID = (str)=>{
        setTeacherID(CapitalizeFirstLetter(str));
    };
    const CapitalizeFirstLetter = (str)=>{
        return str != "" ? str[0].toUpperCase() + str.slice(1).toLowerCase() : "";
    };
    const LoginUser = async (e)=>{
        e.preventDefault();
        setMessage(`The system is authenticating you...`);
        setshowProcessing(true);
        let WayGate = CryptoJS.AES.encrypt(Gateway, "143tonybridget").toString();
        let LoginDetails = {
            TeacherID: TeacherID,
            Gateway: WayGate
        };
        let Ac = await (0,axioscall/* default */.Z)("get_access", LoginDetails);
        console.log(Ac);
        let Accessor = JSON.parse(Ac);
        let logstatus = Accessor.LogStatus;
        // console.log(Accessor.Access);
        // var bytes = CryptoJS.AES.decrypt(Accessor.Access, "143tonybridget");
        // var Allowance = bytes.toString(CryptoJS.enc.Utf8);
        setshowProcessing(false);
        if (logstatus) {
            let d = new Date();
            d.setTime(d.getTime() + 720 * 60 * 1000);
            cookies.set("this_staff", TeacherID, {
                path: "/",
                expires: d
            });
            cookies.set("this_category", Accessor.Category, {
                path: "/",
                expires: d
            });
            cookies.set("this_fullname", Accessor.Username, {
                path: "/",
                expires: d
            });
            cookies.set("Logged", true, {
                path: "/",
                expires: d
            });
            window.location.reload(true);
            (0,Notification/* DisplayNotification */.g)("Success", `Welcome ${Accessor.Username}, APPLAUSE wishes you an enjoyable moment with the application. Contact the Administrator in case you face any challenge `, "success", "top-center", 7000);
        } else {
            (0,Notification/* DisplayNotification */.g)("Error", `Incorrect Username and Password. Please check the username and password entered and try again or contact the Administrator `, "danger", "top-center", 7000);
        }
    };
    (0,react_.useEffect)(()=>{
        if (props.Redirection) {
            (0,Notification/* DisplayNotification */.g)("Error", `Oops!!! Your Session has expired, Please login with your Username and Password `, "danger", "top-center", 7000);
        }
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist.ReactNotifications, {}),
            /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                    md: 12,
                    lg: 12,
                    sm: 12,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                            className: "justify-content-around align-items-center border border-danger",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                className: "text-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: ` ${(Login_Page_module_default()).Softname} ${fonts/* roboto_serif */.X$}`,
                                    children: "Result Processing & Production Portal"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                            className: (Login_Page_module_default()).MainRow,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                    md: 7,
                                    lg: 7,
                                    sm: 7,
                                    className: `${(Login_Page_module_default()).MainImg} h-100`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: MainImage,
                                        alt: "Main Image"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                    md: 5,
                                    sm: 12,
                                    xs: 12,
                                    className: (Login_Page_module_default()).formCol,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                                        className: ` justify-content-around align-items-center h-100 ${(Login_Page_module_default()).FormMainRow}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            md: 9,
                                            sm: 10,
                                            xs: 10,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                                                style: {
                                                    backgroundColor: "rgba(255, 255, 255, 0.5) "
                                                },
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()).Body, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                            className: "h2 text-center",
                                                            style: {
                                                                fontFamily: "Times New Roman"
                                                            },
                                                            children: "WELCOME TO APPLAUSE RESPAPP!"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                            className: "text-center",
                                                            children: "Please login with your Username and Password"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Form_default()), {
                                                            onSubmit: LoginUser,
                                                            autoComplete: "false",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                                        md: 12,
                                                                        sm: 12,
                                                                        xs: 12,
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: " mx-md-5 my-3 m-sm-2 p-4",
                                                                            style: {
                                                                                boxShadow: "10px 10px 5px rgba(68, 68, 68, 0.6)",
                                                                                border: "2px groove #800000"
                                                                            },
                                                                            children: [
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                    className: "input-group",
                                                                                    style: {
                                                                                        boxShadow: "5px 5px #b1b1b1"
                                                                                    },
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                            className: "input-group-prepend",
                                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                                id: "basic-addon",
                                                                                                className: `${(Login_Page_module_default()).AllBgColor} ${"input-group-text"}`,
                                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                                                                                    icon: fontawesome_free_solid.faUserAlt,
                                                                                                    style: {
                                                                                                        color: "white"
                                                                                                    }
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "text",
                                                                                            className: "form-control",
                                                                                            placeholder: "Your Username?",
                                                                                            name: "Username",
                                                                                            value: TeacherID,
                                                                                            "aria-label": "Username",
                                                                                            onChange: (e)=>GetTeacherID(e.target.value),
                                                                                            onBlur: (e)=>GetTeacherID(e.target.value),
                                                                                            required: true,
                                                                                            autoComplete: "off",
                                                                                            style: {
                                                                                                borderRadius: "0px"
                                                                                            }
                                                                                        })
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                    className: "input-group mt-3",
                                                                                    style: {
                                                                                        boxShadow: "5px 5px #b1b1b1"
                                                                                    },
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                            className: "input-group-prepend",
                                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                                id: "basic-addon",
                                                                                                className: `${(Login_Page_module_default()).AllBgColor} ${"input-group-text"}`,
                                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                                                                                    icon: fontawesome_free_solid.faKey,
                                                                                                    style: {
                                                                                                        color: "white"
                                                                                                    }
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "password",
                                                                                            className: "form-control",
                                                                                            name: "gateway",
                                                                                            placeholder: "Password",
                                                                                            "aria-label": "Password",
                                                                                            autoComplete: "off",
                                                                                            onChange: (e)=>setGateway(e.target.value),
                                                                                            onBlur: (e)=>setGateway(e.target.value),
                                                                                            "aria-describedby": "basic-addon",
                                                                                            required: true,
                                                                                            style: {
                                                                                                borderRadius: "0px"
                                                                                            }
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                                        md: 12,
                                                                        sm: 12,
                                                                        xs: 12,
                                                                        className: "align-items-right",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                                                                            className: "d-flex justify-content-end  p-0",
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                                                                md: 4,
                                                                                sm: 4,
                                                                                xs: 4,
                                                                                className: "m-0 pr-1  text-end",
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                                                    type: "submit",
                                                                                    className: "btn btn-danger mt-3",
                                                                                    variant: "danger",
                                                                                    style: {
                                                                                        backgroundColor: "brown"
                                                                                    },
                                                                                    children: "Login"
                                                                                })
                                                                            })
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Processing_Modal/* default */.Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const components_Login_Page = (Login_Page);


/***/ }),

/***/ 77253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_MenuDisplayPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Store/permission-context.js
var permission_context = __webpack_require__(57948);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Container.js
var Container = __webpack_require__(46887);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Row.js
var Row = __webpack_require__(44906);
var Row_default = /*#__PURE__*/__webpack_require__.n(Row);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Col.js
var Col = __webpack_require__(57237);
// EXTERNAL MODULE: ./components/MenuTemplate.module.css
var MenuTemplate_module = __webpack_require__(85954);
var MenuTemplate_module_default = /*#__PURE__*/__webpack_require__.n(MenuTemplate_module);
;// CONCATENATED MODULE: ./components/Images/homepicture.png
/* harmony default export */ const homepicture = ({"src":"/_next/static/media/homepicture.7915dbb4.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAV1BMVEVMaXHj1uT/1DX7rjD4sjf3ewrftHj/omDimjL/wTP902PY2PLmzarxtWPciC/wsD3ilz//qDzTuZ7/wDTY0ezh2Nj5tj73vUv/jijm3O7/3zj7zFD/4aHrxQN3AAAAGnRSTlMAWv2VaA7+A/79+x2Dqcr6yET9y/n+MecZ/oev38gAAAAJcEhZcwAADnQAAA50AWsks9YAAAA/SURBVHicBcEFAsAgDACxQ0aLzA3Z/9+5BITqfDYw+bfbktnPcadRYO1HS/EBteH6HILG0OYKaNyMACxeEIEfYmUCd2ghMGIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/Cards/BorderedCard.jsx
var BorderedCard = __webpack_require__(40895);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./app/util/fonts.js
var fonts = __webpack_require__(26130);
;// CONCATENATED MODULE: ./components/MenuTemplate.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









const MenuTemplate = (props)=>{
    const [isHover, setisHover] = (0,react_.useState)(false);
    const [Menu, setMenu] = (0,react_.useState)(props.Menu);
    const changeBg = ()=>{
        setisHover(true);
    };
    const changeBg2 = ()=>{
        setisHover(false);
    };
    const ExFunc = (e, tt)=>{
        if (tt === "Log Out") {
            e.preventDefault();
            console.log("I am Exiting");
            props.Ex();
        }
    };
    const DCss = Menu.IsReal ? {
        visibility: "visible"
    } : {
        visibility: "hidden"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(BorderedCard/* default */.Z, {
        MyStyle: {
            ...DCss,
            padding: "0px",
            height: "150px"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: Menu.link,
            className: (MenuTemplate_module_default()).theLinks,
            onClick: (e)=>ExFunc(e, Menu.Title),
            children: /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                className: (MenuTemplate_module_default()).TemplateDimension,
                onMouseOver: changeBg,
                onMouseLeave: changeBg2,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                    md: 12,
                    sm: 12,
                    lg: 12,
                    xs: 12,
                    className: "h-100",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                        className: "justify-content-center align-items-center h-100",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 4,
                                lg: 4,
                                sm: 4,
                                xs: 4,
                                className: "text-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: Menu.Icon,
                                    width: 90,
                                    height: 90,
                                    alt: "Menu Images"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 8,
                                lg: 8,
                                sm: 8,
                                xs: 8,
                                className: isHover ? `d-flex h-100 justify-content-center align-items-center ${(MenuTemplate_module_default()).TitleColumnHover}` : `d-flex h-100 justify-content-center align-items-center ${(MenuTemplate_module_default()).TitleColumn}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: `h4 text-center ${(MenuTemplate_module_default()).TitleText} ${fonts/* roboto_serif */.X$}`,
                                    children: Menu.Title.toUpperCase()
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const components_MenuTemplate = (MenuTemplate);

;// CONCATENATED MODULE: ./components/Images/score.png
/* harmony default export */ const score = ({"src":"/_next/static/media/score.d6302969.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAWlBMVEV1NoZuH27/zaBnMYzLd3nIz+exdpSqcJScQmuUP2xVNJ/Rgn/mo5BXOJJFVq3V1uGpXn60eJKrXnycQ3LWnJX/17OxZ4CintLQkI6xqM60h5apnsmWk87/5r86W1y0AAAAFnRSTlMxMP40+v79+iYzDPj7Sqv++/H9Mf78WacIsQAAAAlwSFlzAAAPRQAAD0UBxeoB7wAAAENJREFUeJwFwQcCgCAMBLBjb3C2BfX/3zRBRuu9IcPYspZYA1W1vr+qACuXSIk4Azt+Q0IM7Cb7hLjPMR+fgI2I6MAPbXYDVCxfPaIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/teacherreg.png
/* harmony default export */ const teacherreg = ({"src":"/_next/static/media/teacherreg.88f511f2.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAclBMVEVMaXEWDQxniJPj6+4iKTETHSUbHydIgpkRCQUSJCtOi6L0+/15ufw2YGn87eeIvvyVscC60N02V2Z7i5m8opH/0rJlfYu4xs5tgYVYgpBXiZuv0fWWqdSx6v2R1/yy4POh2e6fz+aFlaT5wJeBi5DXx71F3KOPAAAAHXRSTlMAcvz+4WbJulRFuvr+u/36v/y7fvz8fr/7/v///oRgOdEAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABFSURBVHicBcGFAcAgEASwQx+oe9H6/is2AdZ35/cE2O2bxdVbUF4eMZwEKinF9iC40tWxyg5j8N7z0MAwo7VhFoCSUgE/ojMD1KUZ/GwAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/teacher.png
/* harmony default export */ const teacher = ({"src":"/_next/static/media/teacher.d1af6d2e.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAaVBMVEVMaXFgQ0NVRUI8QVk/OT09MDReUVJrWlhQQURcZGZbS0xeTU9tXFw5MDRLhV9WZmQyYkpDRkdVXXdcZGSbo6xkaHBMVlcAAAB3Z2V4ZWFZaWc3W0YnSDxkdHCKe3c6aDopUTLjw7iggoDp4hbVAAAAGHRSTlMABHn8XYL9/suv7pKhOuDr3tz4wf56vQzo1PyKAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAQ0lEQVR4nAXBhQHAIBAAsaPIY3V32X/IJpDFhnOrmePnp+doIL8p3HsFxpmxbwNp1WthPcRFLyIGnAyXL1FY10mB4gd/1wMIMPN+QwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/registration.png
/* harmony default export */ const registration = ({"src":"/_next/static/media/registration.82fee9de.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAbFBMVEWDnaZHRUU2EhwUEh+CnaiNqbNabnt3jpVei6tMaXFIaYR7IR8FGDaOqrV7Y1+dbV5ojaeMg3gAAABGERqXHh1hhqVsLy2YtsKevMmcpqOry9eHo608XHZjd39WaG+LnaGYkpCyn5NliagxVXicPza/AAAAF3RSTlO9Y8SS/f3GwvMA/sBM/P39/P0cw776dcI19zQAAAAJcEhZcwAADsQAAA7EAZUrDhsAAABFSURBVHicHchHEoAgEATAQSSa48KK+f9/tOTW1RApef/WDiYOkZ8fdxdpkSvM1Z5siwqgcgt2mjMoz9EE7qWA3pUiPboPmGsD7haaXzEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/broadsheet.png
/* harmony default export */ const broadsheet = ({"src":"/_next/static/media/broadsheet.6f150aa4.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEVoaWlJaoJwMzE8ZIBHUWFVU1NzdXUbKzMZIiadoaSMcXB4WFcQHCMIDQ0RGSKre3l+XShPT09sUlAwV3Nqbm+VPTlhfJB+goImS2atlpaFg4B2cG2zucBcVkODYSujdiqhdCqNazMrKy6NkJBxcHCFh4prTEtXkLrnpTh2oLXBAAAAI3RSTlPW2Je8MtX7UQrz/v48Hlj+gbHV1Pya9cOm9J2j75q6oqevOZdn/wwAAAAJcEhZcwAADsQAAA7EAZUrDhsAAABJSURBVHicFcZVEoAgAAXAR0kLdtdg3f+Ejvu1UM5LHncFn+eTPt4N0kmtlzWCNjSEYeYojb2tGRWQsjp1Pf9zXu3DUEAIUhH2AZKjA/29Ee9QAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/subjects.png
/* harmony default export */ const subjects = ({"src":"/_next/static/media/subjects.db8383c9.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEW2jFqcaVdMmQCbQUBoY0+OucdxVVaIcXdBDguVwc+gcWWKWFSmh1yUrblQaXh0g1CSpXytwmemuGKdsFuWZFSvu4OfsGeVqlLSp2SZsWetkFh/bXN/qrauVFSlT0upbmykv4iFYmWesXuTamPIl2+nc1q5zpvcuH3Cl10zcamrAAAAIHRSTlP9/QXdQ/2Q/hn+vY6O/Wgjwf3059DQ2XL9l7+QkM3o9xrmxhsAAAAJcEhZcwAACxMAAAsTAQCanBgAAABISURBVHicHcZVEoAgAAXAJyBtdxPW/U/ojPu1kJIwLgsGrQmPeRmwnXPrM1eBnuPllatBgUSkocH+x/U4njcKdXcw1pplnYYPj/8EXKYh4mgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/result.png
/* harmony default export */ const result = ({"src":"/_next/static/media/result.110bbbbd.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAP1BMVEVxGADAwMCwcHGqVVWKenGlkIKMa1WjiXehi3zJyMiWe25ZOiykV1jbtkh4VRbJnR/MztDa3+KFn7m4pXl+l7PLkYd2AAAAEHRSTlMO/fsD7/Hr/vD+7zn6/lW/uHDZLwAAAAlwSFlzAAB2HAAAdhwBp8J46gAAADlJREFUeJw1yEEOgCAMAMFVhFIQWsD/v9VEw20yhNrNeg1QVmurAHHc54gbGbimHv7hcf2xJ4mIJF5P9wID2Tf6LgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Images/logout.png
/* harmony default export */ const logout = ({"src":"/_next/static/media/logout.c6db3cd8.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAYFBMVEVMaXGS3AA6Pj80PUY2STZNRjdvxA0zOED1jQT+kAD6lAaU0ASB0QE4ODxhfyV1uAlXXmIpNEHWgxbyjQZNRDVZSTP9jwD/kgD+kQD/jgD9lwD/mAAtNkVGXzZglxqvfTfJ8OuoAAAAG3RSTlMAdP7+BP0Kbfy7/TfnP5DR/Jv8ufmggkTKIrz7K8LDAAAACXBIWXMAAAsYAAALGAGJqbUQAAAARElEQVR4nGMQlhdgZmJnYGHglBZikoEwOFhl+Ri5wQw5fh5GBk4uDhEZdjY2BilpDlZmkBoxaS5RQV4GBgYGcQlJEAUAbSUC6XEb1nkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/universal-cookie/cjs/index.js
var cjs = __webpack_require__(18284);
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);
// EXTERNAL MODULE: ./components/MenuDisplayPage.module.css
var MenuDisplayPage_module = __webpack_require__(63682);
var MenuDisplayPage_module_default = /*#__PURE__*/__webpack_require__.n(MenuDisplayPage_module);
// EXTERNAL MODULE: ./components/Notification.jsx
var Notification = __webpack_require__(41315);
// EXTERNAL MODULE: ./node_modules/react-notifications-component/dist/index.js
var dist = __webpack_require__(85307);
// EXTERNAL MODULE: ./components/API_Call/exit.js
var exit = __webpack_require__(54797);
// EXTERNAL MODULE: ./components/ModalsAndAlerts/OK_Modal.jsx
var OK_Modal = __webpack_require__(41129);
;// CONCATENATED MODULE: ./components/MenuDisplayPage.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






















const MenuDisplayPage = ()=>{
    const cookies = new (cjs_default())();
    const logged = cookies.get("Logged");
    const router = (0,navigation.useRouter)();
    const [Modal_Message, setModal_Message] = (0,react_.useState)("");
    const [Show_Modal, setShow_Modal] = (0,react_.useState)(false);
    const [Modal_Title, setModal_Title] = (0,react_.useState)("");
    const [Button_Title, setButton_Title] = (0,react_.useState)("");
    const PCtx = (0,react_.useContext)(permission_context["default"]);
    (0,react_.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    const [MenuItems, setMenuItems] = (0,react_.useState)([
        {
            Title: "New Student Registration",
            Icon: registration,
            link: "/studentregistration",
            IsReal: true
        },
        {
            Title: "New Staff Registration",
            Icon: teacherreg,
            link: "/teachersregistration",
            IsReal: true
        },
        {
            Title: "Subjects Registration",
            Icon: subjects,
            link: "/subjectsregistration",
            IsReal: true
        },
        {
            Title: "Scores Computation",
            Icon: score,
            link: "/computescores",
            IsReal: true
        },
        {
            Title: "Class Teacher's Work",
            Icon: teacher,
            link: "/computereports",
            IsReal: true
        },
        {
            Title: "View Report Sheet",
            Icon: result,
            link: "/displayresults",
            IsReal: true
        },
        {
            Title: "View Broad Sheet",
            Icon: broadsheet,
            link: "/displaybroadsheet",
            IsReal: true
        },
        {
            Title: "Log Out",
            Icon: logout,
            link: "#",
            IsReal: true
        }
    ]);
    (0,react_.useEffect)(()=>{
        let AM = [
            ...MenuItems
        ];
        let MenuRemains = 3 - AM.length % 3;
        if (MenuRemains > 0) {
            let DummyMenu = {
                Title: "Dummy",
                Icon: homepicture,
                link: "",
                IsReal: false
            };
            for(var x = 0; x < MenuRemains; x++){
                AM = [
                    ...AM,
                    DummyMenu
                ];
            }
            setMenuItems(AM);
        }
    }, []);
    const AfterEvent = ()=>{
        window.location.reload(true);
    };
    const ExitFunction = async ()=>{
        if (await (0,exit/* default */.Z)()) {
            setModal_Title("Success");
            setModal_Message("You have successfully logged out of the system. Do have a wonderful day, Bye");
            setButton_Title("Ok, Bye");
            setShow_Modal(true);
        } else {
            (0,Notification/* DisplayNotification */.g)("Error", `Error in logging out. Please contact the Admin `, "danger", "top-center", 7000);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
        fluid: true,
        className: "p-0 m-0",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist.ReactNotifications, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                className: "justify-content-around",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                        md: 12,
                        lg: 12,
                        sm: 12,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
                            className: "justify-content-around",
                            children: MenuItems.map((menu, index)=>/*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                    md: 4,
                                    lg: 4,
                                    xs: 12,
                                    sm: 12,
                                    className: (MenuDisplayPage_module_default()).EachMenuCol,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_MenuTemplate, {
                                        Menu: menu,
                                        Ex: ExitFunction
                                    })
                                }, index))
                        })
                    }),
                    Show_Modal && /*#__PURE__*/ jsx_runtime_.jsx(OK_Modal/* default */.Z, {
                        title: Modal_Title,
                        message: Modal_Message,
                        ShowModal: Show_Modal,
                        buttontitle: Button_Title,
                        AfterEvent: AfterEvent,
                        variant: "success",
                        size: "sm"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_MenuDisplayPage = (MenuDisplayPage);


/***/ }),

/***/ 41129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7883);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__);




const OK_Modal = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default()), {
            show: props.ShowModal,
            onHide: props.AfterEvent,
            backdrop: "static",
            keyboard: false,
            size: props.size,
            style: {
                backgroundColor: "212733"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Header), {
                    closeButton: true,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Title), {
                        children: props.title
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Body), {
                    children: props.message
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Footer), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                        variant: "secondary",
                        onClick: props.AfterEvent,
                        children: "Close"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OK_Modal);


/***/ }),

/***/ 24606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7883);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44906);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57237);
/* harmony import */ var react_loading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75402);
/* harmony import */ var react_loading__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_loading__WEBPACK_IMPORTED_MODULE_2__);







const Processing_Modal = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default()), {
            show: props.Show,
            onHide: props.AfterEvent,
            backdrop: "static",
            keyboard: false,
            size: props.size,
            style: {
                backgroundColor: "212733"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default().Header), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default().Title), {
                        className: "small",
                        children: "Please wait..."
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_3___default().Body), {
                    className: "pr-2",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_4___default()), {
                        className: "justify-content-around pr-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                md: 4,
                                lg: 4,
                                sm: 4,
                                xs: 4,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    type: "bars",
                                    color: "brown",
                                    height: "40%",
                                    width: "70%"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                md: 8,
                                lg: 8,
                                sm: 8,
                                xs: 8,
                                style: {
                                    backgroundColor: "brown",
                                    color: "white",
                                    fontSize: "11px",
                                    fontStyle: "Times New Roman",
                                    padding: "10px",
                                    borderRadius: "3px"
                                },
                                children: props.message
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Processing_Modal);


/***/ }),

/***/ 41315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ DisplayNotification)
/* harmony export */ });
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_0__);

const DisplayNotification = (title, message, type, position, duration)=>{
    react_notifications_component__WEBPACK_IMPORTED_MODULE_0__.Store.addNotification({
        title: title,
        message: message,
        type: type,
        insert: "top",
        container: position,
        animationIn: [
            "animate__animated",
            "animate__fadeIn"
        ],
        animationOut: [
            "animate__animated",
            "animate__fadeOut"
        ],
        dismiss: {
            duration: duration,
            onScreen: true
        }
    });
};



/***/ }),

/***/ 82200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97886);
/* harmony import */ var react_bootstrap_Card__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Card__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44906);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57237);
/* harmony import */ var _TheFooter_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12201);
/* harmony import */ var _TheFooter_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_TheFooter_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ default auto */ 





const TheFooter = ()=>{
    const [FooterDetails, setFooterDetails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            header: "ABOUT US",
            body: "Our mission is to provide a supportive and inclusive learning environment that empowers students to achieve academic excellence, develop social responsibility, and become innovative leaders who positively impact their communities."
        },
        {
            header: "OUR ADDRESS",
            body: "Opp. Old Oyo National Park, Isokun, Oyo"
        },
        {
            header: "CONTACT US",
            body: "PHONE NUMBERS: 08033824233"
        },
        {
            header: " OUR SOFTWARE DEVELOPER",
            body: "APPLAUSE INFOTECH",
            tel: "TELEPHONE:08033824233",
            email: "EMAIL:Upmosttony@gmail.com"
        }
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_2___default()), {
        className: (_TheFooter_module_css__WEBPACK_IMPORTED_MODULE_3___default().Hide4Print),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_4__["default"], {
            md: 12,
            sm: 12,
            xs: 12,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Card__WEBPACK_IMPORTED_MODULE_5___default()), {
                style: {
                    backgroundColor: "#d9ffff"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Card__WEBPACK_IMPORTED_MODULE_5___default().Body), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_2___default()), {
                        children: FooterDetails.map((ft, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                md: 3,
                                sm: 12,
                                xs: 12,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: (_TheFooter_module_css__WEBPACK_IMPORTED_MODULE_3___default().FootHeader),
                                        style: {
                                            color: "brown"
                                        },
                                        children: ft.header
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: "my-1 "
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-justify m-0",
                                        style: {
                                            fontFamily: "Times New Roman"
                                        },
                                        children: ft.body
                                    }),
                                    ft.Add && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-justify m-0",
                                        style: {
                                            fontFamily: "Times New Roman"
                                        },
                                        children: ft.Add
                                    }),
                                    ft.tel && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-justify m-0",
                                        style: {
                                            fontFamily: "Times New Roman"
                                        },
                                        children: ft.tel
                                    }),
                                    ft.email && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-justify m-0",
                                        style: {
                                            fontFamily: "Times New Roman"
                                        },
                                        children: ft.email
                                    })
                                ]
                            }, index))
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TheFooter);


/***/ }),

/***/ 22218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_TheHeader)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Button.js
var Button = __webpack_require__(93780);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Row.js
var Row = __webpack_require__(44906);
var Row_default = /*#__PURE__*/__webpack_require__.n(Row);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/Col.js
var Col = __webpack_require__(57237);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/ListGroup.js
var ListGroup = __webpack_require__(857);
var ListGroup_default = /*#__PURE__*/__webpack_require__.n(ListGroup);
// EXTERNAL MODULE: ./components/Images/modellogo.jpg
var modellogo = __webpack_require__(66080);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/TheHeader.module.css
var TheHeader_module = __webpack_require__(65849);
var TheHeader_module_default = /*#__PURE__*/__webpack_require__.n(TheHeader_module);
// EXTERNAL MODULE: ./components/Cards/BorderedCardNoHover.jsx
var BorderedCardNoHover = __webpack_require__(32182);
// EXTERNAL MODULE: ./components/MainLinks.module.css
var MainLinks_module = __webpack_require__(64207);
var MainLinks_module_default = /*#__PURE__*/__webpack_require__.n(MainLinks_module);
;// CONCATENATED MODULE: ./components/MainLinks.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const MainLinks = (props)=>{
    const [displayPanel, setdisplayPanel] = (0,react_.useState)(false);
    const [isHover, setisHover] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(MainLinks_module_default()).Container}`,
        onMouseEnter: ()=>setdisplayPanel(true),
        onMouseLeave: ()=>setdisplayPanel(false),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: props.thepath,
                className: isHover ? `${(MainLinks_module_default()).StillHovering}` : `${(MainLinks_module_default()).TheMainLink}`,
                onClick: (e)=>props.Action(e, props.LinkName),
                children: props.LinkName
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (MainLinks_module_default()).Gap,
                onMouseEnter: ()=>setisHover(true),
                onMouseLeave: ()=>setisHover(false),
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: displayPanel && props.ThePanel ? (MainLinks_module_default()).ArrowOn : (MainLinks_module_default()).ArrowOff,
                    onMouseEnter: ()=>setisHover(true),
                    onMouseLeave: ()=>setisHover(false)
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: displayPanel && props.ThePanel ? (MainLinks_module_default()).TheDropDownPanel : (MainLinks_module_default()).TheDropDownPanelHidden,
                onMouseEnter: ()=>setisHover(true),
                onMouseLeave: ()=>setisHover(false),
                children: /*#__PURE__*/ jsx_runtime_.jsx(BorderedCardNoHover/* default */.Z, {
                    MyStyle: {
                        zIndex: "1",
                        padding: "0px"
                    },
                    children: props.ThePanel
                })
            })
        ]
    });
};
/* harmony default export */ const components_MainLinks = (MainLinks);

// EXTERNAL MODULE: ./components/Inputs/ButtonBackground.jsx
var ButtonBackground = __webpack_require__(56801);
// EXTERNAL MODULE: ./node_modules/react-bootstrap/cjs/ListGroupItem.js
var ListGroupItem = __webpack_require__(63349);
var ListGroupItem_default = /*#__PURE__*/__webpack_require__.n(ListGroupItem);
// EXTERNAL MODULE: ./components/AllPanel.module.css
var AllPanel_module = __webpack_require__(76879);
var AllPanel_module_default = /*#__PURE__*/__webpack_require__.n(AllPanel_module);
;// CONCATENATED MODULE: ./components/AllPanel.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AllPanel = (props)=>{
    const [TheSubLinks, setTheSubLinks] = (0,react_.useState)(props.TheLink);
    return /*#__PURE__*/ jsx_runtime_.jsx((Row_default()), {
        className: (AllPanel_module_default()).theRow,
        children: /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()), {
            className: "p-0",
            children: TheSubLinks.map((lnk, index)=>/*#__PURE__*/ jsx_runtime_.jsx((ListGroupItem_default()), {
                    variant: "primary",
                    className: (AllPanel_module_default()).ListItem,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: lnk.path,
                        className: (AllPanel_module_default()).subLinks,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (AllPanel_module_default()).sublinkname,
                                children: lnk.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (AllPanel_module_default()).Description,
                                children: lnk.desc
                            })
                        ]
                    })
                }, index))
        })
    });
};
/* harmony default export */ const components_AllPanel = (AllPanel);

// EXTERNAL MODULE: ./node_modules/@fortawesome/react-fontawesome/index.js
var react_fontawesome = __webpack_require__(52196);
// EXTERNAL MODULE: ./node_modules/@fortawesome/free-solid-svg-icons/index.mjs
var free_solid_svg_icons = __webpack_require__(42050);
// EXTERNAL MODULE: ./components/ModalsAndAlerts/OK_Modal.jsx
var OK_Modal = __webpack_require__(41129);
// EXTERNAL MODULE: ./components/API_Call/exit.js
var exit = __webpack_require__(54797);
// EXTERNAL MODULE: ./app/util/fonts.js
var fonts = __webpack_require__(26130);
// EXTERNAL MODULE: ./Store/permission-context.js
var permission_context = __webpack_require__(57948);
// EXTERNAL MODULE: ./components/Notification.jsx
var Notification = __webpack_require__(41315);
;// CONCATENATED MODULE: ./components/TheHeader.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





















const TheHeader = ()=>{
    const [Modal_Message, setModal_Message] = (0,react_.useState)("");
    const [Show_Modal, setShow_Modal] = (0,react_.useState)(false);
    const [Modal_Title, setModal_Title] = (0,react_.useState)("");
    const [Button_Title, setButton_Title] = (0,react_.useState)("");
    const PCtx = (0,react_.useContext)(permission_context["default"]);
    const changeMenuClick = ()=>{
        PCtx.setMenuClicked(!PCtx.MenuClicked);
    };
    const AfterEvent = ()=>{
        window.location.href = "/";
    };
    const ExitFunction = async (e, lmk)=>{
        e.preventDefault();
        lmk = lmk.toLowerCase();
        if (lmk === "log out") {
            if (await (0,exit/* default */.Z)()) {
                setModal_Title("Success");
                setModal_Message("You have successfully logged out of the system. Do have a wonderful day, Bye");
                setButton_Title("Ok, Bye");
                setShow_Modal(true);
            } else {
                (0,Notification/* DisplayNotification */.g)("Error", `Error in logging out. Please contact the Admin `, "danger", "top-center", 7000);
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
        className: `${(TheHeader_module_default()).TheMainRow} ${(TheHeader_module_default()).Hide4Print}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                md: 12,
                lg: 12,
                sm: 12,
                xs: 12,
                className: "h-100",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                        className: (TheHeader_module_default()).EacoedRow,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 12,
                                lg: 8,
                                sm: 12,
                                xs: 12,
                                className: "h-100",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                    className: "h-100",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            md: 2,
                                            lg: 2,
                                            sm: 12,
                                            xs: 12,
                                            className: `${(TheHeader_module_default()).LogoCol} d-flex justify-content-center  align-items-center text-center  m-0 p-0`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: modellogo/* default */.Z,
                                                className: ` ${(TheHeader_module_default()).Logo}`,
                                                alt: "School Logo"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                                            md: 10,
                                            lg: 10,
                                            sm: 12,
                                            xs: 12,
                                            className: "d-flex flex-column justify-content-md-center justify-content-sm-start align-items-md-start align-items-sm-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: ` m-0  px-md-0 ${(TheHeader_module_default()).schoolname}`,
                                                    children: "EAUED MODEL HIGH SCHOOL, OYO"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: `m-0 p-0 ${(TheHeader_module_default()).forward}`,
                                                    children: "...forward ever, backward never"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 12,
                                lg: 4,
                                sm: 12,
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                                    className: `${(TheHeader_module_default()).poweredRow} h-100 d-flex justify-content-end align-items-center`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                            md: 6,
                                            lg: 6,
                                            sm: 6,
                                            xs: 6,
                                            className: `d-inline-block  ${(TheHeader_module_default()).powered}`,
                                            children: "Powered By:"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Col["default"], {
                                            md: 6,
                                            lg: 6,
                                            sm: 6,
                                            xs: 6,
                                            className: ` d-inline-block justify-content-start  ${(TheHeader_module_default()).waviy} `,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "A"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "P"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "P"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "L"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "A"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "U"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "S"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: fonts/* shadows_Into_Light */.js,
                                                    children: "E"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                        className: `${(TheHeader_module_default()).LinksRow} "justify-content-end"`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 10,
                                lg: 10,
                                sm: 12,
                                xs: 12,
                                className: "d-flex justify-content-center align-items-center ",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: " m-0  p-0",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-0 px-3 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "HOME",
                                                thepath: "/"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-0 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "REGISTRATION",
                                                ThePanel: /*#__PURE__*/ jsx_runtime_.jsx(components_AllPanel, {
                                                    TheLink: [
                                                        {
                                                            title: "Student's Registration",
                                                            desc: "This opens a new form to register a newly admitted student who has no record on the software yet.",
                                                            path: "/studentregistration"
                                                        },
                                                        {
                                                            title: "Teacher's Registration",
                                                            desc: "This opens a new form to register a new teacher and provide the teacher with necessary login details",
                                                            path: "/teachersregistration"
                                                        },
                                                        {
                                                            title: "Subjects' Registration",
                                                            desc: "This opens a new form to register all the subjects offered by a  subject here",
                                                            path: "/subjectssregistration"
                                                        }
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-4 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "COMPUTATION",
                                                ThePanel: /*#__PURE__*/ jsx_runtime_.jsx(components_AllPanel, {
                                                    TheLink: [
                                                        {
                                                            title: "Scores Computation",
                                                            desc: "Subject Teachers input the scores of their students by selecting the necessary details",
                                                            path: "/computescores"
                                                        },
                                                        {
                                                            title: "Students Attributes",
                                                            desc: "Class Teachers input the attributes of students in their class. This include the psychomotor and thhe affective domain",
                                                            path: "/computereports"
                                                        }
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-4 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "VIEW",
                                                ThePanel: /*#__PURE__*/ jsx_runtime_.jsx(components_AllPanel, {
                                                    TheLink: [
                                                        {
                                                            title: "View Report Sheet",
                                                            desc: "Students completed Report Sheet can be viewed and printed or exported to parents here",
                                                            path: "/displayresults"
                                                        },
                                                        {
                                                            title: "View Broad Sheet",
                                                            desc: "Teachers view the cummulative broadsheet of scores of all the students in all subjects  in their class here",
                                                            path: "/displaybroadsheet"
                                                        }
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-4 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "AWARDS"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-4 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "ADMIN",
                                                ThePanel: /*#__PURE__*/ jsx_runtime_.jsx(components_AllPanel, {
                                                    TheLink: [
                                                        {
                                                            title: "Subject Teacher Allocation",
                                                            desc: "Authorize a teacher to the subject he/she teaches for easy access to scores computation",
                                                            path: "/subjectteacherallocation"
                                                        },
                                                        {
                                                            title: "Class Teacher Allocation",
                                                            desc: "Authorize teacher to perform class teacher's work for a particular class",
                                                            path: "/classteacherallocation"
                                                        },
                                                        {
                                                            title: "Promote Students",
                                                            desc: "Promote successful students to the selected session with respect to their classes",
                                                            path: "/promotion"
                                                        },
                                                        {
                                                            title: "View Students PINs",
                                                            desc: "View students PINs for result checking",
                                                            path: "/pins"
                                                        }
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-4 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "ABOUT"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "d-inline-block mx-4 px-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_MainLinks, {
                                                LinkName: "LOG OUT",
                                                Action: ExitFunction
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                md: 2,
                                lg: 2,
                                sm: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ButtonBackground/* default */.Z, {
                                    ButtonName: "12:00:00",
                                    ButtonCss: {
                                        display: "block"
                                    }
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Row_default()), {
                        className: `h-100 p-0 m-0   ${(TheHeader_module_default()).MenuBarRow}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                lg: 12,
                                md: 12,
                                sm: 12,
                                xs: 12,
                                className: "d-flex align-self-end  justify-content-end align-items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    className: "d-block ml-3",
                                    variant: "secondary-outline",
                                    onClick: changeMenuClick,
                                    children: PCtx.MenuClicked ? /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                        icon: free_solid_svg_icons/* faTimes */.NBC,
                                        style: {
                                            color: "black"
                                        }
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome.FontAwesomeIcon, {
                                        icon: free_solid_svg_icons/* faBars */.xiG,
                                        style: {
                                            color: "black"
                                        }
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Col["default"], {
                                lg: 12,
                                md: 12,
                                sm: 12,
                                xs: 12,
                                className: PCtx.MenuClicked ? (TheHeader_module_default()).MobileMenuPanelOn : (TheHeader_module_default()).MobileMenuPanelOff,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        position: "relative",
                                        margin: "0px",
                                        padding: "0px !important"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(BorderedCardNoHover/* default */.Z, {
                                        MyStyle: {
                                            padding: "0px !important",
                                            margin: "0px !important",
                                            position: "absolute",
                                            right: "0",
                                            top: "0",
                                            zIndex: "1 !important",
                                            borderRadius: "0px !important",
                                            width: "100%"
                                        },
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListGroup_default()), {
                                            style: {
                                                margin: "0px !important",
                                                borderRadius: "0px",
                                                margin: "0px",
                                                display: "inline-block"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: "Home"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0 d-block`,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: [
                                                            "Registration",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/studentregistration",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Students Registration"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/teachersregistration",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Staff Registration"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/subjectsregistration",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Subjects Registration"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0 d-block`,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: [
                                                            "Computation",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/computescores",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Scores Computation"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/computereports",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Students Attributes"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0 d-block`,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: [
                                                            "View",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/displayresults",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "View Report Sheet"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/displaybroadsheet",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "View Broad Sheet"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: "Award"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: "About"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0 d-block`,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        children: [
                                                            "Admin",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/subjectteacherallocation",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Subject Teacher Allocation"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/classteacherallocation",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Class Teacher Allocation"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/classteacherallocation",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Change Student Class"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: `${(TheHeader_module_default()).submobileP} ml-3 my-0`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/promotion",
                                                                    className: (TheHeader_module_default()).submobilelinks,
                                                                    children: "Promote Students"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListGroup_default()).Item, {
                                                    className: `${(TheHeader_module_default()).MobileMenuList} w-100 m-0`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: `${fonts/* rubik */.kg} ${(TheHeader_module_default()).subLinks}`,
                                                        onClick: (e)=>ExitFunction(e, "Log Out"),
                                                        children: "Log Out"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            Show_Modal && /*#__PURE__*/ jsx_runtime_.jsx(OK_Modal/* default */.Z, {
                title: Modal_Title,
                message: Modal_Message,
                ShowModal: Show_Modal,
                buttontitle: Button_Title,
                AfterEvent: AfterEvent,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const components_TheHeader = (TheHeader);


/***/ }),

/***/ 76879:
/***/ ((module) => {

// Exports
module.exports = {
	"theRow": "AllPanel_theRow__Qcqi6",
	"subLinks": "AllPanel_subLinks__QqYPt",
	"ListItem": "AllPanel_ListItem__peUiE",
	"sublinkname": "AllPanel_sublinkname__7Q5bq",
	"Description": "AllPanel_Description__FD_AK"
};


/***/ }),

/***/ 68886:
/***/ ((module) => {

// Exports
module.exports = {
	"cardcss": "BorderedCard_cardcss__2SgB8"
};


/***/ }),

/***/ 68635:
/***/ ((module) => {

// Exports
module.exports = {
	"cardcss": "BorderedCardNoHover_cardcss__PeSkf"
};


/***/ }),

/***/ 21306:
/***/ ((module) => {

// Exports
module.exports = {
	"CompulsoryItem": "FormInputText_CompulsoryItem__F25Sn"
};


/***/ }),

/***/ 80700:
/***/ ((module) => {

// Exports
module.exports = {
	"formCol": "Login_Page_formCol__iYOVU",
	"MainRow": "Login_Page_MainRow__kxhmS",
	"Softname": "Login_Page_Softname__B15bD",
	"AllBgColor": "Login_Page_AllBgColor__5WofF",
	"logSquare": "Login_Page_logSquare__yVzio",
	"MainImg": "Login_Page_MainImg__2arD6",
	"FormMainRow": "Login_Page_FormMainRow__umQzR"
};


/***/ }),

/***/ 64207:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "MainLinks_Container__S1dxP",
	"TheMainLink": "MainLinks_TheMainLink__zJCH3",
	"StillHovering": "MainLinks_StillHovering__vrhxh",
	"TheDropDownPanel": "MainLinks_TheDropDownPanel__aPh_Y",
	"PanelMovement": "MainLinks_PanelMovement__JaqX3",
	"TheDropDownPanelHidden": "MainLinks_TheDropDownPanelHidden__E9U7F",
	"ArrowOn": "MainLinks_ArrowOn__XefyN",
	"Gap": "MainLinks_Gap__G51OR",
	"ArrowOff": "MainLinks_ArrowOff__wwE_X"
};


/***/ }),

/***/ 63682:
/***/ ((module) => {

// Exports
module.exports = {
	"EachMenuCol": "MenuDisplayPage_EachMenuCol__zmHTS"
};


/***/ }),

/***/ 85954:
/***/ ((module) => {

// Exports
module.exports = {
	"TemplateDimension": "MenuTemplate_TemplateDimension__oKvip",
	"TitleColumn": "MenuTemplate_TitleColumn__Fowm2",
	"TitleColumnHover": "MenuTemplate_TitleColumnHover__Qgm0f",
	"theLinks": "MenuTemplate_theLinks__tGwT3",
	"TitleText": "MenuTemplate_TitleText__iCYN_"
};


/***/ }),

/***/ 12201:
/***/ ((module) => {

// Exports
module.exports = {
	"FootHeader": "TheFooter_FootHeader__DDyiN",
	"Margin4Print": "TheFooter_Margin4Print__cyQji",
	"Hide4Print": "TheFooter_Hide4Print__i6bni"
};


/***/ }),

/***/ 65849:
/***/ ((module) => {

// Exports
module.exports = {
	"TheMainRow": "TheHeader_TheMainRow__rvAsx",
	"EacoedRow": "TheHeader_EacoedRow__WJePQ",
	"MenuBarRow": "TheHeader_MenuBarRow__3qX_c",
	"LinksRow": "TheHeader_LinksRow__f6k7C",
	"Logo": "TheHeader_Logo__RL1p7",
	"schoolname": "TheHeader_schoolname__Y0S0u",
	"forward": "TheHeader_forward__2HgZK",
	"waviy": "TheHeader_waviy__6vebA",
	"flip": "TheHeader_flip__1byQo",
	"powered": "TheHeader_powered__HH7Fi",
	"LogoCol": "TheHeader_LogoCol__w6Zi3",
	"poweredRow": "TheHeader_poweredRow__6xTOu",
	"MobileMenuList": "TheHeader_MobileMenuList__W5rvM",
	"subLinks": "TheHeader_subLinks__7wd7v",
	"submobileP": "TheHeader_submobileP__zB0la",
	"submobilelinks": "TheHeader_submobilelinks__Rq96x",
	"MobileMenuPanelOn": "TheHeader_MobileMenuPanelOn__ZCiS4",
	"PanelMovement": "TheHeader_PanelMovement__gNv5l",
	"MobileMenuPanelOff": "TheHeader_MobileMenuPanelOff__VwyzD",
	"Margin4Print": "TheHeader_Margin4Print__eHpee",
	"Hide4Print": "TheHeader_Hide4Print__IH9O_"
};


/***/ }),

/***/ 92304:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(54010);
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.min.css
var bootstrap_min = __webpack_require__(47453);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(67272);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/TheHeader.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\TheHeader.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const TheHeader = (__default__);
;// CONCATENATED MODULE: ./components/TheFooter.jsx

const TheFooter_proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\TheFooter.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: TheFooter_esModule, $$typeof: TheFooter_$$typeof } = TheFooter_proxy;
const TheFooter_default_ = TheFooter_proxy.default;


/* harmony default export */ const TheFooter = (TheFooter_default_);
;// CONCATENATED MODULE: ./Store/permission-context.js

const permission_context_proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\Store\permission-context.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: permission_context_esModule, $$typeof: permission_context_$$typeof } = permission_context_proxy;
const permission_context_default_ = permission_context_proxy.default;

const e0 = permission_context_proxy["PermissionContextProvider"];


/* harmony default export */ const permission_context = ((/* unused pure expression or super */ null && (permission_context_default_)));
;// CONCATENATED MODULE: ./app/layout.js







const metadata = {
    title: {
        absolute: "EAUED MHS",
        template: "EAUED MHS | %s"
    },
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            className: (target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e0, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(TheHeader, {}),
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(TheFooter, {})
                ]
            })
        })
    });
}


/***/ }),

/***/ 83236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\wamp64\www\next-app\components\Login_Page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 66080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/modellogo.0e50d24f.jpg","height":72,"width":74,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAgEAABAwIHAAAAAAAAAAAAAAABAAIDBAUREyExMlHx/8QAFAEBAAAAAAAAAAAAAAAAAAAAAv/EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oADAMBAAIRAxEAPwC9NdVi+Gcw3HIA4iFxadcNu/UREBr/2Q==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 57481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(80085);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 67272:
/***/ (() => {



/***/ })

};
;