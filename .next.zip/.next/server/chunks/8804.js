"use strict";
exports.id = 8804;
exports.ids = [8804];
exports.modules = {

/***/ 46707:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _app_util_fonts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(26130);
/* harmony import */ var _FormInputText_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21306);
/* harmony import */ var _FormInputText_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_FormInputText_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* __next_internal_client_entry_do_not_use__ default auto */ 




const FormInputSelect = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                className: _app_util_fonts__WEBPACK_IMPORTED_MODULE_2__/* .pt_Sans */ .g7,
                style: {
                    color: props.Color,
                    fontWeight: "bold"
                },
                children: [
                    props.Label,
                    props.Compulsory && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_FormInputText_module_css__WEBPACK_IMPORTED_MODULE_4___default().CompulsoryItem),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("sup", {
                            children: " * "
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Select), {
                value: props.Owner,
                onChange: (e)=>props.GetValue(e.target.value),
                disabled: props.Disabled,
                className: _app_util_fonts__WEBPACK_IMPORTED_MODULE_2__/* .pt_Sans */ .g7,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        children: " Select"
                    }),
                    props.Data.map((cat, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: cat,
                            className: _app_util_fonts__WEBPACK_IMPORTED_MODULE_2__/* .rubik */ .kg,
                            children: cat
                        }, index))
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormInputSelect);


/***/ }),

/***/ 82616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _db_createtable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32201);
/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(40063);
/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_headers__WEBPACK_IMPORTED_MODULE_1__);
// import { NextResponse } from "next/server";


const CheckLoggedStatus = async ()=>{
    const Cookies = new next_headers__WEBPACK_IMPORTED_MODULE_1__.cookies();
    const stat = Cookies.get("accessStatus");
    if (stat) {
        return true;
    } else {
        return false;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckLoggedStatus);


/***/ })

};
;