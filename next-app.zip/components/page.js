import Display_Result from "@/components/Display_Result";

const DisplayResults = async () => {
  return <Display_Result />;
};

export default DisplayResults;
