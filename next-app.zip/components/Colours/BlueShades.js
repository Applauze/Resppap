export const BlueShades = {
  BlackShade: "#141414",
  WineShade: "#920808",
  WineShadeDeeper: "#4a0303",
  WhiteShade: "#d9d2d2",
  White: "#ffffff",
  HoverOnWine: "#f6add1",
  HoverOnWineDeep: "#f0238a",
};

export default BlueShades;
