"use strict";
exports.id = 5528;
exports.ids = [5528];
exports.modules = {

/***/ 42634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Class = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: [
            "JS1M",
            "JS1O",
            "JS1D",
            "JS1E",
            "JS1L",
            "JS2M",
            "JS2O",
            "JS2D",
            "JS2E",
            "JS2L",
            "JS3M",
            "JS3O",
            "JS3D",
            "JS3E",
            "JS3L",
            "SS1M",
            "SS1O",
            "SS1D",
            "SS1E",
            "SS1L",
            "SS2M",
            "SS2O",
            "SS2D",
            "SS2E",
            "SS2L",
            "SS3M",
            "SS3O",
            "SS3D",
            "SS3E",
            "SS3L"
        ],
        Label: "Class",
        GetValue: props.setClaz,
        Color: "brown",
        Owner: props.Claz,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Class);


/***/ }),

/***/ 29332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Session = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: [
            "20222023",
            "20232024",
            "20242025",
            "20252026"
        ],
        Label: "Session",
        GetValue: props.setSession,
        Color: "brown",
        Owner: props.Session,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Session);


/***/ })

};
;