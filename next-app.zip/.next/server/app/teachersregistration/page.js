(() => {
var exports = {};
exports.id = 1859;
exports.ids = [1859];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 81176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'teachersregistration',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31306)), "C:\\wamp64\\www\\next-app\\app\\teachersregistration\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\teachersregistration\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/teachersregistration/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/teachersregistration/page",
        pathname: "/teachersregistration",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 20824:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28309))

/***/ }),

/***/ 28309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Store_permission_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57948);
/* harmony import */ var _API_Call_axioscall__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(69294);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2129);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ModalsAndAlerts_OK_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41129);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(46887);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(44561);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(57237);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_bootstrap_Spinner__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(27093);
/* harmony import */ var react_bootstrap_Spinner__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Spinner__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32182);
/* harmony import */ var _Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(73446);
/* harmony import */ var _Inputs_FormInputPassword__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(31160);
/* harmony import */ var _Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(69541);
/* harmony import */ var _Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(46707);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(41315);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_11__);
/* __next_internal_client_entry_do_not_use__ default auto */ 



















const Teachers_Registration = (props)=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_11___default())();
    const [TeachersID, setTeachersID] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Title, setTitle] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Surname, setSurname] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Firstname, setFirstname] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Middlename, setMiddlename] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Gateway, setGateway] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Gateway2, setGateway2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [AllTheTeachersID, setAllTheTeachersID] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [Category, setCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [Modal_Title, setModal_Title] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Button_Title, setButton_Title] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Modal_Message, setModal_Message] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Show_Modal, setShow_Modal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [Saving, setSaving] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    var CryptoJS = __webpack_require__(87683);
    const PCtx = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_Store_permission_context__WEBPACK_IMPORTED_MODULE_2__["default"]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    const TheColor = "brown";
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const AllTeachers = JSON.parse(props.TeachersNames);
        setAllTheTeachersID(AllTeachers.AllTeachersID);
    }, []);
    const AfterEvent = ()=>{
        setShow_Modal(false);
        setSurname("");
        setFirstname("");
        setMiddlename("");
        setTeachersID("");
        setGateway("");
        setGateway2("");
        setCategory("Select");
        setTitle("Select");
    };
    const CapitalizeFirstLetter = (str)=>{
        return str != "" ? str[0].toUpperCase() + str.slice(1).toLowerCase() : "";
    };
    const GetSurname = (str)=>{
        setSurname(str.toUpperCase());
    };
    const GetMiddlename = (str)=>{
        setMiddlename(CapitalizeFirstLetter(str));
    };
    const GetFirstname = (str)=>{
        setFirstname(CapitalizeFirstLetter(str));
    };
    const GetTeachersID = (str)=>{
        setTeachersID(CapitalizeFirstLetter(str));
    };
    const SaveStudentInformation = async (e)=>{
        e.preventDefault();
        if (Gateway === Gateway2) {
            if (!AllTheTeachersID.includes(TeachersID)) {
                let WayGate = CryptoJS.AES.encrypt(Gateway, "143tonybridget").toString();
                let TeacherData = {
                    TeachersID: TeachersID,
                    Title: Title,
                    Gateway: WayGate,
                    Surname: Surname,
                    Firstname: Firstname,
                    Middlename: Middlename,
                    Category: Category
                };
                setSaving(true);
                const response = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)("save_new_teacher", TeacherData);
                if (response === "Saved Successfully") {
                    setSaving(false);
                    setModal_Title("Success");
                    setModal_Message(Firstname + "'s data saved succesfully!");
                    setButton_Title("Ok, Thank you!");
                    setShow_Modal(true);
                }
            } else {
                (0,_Notification__WEBPACK_IMPORTED_MODULE_10__/* .DisplayNotification */ .g)("Error", `A teacher has already taken "${TeachersID}" as Teacher's ID, Please use another Teacher's ID`, "danger", "top-center", 7000);
            }
        } else {
            (0,_Notification__WEBPACK_IMPORTED_MODULE_10__/* .DisplayNotification */ .g)("Error", `Unmatched password. Please check the password enetered in both boxes and ensure they are the same`, "danger", "top-center", 7000);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_13___default()), {
        fluid: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_notifications_component__WEBPACK_IMPORTED_MODULE_3__.ReactNotifications, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                className: "justify-content-around",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                        lg: 10,
                        md: 10,
                        sm: 11,
                        xs: 11,
                        className: "my-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            MyStyle: {
                                backgroundColor: "#eeeeee",
                                padding: "0px",
                                margin: "0px"
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                        md: 5,
                                        lg: 5,
                                        sm: 12,
                                        xs: 12,
                                        className: `p-5 ${(_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default().FormFirstDivision)}`,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                className: '"text-center',
                                                children: "Please read Carefully before filling this form"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: "The surname, firstname are compulsory. The middle name may be left blank if the teacher has none."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: "Note that password are case sensitive and must be atleast six characters long. i.e PASSWORD is not te same as Password nor password."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: "Ensure that the information enetered in Password Field and Retype Password field are the same."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: "Your TeacherID and Password are very essential. Please keep it safe and confidential as you will need it for subsequent login."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: "The Admin is to choose the Category of teachers you belong to."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: "Direct any question or information that is not clear to the Admin before saving this form."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                        md: 7,
                                        lg: 7,
                                        sm: 12,
                                        xs: 12,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_17___default()), {
                                            className: "pt-2 mb-4",
                                            onSubmit: SaveStudentInformation,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    className: "justify-content-around my-1",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                        lg: 12,
                                                        md: 12,
                                                        xs: 12,
                                                        sm: 12,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                            className: "h4 text-center mb-3",
                                                            children: "New Student Registration Form"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                    className: (_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default().formDivider)
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                Label: "Teacher's ID",
                                                                GetValue: GetTeachersID,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: TeachersID
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: (_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default().formDivider)
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                                Data: [
                                                                    "Mr.",
                                                                    "Mrs.",
                                                                    "Miss.",
                                                                    "Chief",
                                                                    "Dr."
                                                                ],
                                                                Label: "Title",
                                                                GetValue: setTitle,
                                                                Color: TheColor,
                                                                Owner: Title
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputPassword__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                Label: "Password",
                                                                GetValue: setGateway,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Gateway
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: (_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default().formDivider)
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputPassword__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                Label: "Re-enter Password",
                                                                GetValue: setGateway2,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Gateway2
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                Label: "Surname",
                                                                GetValue: GetSurname,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Surname
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: (_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default().formDivider)
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                Label: "Firstname",
                                                                GetValue: GetFirstname,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Firstname
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    className: "justify-content-around my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputText__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                Label: "Middlename",
                                                                GetValue: GetMiddlename,
                                                                Color: TheColor,
                                                                readonly: Saving,
                                                                Owner: Middlename
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                            className: (_Teachers_Registration_module_css__WEBPACK_IMPORTED_MODULE_16___default().formDivider)
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 5,
                                                            lg: 5,
                                                            sm: 10,
                                                            xs: 10,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                                Data: [
                                                                    "Admin",
                                                                    "Non Admin"
                                                                ],
                                                                Label: "Category",
                                                                GetValue: setCategory,
                                                                Color: TheColor,
                                                                Owner: Category
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    className: "justify-content-around align-items-end",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 4,
                                                            lg: 4,
                                                            sm: 6,
                                                            xs: 6,
                                                            className: "text-center",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                                variant: "danger",
                                                                className: "btn_small px-md-4 mt-3",
                                                                disabled: Saving,
                                                                onClick: AfterEvent,
                                                                children: "Clear"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                            md: 4,
                                                            lg: 4,
                                                            sm: 6,
                                                            xs: 6,
                                                            className: "text-center",
                                                            children: Saving ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                                variant: "success",
                                                                className: "btn_small px-md-4 mt-3",
                                                                disabled: true,
                                                                type: "submit",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Spinner__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                                        as: "span",
                                                                        animation: "border",
                                                                        size: "sm",
                                                                        role: "status",
                                                                        "aria-hidden": "true"
                                                                    }),
                                                                    "Saving..."
                                                                ]
                                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                                variant: "success",
                                                                className: "btn_small px-md-4 mt-3",
                                                                type: "submit",
                                                                children: "Save"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    Show_Modal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalsAndAlerts_OK_Modal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: Modal_Title,
                        message: Modal_Message,
                        ShowModal: Show_Modal,
                        buttontitle: Button_Title,
                        AfterEvent: AfterEvent,
                        variant: "success",
                        size: "sm"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Teachers_Registration);


/***/ }),

/***/ 69541:
/***/ ((module) => {

// Exports
module.exports = {
	"formDivider": "Teachers_Registration_formDivider__ijTyz",
	"FormFirstDivision": "Teachers_Registration_FormFirstDivision__0cHX7"
};


/***/ }),

/***/ 7046:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89335);
/* harmony import */ var _db_createtable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32201);


const GetAllNames = async (request, response)=>{
    const connect = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabase */ .TR)();
    const select_sql = " SELECT teacher_id, surname, firstname, middlename FROM teachers_details";
    const result = await (0,_db_createtable__WEBPACK_IMPORTED_MODULE_1__/* .selectTable */ .jM)(connect, select_sql);
    let AllNames = [];
    let AllTIDs = [];
    let AllTeachersDetails = {};
    result.forEach((Teacher)=>{
        AllNames = [
            ...AllNames,
            Teacher.surname + " " + Teacher.firstname + " " + Teacher.middlename
        ];
        AllTIDs = [
            ...AllTIDs,
            Teacher.teacher_id
        ];
    });
    AllTeachersDetails = {
        AllTeachersNames: AllNames,
        AllTeachersID: AllTIDs
    };
    const theData = JSON.stringify(AllTeachersDetails);
    connect.end();
    return theData;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetAllNames);


/***/ }),

/***/ 31306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/Teachers_Registration.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\Teachers_Registration.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Teachers_Registration = (__default__);
// EXTERNAL MODULE: ./app/api/getallteachersname.js
var getallteachersname = __webpack_require__(7046);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/teachersregistration/page.js





const ComputeScores = async ()=>{
    const getTeachersNames = async ()=>{
        const All_TeachersNames = await (0,getallteachersname/* default */.Z)();
        return All_TeachersNames;
    };
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    let TeachersNames = "{}";
    if (Stat) {
        TeachersNames = await getTeachersNames();
    }
    return Stat ? /*#__PURE__*/ jsx_runtime_.jsx(Teachers_Registration, {
        TeachersNames: TeachersNames
    }) : /*#__PURE__*/ jsx_runtime_.jsx(Login_Page/* default */.ZP, {
        Redirection: true
    });
};
/* harmony default export */ const page = (ComputeScores);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,4642,2284,9335,1934,7341,1827,4232,8505,8804,3446], () => (__webpack_exec__(81176)));
module.exports = __webpack_exports__;

})();