(() => {
var exports = {};
exports.id = 2757;
exports.ids = [2757];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 30412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'displaybroadsheet',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54467)), "C:\\wamp64\\www\\next-app\\app\\displaybroadsheet\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\displaybroadsheet\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/displaybroadsheet/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/displaybroadsheet/page",
        pathname: "/displaybroadsheet",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 60689:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 69454))

/***/ }),

/***/ 69454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Store_permission_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57948);
/* harmony import */ var _SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29332);
/* harmony import */ var _SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(42634);
/* harmony import */ var _SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55607);
/* harmony import */ var _SessionTermClass_Subjects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67109);
/* harmony import */ var _ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24606);
/* harmony import */ var _Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(52739);
/* harmony import */ var _Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(46887);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(44561);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(57237);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(11589);
/* harmony import */ var react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _API_Call_axioscall__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(69294);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(41315);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2129);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(32182);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(56801);
/* __next_internal_client_entry_do_not_use__ default auto */ 






















const Display_Broadsheet = (props)=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_13___default())();
    const [session, setsession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [claz, setclaz] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [term, setterm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [showProcessing, setshowProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [Message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [activateSelector, setactivateSelector] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [activateButton, setactivateButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [displayBroadsheet, setdisplayBroadsheet] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [AllBroadSheetInfo, setAllBroadSheetInfo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [AllBroadSheetInfoHeader, setAllBroadSheetInfoHeader] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const buttonBackground = {
        backgroundColor: "#003152",
        boxShadow: "0 5px 8px 0 rgba(0, 0, 0, 0.2) "
    };
    const PCtx = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_Store_permission_context__WEBPACK_IMPORTED_MODULE_2__["default"]);
    const buttonCss = {
        width: "100%"
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const activateTheButton = ()=>{
            if (session != "Select" && claz != "Select" && term != "Select") {
                setactivateButton(true);
            } else {
                setactivateButton(false);
            }
        };
        setdisplayBroadsheet(false);
        activateTheButton();
    }, [
        session,
        claz,
        term
    ]);
    const PrintTheReport = async ()=>{
        window.print();
        (0,_Notification__WEBPACK_IMPORTED_MODULE_8__/* .DisplayNotification */ .g)("Success", `The Broadsheet has been sent to the Printer`, "success", "top-center", 5000);
    };
    const GetTheStudents = async (e)=>{
        e.preventDefault();
        setMessage(`The system is retrieving the broadsheet for ${claz}`);
        setshowProcessing(true);
        let BroadsheetParam = {
            Session: session,
            Term: term,
            Claz: claz
        };
        let BroadSheetInfoInJSON = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)("load_broadsheet", BroadsheetParam);
        if (BroadSheetInfoInJSON === "No result" || BroadSheetInfoInJSON === "Error") {
            setshowProcessing(false);
            (0,_Notification__WEBPACK_IMPORTED_MODULE_8__/* .DisplayNotification */ .g)("Error", `No result found, check the details you have entered for possible error or contact the administrator for assistance`, "danger", "top-center", 7000);
        } else {
            let BInfo = JSON.parse(BroadSheetInfoInJSON);
            setAllBroadSheetInfo(BInfo);
            setAllBroadSheetInfoHeader(BInfo[0]);
            setdisplayBroadsheet(true);
            setshowProcessing(false);
        }
    };
    const RotatedHeading = (ind, Heading)=>{
        if (ind < 2) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                className: ` ${(_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().BoldTableHeading)}`,
                children: Heading
            }, ind);
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                className: `${(_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().RotatedHeading)} ${(_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().BoldTableHeading)}`,
                children: Heading
            }, ind);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_16___default()), {
        fluid: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_notifications_component__WEBPACK_IMPORTED_MODULE_9__.ReactNotifications, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().Hide4Print),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    MyStyle: {
                        borderRadius: "0px"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17___default()), {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                md: 12,
                                lg: 12,
                                sm: 11,
                                xs: 11,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "text-center h4",
                                    children: "BROADSHEET DISPLAY"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17___default()), {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default()), {
                                onSubmit: GetTheStudents,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17___default()), {
                                        className: "justify-content-around",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                md: 12,
                                                lg: 12,
                                                sm: 11,
                                                xs: 11,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                    className: "text-center h6",
                                                    children: "Please fill in the details of the class you want to display the Broadsheet"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                lg: 4,
                                                md: 4,
                                                sm: 11,
                                                xs: 11,
                                                className: " ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    Session: session,
                                                    setSession: setsession,
                                                    Disabled: !activateSelector
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                lg: 4,
                                                md: 4,
                                                sm: 11,
                                                xs: 11,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                    Term: term,
                                                    setTerm: setterm,
                                                    Disabled: !activateSelector
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                lg: 4,
                                                md: 4,
                                                sm: 11,
                                                xs: 11,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                    Claz: claz,
                                                    setClaz: setclaz,
                                                    Disabled: !activateSelector
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17___default()), {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                            lg: 3,
                                            md: 3,
                                            sm: 11,
                                            xs: 11,
                                            className: "mt-2 col-offset-9",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_20___default()), {
                                                variance: "info",
                                                type: "submit",
                                                disabled: !activateButton,
                                                style: buttonBackground,
                                                children: "Retrieve Students"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            displayBroadsheet && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_17___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_18__["default"], {
                        md: 12,
                        lg: 12,
                        xs: 12,
                        sm: 12,
                        className: "p-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "h5 text-center",
                                children: `${claz} BROADSHEET FOR ${session} SESSION, ${term} TERM `.toUpperCase()
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_21___default()), {
                                responsive: true,
                                hover: true,
                                bordered: true,
                                striped: true,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: (_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().BoldTableHeading),
                                                    style: {
                                                        width: "3%",
                                                        textAlign: "center"
                                                    },
                                                    children: "SN"
                                                }),
                                                AllBroadSheetInfoHeader.map((hd, index)=>index != 0 && RotatedHeading(index, hd))
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: AllBroadSheetInfo.map((bd, index)=>index != 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: index
                                                    }),
                                                    bd.map((dt, ind)=>ind != 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: ind > 1 ? (_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().TableData) : (_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().TableData2),
                                                            style: ind > 1 ? parseFloat(dt) >= 50 || ind === bd.length - 4 || ind === bd.length - 3 ? {
                                                                color: "blue"
                                                            } : {
                                                                color: "red"
                                                            } : {
                                                                color: "brown"
                                                            },
                                                            children: dt
                                                        }, ind))
                                                ]
                                            }, index))
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        ButtonName: "PRINT",
                        className: (_Display_Broadsheet_module_css__WEBPACK_IMPORTED_MODULE_15___default().SubmitButton),
                        ButtonAction: PrintTheReport,
                        ButtonCss: buttonCss
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Display_Broadsheet);


/***/ }),

/***/ 67109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Subjects = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: props.TheSubjects,
        Label: "Subject",
        GetValue: props.setSubject,
        Color: "brown",
        Owner: props.Subject,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Subjects);


/***/ }),

/***/ 55607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46707);



const Term = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Inputs_FormInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        Data: [
            "First",
            "Second",
            "Third"
        ],
        Label: "Term",
        GetValue: props.setTerm,
        Color: "brown",
        Owner: props.Term,
        Disabled: props.Disabled
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Term);


/***/ }),

/***/ 52739:
/***/ ((module) => {

// Exports
module.exports = {
	"RotatedHeading": "Display_Broadsheet_RotatedHeading__tM9bd",
	"BoldTableHeading": "Display_Broadsheet_BoldTableHeading__zuEoQ",
	"TableData": "Display_Broadsheet_TableData__AYR3b",
	"TableData2": "Display_Broadsheet_TableData2__3zw1U",
	"SubmitButton": "Display_Broadsheet_SubmitButton__1zQGk",
	"Margin4Print": "Display_Broadsheet_Margin4Print__aMT0B",
	"Hide4Print": "Display_Broadsheet_Hide4Print__9cHoK"
};


/***/ }),

/***/ 54467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/Display_Broadsheet.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\Display_Broadsheet.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Display_Broadsheet = (__default__);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/displaybroadsheet/page.js




const DisplayBroadsheet = async ()=>{
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    return Stat ? /*#__PURE__*/ jsx_runtime_.jsx(Display_Broadsheet, {}) : /*#__PURE__*/ jsx_runtime_.jsx(Login_Page/* default */.ZP, {
        Redirection: true
    });
};
/* harmony default export */ const page = (DisplayBroadsheet);


/***/ }),

/***/ 40063:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(74937);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,4642,1934,7341,1589,4232,8505,8804,5528], () => (__webpack_exec__(30412)));
module.exports = __webpack_exports__;

})();