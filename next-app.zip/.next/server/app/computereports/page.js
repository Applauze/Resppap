(() => {
var exports = {};
exports.id = 8476;
exports.ids = [8476];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 39512:
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 93686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'computereports',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 36277)), "C:\\wamp64\\www\\next-app\\app\\computereports\\page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92304)), "C:\\wamp64\\www\\next-app\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\wamp64\\www\\next-app\\app\\computereports\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/computereports/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/computereports/page",
        pathname: "/computereports",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 76773:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97274));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90661))

/***/ }),

/***/ 90661:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29332);
/* harmony import */ var _SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42634);
/* harmony import */ var _SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55607);
/* harmony import */ var _Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(56801);
/* harmony import */ var _ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(24606);
/* harmony import */ var _Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9201);
/* harmony import */ var _Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _Store_permission_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57948);
/* harmony import */ var _Images_MaleDummy_jpg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(86955);
/* harmony import */ var _Images_FemaleDummy_jpg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1241);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(46887);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(44561);
/* harmony import */ var react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(57237);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(39486);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(93780);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(11589);
/* harmony import */ var react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var react_bootstrap_ListGroup__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(857);
/* harmony import */ var react_bootstrap_ListGroup__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_ListGroup__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _API_Call_axioscall__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(69294);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41315);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85307);
/* harmony import */ var react_notifications_component__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2129);
/* harmony import */ var react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_notifications_component_dist_theme_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(32182);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(18284);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_15__);
/* __next_internal_client_entry_do_not_use__ default auto */ 
























const Compute_Reports = ()=>{
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_15___default())();
    const [session, setsession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [claz, setclaz] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [term, setterm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [showProcessing, setshowProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [Message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [activateSelector, setactivateSelector] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [activateButton, setactivateButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [displayStudents, setdisplayStudents] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [AllStudents, setAllStudents] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedStudentDetails, setRetrievedStudentDetails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedSubjects, setRetrievedSubjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedAttributes1, setRetrievedAttributes1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [RetrievedAttributes2, setRetrievedAttributes2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ct_remark, setct_remark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [p_attendance, setp_attendance] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [nexttermbegins, setnexttermbegins] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [schoolopens, setschoolopens] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [ResumptionCheck, setResumptionCheck] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [TeachersComments, setTeachersComments] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [PrincipalsComments, setPrincipalsComments] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [p_remark, setp_remark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [sel_ct_remark, setsel_ct_remark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [sel_p_remark, setsel_p_remark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Select");
    const [DisplayPOptions, setDisplayPOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [DisplayCTOptions, setDisplayCTOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [DisplayCardPanel, setDisplayCardPanel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [DisplayMainCard, setDisplayMainCard] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [st_id, setst_id] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Fullname, setFullname] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [Firstname, setFirstname] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const PCtx = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_Store_permission_context__WEBPACK_IMPORTED_MODULE_8__["default"]);
    const buttonBackground = {
        backgroundColor: "#003152",
        boxShadow: "0 5px 8px 0 rgba(0, 0, 0, 0.2) "
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        PCtx.setMenuClicked(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const activateTheButton = ()=>{
            if (session != "Select" && claz != "Select" && term != "Select") {
                setactivateButton(true);
            } else {
                setactivateButton(false);
            }
        };
        setdisplayStudents(false);
        activateTheButton();
    }, [
        session,
        claz,
        term
    ]);
    const GetThisStudentReport = async (element)=>{
        setMessage(`The system is retrieving  ${element.Fullname}'s report`);
        setshowProcessing(true);
        setDisplayMainCard(false);
        let ThisStudentParam = {
            student_id: element.student_id,
            Session: session,
            Term: term,
            Claz: claz
        };
        setst_id(element.student_id);
        let ThisStudentReportInJson = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)("load_this_student_report", ThisStudentParam);
        ThisStudentReportInJson = JSON.parse(ThisStudentReportInJson);
        // console.log(ThisStudentReportInJson.ThisStudentScores);
        ThisStudentParam = {
            ...ThisStudentParam,
            dob: element.dob,
            sex: element.sex,
            subjectsoffered: ThisStudentReportInJson.ThisStudentScores,
            alltheattributes: ThisStudentReportInJson.ThisStudentAttributes,
            allthecomments: ThisStudentReportInJson.ThisStudentComments,
            termproperties: ThisStudentReportInJson.ThisTermProperties,
            nic: element.nic,
            Fullname: element.Fullname,
            PixUrl: element.pixurl
        };
        setFullname(element.Fullname);
        let fn = element.Fullname.split(" ");
        setFirstname(fn[1]);
        let PsychoAttributes = ThisStudentReportInJson.ThisStudentAttributes;
        let AllComments = ThisStudentReportInJson.ThisStudentComments;
        let AllTermProp = ThisStudentReportInJson.ThisTermProperties;
        let n = Math.ceil(PsychoAttributes.length / 2) + 1;
        setRetrievedStudentDetails(ThisStudentParam);
        setRetrievedSubjects(ThisStudentReportInJson.ThisStudentScores);
        setRetrievedAttributes1(PsychoAttributes.slice(0, n));
        setRetrievedAttributes2(PsychoAttributes.slice(n));
        setDisplayMainCard(true);
        setshowProcessing(false);
        setct_remark(AllComments[0][`${term}_term_ctc`] ? AllComments[0][`${term}_term_ctc`] : "");
        setp_remark(AllComments[0][`${term}_term_pc`] ? AllComments[0][`${term}_term_pc`] : "");
        setp_attendance(AllComments[0][`${term}_term_attendance`] ? AllComments[0][`${term}_term_attendance`] : "");
        if (AllTermProp.length < 1) {
            setResumptionCheck(false);
        } else {
            setnexttermbegins(AllTermProp[0]["Resumption"]);
            setschoolopens(AllTermProp[0]["SchoolOpens"]);
            setResumptionCheck(true);
        }
    // setRetrievedComments(ThisStudentReportInJson.ThisStudentComments);
    };
    const GetTheStudents = async (e)=>{
        e.preventDefault();
        setMessage(`The system is retrieving the students in ${claz}`);
        setshowProcessing(true);
        let TeacherID = cookies.get("this_staff");
        let Category = cookies.get("this_category");
        let ReportsParam = {
            Session: session,
            Term: term,
            Claz: claz,
            TeacherID: TeacherID ? TeacherID : "Nothing",
            Category: Category ? Category : "Nothing"
        };
        let StudentsAndCommentsInJson = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)("load_students_for_reports", ReportsParam);
        console.log(StudentsAndCommentsInJson);
        if (!StudentsAndCommentsInJson.includes("Not Authorized")) {
            if (!StudentsAndCommentsInJson.includes("Error")) {
                StudentsAndCommentsInJson = JSON.parse(StudentsAndCommentsInJson);
                let AllStds = [];
                let AllComments = StudentsAndCommentsInJson.AllComments;
                let TCom = [];
                let PCom = [];
                AllComments.forEach((element)=>{
                    if (term === "Third") {
                        if (element.term === "Third") {
                            PCom.push(element.comment);
                        } else {
                            TCom.push(element.comment);
                        }
                    } else {
                        PCom.push(element.comment);
                        TCom.push(element.comment);
                    }
                });
                setTeachersComments(TCom);
                setPrincipalsComments(PCom);
                let NIC = StudentsAndCommentsInJson.AllStudents.length;
                StudentsAndCommentsInJson.AllStudents.forEach((element)=>{
                    AllStds = [
                        ...AllStds,
                        {
                            Fullname: `${element.surname} ${element.firstname} ${element.middlename}`,
                            student_id: element.student_id,
                            dob: element.dob,
                            sex: element.sex,
                            nic: NIC,
                            pixurl: element.picture_directory
                        }
                    ];
                });
                setAllStudents(AllStds);
                setDisplayCardPanel(true);
            } else {
                (0,_Notification__WEBPACK_IMPORTED_MODULE_11__/* .DisplayNotification */ .g)("Error", `No student has been registered in this class`, "danger", "top-center", 5000);
            }
        } else {
            (0,_Notification__WEBPACK_IMPORTED_MODULE_11__/* .DisplayNotification */ .g)("Error", `You are not an authorized teacher for the selected class. Please contact the Administrator`, "danger", "top-center", 7000);
        }
        setshowProcessing(false);
    };
    const StudentDescription = (LABEL, value, colsp)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
            md: colsp,
            lg: colsp,
            xs: 11,
            sm: 11,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "small py-0 my-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().mylabel),
                        children: LABEL
                    }),
                    ":",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: LABEL === "NAME" ? (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().myvalueName) : (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().myvalue),
                        children: value
                    })
                ]
            })
        });
    };
    const StudentDescription1 = (LABEL, colsp)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
            md: colsp,
            lg: colsp,
            xs: 11,
            sm: 11,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "small py-0 my-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().mylabel),
                    children: [
                        LABEL,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Control), {
                            type: "text",
                            value: schoolopens,
                            onChange: (e)=>{
                                !isNaN(e.target.value) && setschoolopens(e.target.value);
                            },
                            name: "PT1",
                            style: {
                                width: "60px",
                                height: "30px",
                                display: "inline-block",
                                marginLeft: "2px",
                                paddingLeft: "10px",
                                border: "1px solid brown",
                                borderRadius: "3px"
                            }
                        })
                    ]
                })
            })
        });
    };
    const StudentDescription2 = (LABEL, colsp)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
            md: colsp,
            lg: colsp,
            xs: 11,
            sm: 11,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "small py-0 my-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().mylabel),
                    children: [
                        LABEL,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Control), {
                            type: "text",
                            value: p_attendance,
                            onChange: (e)=>{
                                !isNaN(e.target.value) && setp_attendance(e.target.value);
                            },
                            name: "PT2",
                            style: {
                                width: "60px",
                                height: "30px",
                                display: "inline-block",
                                marginLeft: "2px",
                                paddingLeft: "10px",
                                border: "1px solid brown",
                                borderRadius: "3px"
                            }
                        })
                    ]
                })
            })
        });
    };
    const StudentDescription3 = (LABEL, colsp)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
            md: colsp,
            lg: colsp,
            xs: 11,
            sm: 11,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "small py-0 my-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().mylabel),
                    children: [
                        LABEL,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Control), {
                            type: "text",
                            value: nexttermbegins,
                            onChange: (e)=>{
                                setnexttermbegins(e.target.value);
                            },
                            name: "PT3",
                            style: {
                                width: "150px",
                                paddingLeft: "10px",
                                height: "30px",
                                display: "inline-block",
                                marginLeft: "2px",
                                border: "1px solid brown",
                                borderRadius: "3px"
                            }
                        })
                    ]
                })
            })
        });
    };
    const RotatedHeading = (tam, ThirdText, OtherText)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
            className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().RotatedHeading)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
            children: tam === "Third" ? ThirdText : OtherText
        });
    };
    const ChangeTheAttribute = (TheArray, val, Inc)=>{
        let AllAtt = TheArray === 1 ? [
            ...RetrievedAttributes1
        ] : [
            ...RetrievedAttributes2
        ];
        let TheAffected = {
            ...AllAtt[Inc]
        };
        TheAffected[`${term}_term_value`] = val;
        AllAtt[Inc] = TheAffected;
        TheArray === 1 ? setRetrievedAttributes1(AllAtt) : setRetrievedAttributes2(AllAtt);
    };
    const StudentAttributes = (n, ATT, RIndx)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: `py-1 ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)}`,
                    children: ATT[`${term}_term_attribute`]
                }),
                [
                    1,
                    2,
                    3,
                    4,
                    5
                ].map((vl, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                        className: `py-0 ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Check), {
                            name: ATT[`${term}_term_attribute`],
                            value: vl,
                            checked: parseInt(vl) === parseInt(ATT[`${term}_term_value`]),
                            type: "radio",
                            onChange: (e)=>ChangeTheAttribute(n, e.target.value, RIndx)
                        })
                    }, index))
            ]
        }, RIndx);
    };
    const InfoTable = (left, right)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().InfoTableLeft),
                    children: left
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().InfoTableRight),
                    children: right
                })
            ]
        });
    };
    const ChangeCTComment = (vl)=>{
        setct_remark(vl);
        setsel_ct_remark("Select");
    };
    const ChangePComment = (vl)=>{
        setp_remark(vl);
        setsel_p_remark("Select");
    };
    const SaveTheReport = async ()=>{
        setMessage(`The system is saving ${Fullname}'s Reports`);
        setshowProcessing(true);
        let MergedAttributes = RetrievedAttributes1.concat(RetrievedAttributes2);
        let NewStudentParam = {
            student_id: st_id,
            Session: session,
            Term: term,
            Claz: claz,
            AllAttributes: MergedAttributes,
            CTComment: ct_remark,
            PComment: p_remark,
            PresentTimes: p_attendance,
            SchoolOpens: schoolopens,
            Resumption: nexttermbegins,
            ResumptionCheck: ResumptionCheck
        };
        let SaveTheReports = await (0,_API_Call_axioscall__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)("save_all_reports", NewStudentParam);
        if (SaveTheReports === "Saved Successfully") {
            (0,_Notification__WEBPACK_IMPORTED_MODULE_11__/* .DisplayNotification */ .g)("Success", `${Fullname}'s reports have been succesfully saved`, "success", "top-center", 5000);
            setDisplayMainCard(false);
            setshowProcessing(false);
        } else {
            (0,_Notification__WEBPACK_IMPORTED_MODULE_11__/* .DisplayNotification */ .g)("Error", `Error in saving ${Fullname}'s reports. Please contact the administrator`, "danger", "top-center", 5000);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_20___default()), {
        fluid: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_notifications_component__WEBPACK_IMPORTED_MODULE_12__.ReactNotifications, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                MyStyle: {
                    borderRadius: "0px"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                            md: 12,
                            lg: 12,
                            sm: 11,
                            xs: 11,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "text-center h4",
                                children: "REPORTS COMPUTATION"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default()), {
                            onSubmit: GetTheStudents,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                    className: "justify-content-around",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            md: 12,
                                            lg: 12,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                className: "text-center h6",
                                                children: "Please fill in the details of the class you want to work on"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            lg: 4,
                                            md: 4,
                                            sm: 11,
                                            xs: 11,
                                            className: " ",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Session__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                Session: session,
                                                setSession: setsession,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            lg: 4,
                                            md: 4,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Term__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                Term: term,
                                                setTerm: setterm,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            lg: 4,
                                            md: 4,
                                            sm: 11,
                                            xs: 11,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SessionTermClass_Class__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                Claz: claz,
                                                setClaz: setclaz,
                                                Disabled: !activateSelector
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            className: "d-md-none d-lg-none d-sm-block d-xs-block mt-3 mb-1"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                    className: "justify-content-end",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                        lg: 3,
                                        md: 3,
                                        sm: 11,
                                        xs: 11,
                                        className: "mt-2 col-offset-9",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Inputs_ButtonBackground__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            ButtonType: "submit",
                                            ButtonDisable: !activateButton,
                                            ButtonName: "Retrieve Students"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            DisplayCardPanel && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().PanelContainer),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                        md: 3,
                        lg: 3,
                        sm: 11,
                        xs: 11,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Cards_BorderedCardNoHover__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                            MyStyle: {
                                borderRadius: "0px"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().ListHeading),
                                    children: claz.toUpperCase() + " STUDENTS"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_ListGroup__WEBPACK_IMPORTED_MODULE_22___default()), {
                                    as: "ol",
                                    numbered: true,
                                    variant: "flush",
                                    children: AllStudents.map((student, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_ListGroup__WEBPACK_IMPORTED_MODULE_22___default().Item), {
                                            action: true,
                                            onClick: ()=>GetThisStudentReport(student),
                                            as: "li",
                                            children: student.Fullname
                                        }, index))
                                })
                            ]
                        })
                    }),
                    DisplayMainCard && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                        md: 9,
                        lg: 9,
                        sm: 11,
                        xs: 11,
                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().MainCardContainer),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                            className: "justify-content-around",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                md: 11,
                                lg: 11,
                                xs: 11,
                                sm: 11,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                        className: "justify-content-around",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                md: 10,
                                                lg: 10,
                                                xs: 11,
                                                sm: 11,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                    children: [
                                                        StudentDescription("NAME", RetrievedStudentDetails.Fullname, 12),
                                                        StudentDescription("ADMISSION NUMBER", "123456789", 4),
                                                        StudentDescription("DATE OF BIRTH", RetrievedStudentDetails.dob, 4),
                                                        StudentDescription("SEX", RetrievedStudentDetails.sex, 4),
                                                        StudentDescription("SESSION", RetrievedStudentDetails.Session, 4),
                                                        StudentDescription("TERM", RetrievedStudentDetails.Term, 4),
                                                        StudentDescription("CLASS", RetrievedStudentDetails.Claz, 4),
                                                        StudentDescription("NO IN CLASS", RetrievedStudentDetails.nic, 4),
                                                        StudentDescription1("TOTAL ATTENDANCE", 4),
                                                        StudentDescription2("NO OF TIMES PRESENT", 4),
                                                        StudentDescription3("NEXT TERM BEGINS ON", 12)
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                md: 2,
                                                lg: 2,
                                                xs: 6,
                                                sm: 6,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    src: RetrievedStudentDetails.PixUrl === null || RetrievedStudentDetails.PixUrl === "" ? RetrievedStudentDetails.sex === "Male" ? _Images_MaleDummy_jpg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z : _Images_FemaleDummy_jpg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z : RetrievedStudentDetails.PixUrl,
                                                    width: 80,
                                                    height: 80,
                                                    alt: "StudentID"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                        className: "justify-content-around",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            md: 12,
                                            lg: 12,
                                            xs: 12,
                                            sm: 12,
                                            className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().theTableCol),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                responsive: true,
                                                hover: true,
                                                bordered: true,
                                                striped: true,
                                                className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().Tables),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                            className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().rowHead),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().subjectHead)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                    children: "SUBJECTS"
                                                                }),
                                                                RotatedHeading(term, "1ST SUMMARY", "1ST CA SCORES"),
                                                                RotatedHeading(term, "2ND SUMMARY", "2ND CA SCORES"),
                                                                RotatedHeading(term, "3RD SUMMARY", "EXAM SCORES"),
                                                                RotatedHeading(term, "AVERAGE", "TOTAL SCORES"),
                                                                RotatedHeading(term, "MAX. SCORES", "MAX. SCORES"),
                                                                RotatedHeading(term, "MIN. SCORES", "MIN. SCORES"),
                                                                RotatedHeading(term, "AVE. SCORES", "AVE. SCORES"),
                                                                claz.includes("JS") && RotatedHeading(term, "POSITION", "POSITION"),
                                                                RotatedHeading(term, "GRADES", "GRADES"),
                                                                RotatedHeading(term, "REMARKS", "REMARKS")
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                        children: RetrievedSubjects.map((det, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().rowHead),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: `pl-3 ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheSubjects)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td2)}`,
                                                                        children: det.subject_name
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["first_term_total_score"] === null ? "AB" : det["first_term_total_score"] : det[`${term}_term_ca_score1`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["second_term_total_score"] === null ? "AB" : det["second_term_total_score"] : det[`${term}_term_ca_score2`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["third_term_total_score"] === null ? "AB" : det["third_term_total_score"] : det[`${term}_term_exam_score`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["overall_average_score"] == 0 ? "AB" : det["overall_average_score"] : det[`${term}_term_total_score`] == 0 ? "AB" : det[`${term}_term_total_score`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["overall_highest_score"] : det[`${term}_term_highest_score`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["overall_lowest_score"] : det[`${term}_term_lowest_score`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det["general_average_score"] : det[`{term}_term_average_score`]
                                                                    }),
                                                                    claz.includes("JS") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det[`overall_position`] : det[`${term}_term_position`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det[`overall_grade`] : det[`${term}_term_grade`]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().scores_td),
                                                                        children: term === "Third" ? det[`overall_remark`] : det[`${term}_term_remark`]
                                                                    })
                                                                ]
                                                            }, index))
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                                children: "Affective & Psychomotor"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                        md: 4,
                                                        lg: 4,
                                                        sm: 12,
                                                        xs: 12,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                            responsive: true,
                                                            hover: true,
                                                            bordered: true,
                                                            className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().Tables),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "ATTRIBUTES"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "1"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "2"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "3"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "4"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "5"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                    children: RetrievedAttributes1.map((RAtt, index)=>StudentAttributes(1, RAtt, index))
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                        md: 4,
                                                        lg: 4,
                                                        sm: 12,
                                                        xs: 12,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                            responsive: true,
                                                            hover: true,
                                                            bordered: true,
                                                            className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().Tables),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "ATTRIBUTES"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "1"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "2"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "3"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "4"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                children: "5"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                    children: RetrievedAttributes2.map((RAtt, index)=>StudentAttributes(2, RAtt, index))
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                        md: 4,
                                                        lg: 4,
                                                        sm: 12,
                                                        xs: 12,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                                    md: 12,
                                                                    lg: 12,
                                                                    sm: 12,
                                                                    xs: 12,
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                                        responsive: true,
                                                                        hover: true,
                                                                        bordered: true,
                                                                        striped: true,
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().Tables),
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                            className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                            children: "KEYS"
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                            className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                            children: "ATTRIBUTES RATINGS"
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                children: [
                                                                                    InfoTable(5, "Maintains an excellent degree of observa traits"),
                                                                                    InfoTable(4, "Maintains high level of observable traits of observable traits"),
                                                                                    InfoTable(3, "Acceptable level of observable traits"),
                                                                                    InfoTable(2, "Shows minimal regards for observable traits"),
                                                                                    InfoTable(1, "Has no regards for the observable traits")
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                                    md: 12,
                                                                    lg: 12,
                                                                    sm: 12,
                                                                    xs: 12,
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Table__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                                        responsive: true,
                                                                        hover: true,
                                                                        bordered: true,
                                                                        striped: true,
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().Tables),
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        colSpan: "2",
                                                                                        className: `${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().TheAttributes)} ${(_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().BoldTableHeading)}`,
                                                                                        children: "GRADES DISTRIBUTION"
                                                                                    })
                                                                                })
                                                                            }),
                                                                            claz.includes("JS") ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                children: [
                                                                                    InfoTable("70-100", "A"),
                                                                                    InfoTable("60-69", "B"),
                                                                                    InfoTable("50-59", "C"),
                                                                                    InfoTable("40-49", "D"),
                                                                                    InfoTable("0-39", "F")
                                                                                ]
                                                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                children: [
                                                                                    InfoTable("75-100", "A1"),
                                                                                    InfoTable("70-74", "B2"),
                                                                                    InfoTable("65-69", "B3"),
                                                                                    InfoTable("60-64", "C4"),
                                                                                    InfoTable("55-59", "C5"),
                                                                                    InfoTable("50-54", "C6"),
                                                                                    InfoTable("45-49", "D7"),
                                                                                    InfoTable("40-44", "E8"),
                                                                                    InfoTable("0-39", "F9")
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                                children: "Remarks"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Label), {
                                                                style: {
                                                                    display: "inline-block"
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().PlusButton),
                                                                        style: buttonBackground,
                                                                        onClick: ()=>setDisplayCTOptions(!DisplayCTOptions),
                                                                        children: DisplayCTOptions ? "-" : "+"
                                                                    }),
                                                                    "Class Teacher's Comment"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Control), {
                                                                type: "text",
                                                                value: ct_remark,
                                                                onChange: (e)=>setct_remark(e.target.value),
                                                                name: "CT"
                                                            }),
                                                            DisplayCTOptions && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Select), {
                                                                value: sel_ct_remark,
                                                                onChange: (e)=>ChangeCTComment(e.target.value),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        children: " Select a Comment"
                                                                    }),
                                                                    TeachersComments.map((cat, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: `${Firstname} ${cat}`,
                                                                            children: `${Firstname} ${cat}`
                                                                        }, index))
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().ClassTeacherName),
                                                                children: [
                                                                    "CLASS TEACHER'S NAME & PHONE NUMBER: MR OLADIPO A.A | 08033824233",
                                                                    " "
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Label), {
                                                                style: {
                                                                    display: "inline-block"
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                        className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().PlusButton),
                                                                        style: buttonBackground,
                                                                        onClick: ()=>setDisplayPOptions(!DisplayPOptions),
                                                                        children: DisplayPOptions ? "-" : "+"
                                                                    }),
                                                                    "Principal's Comment"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Control), {
                                                                type: "text",
                                                                value: p_remark,
                                                                onChange: (e)=>ChangePComment(e.target.value),
                                                                name: "Principal"
                                                            }),
                                                            DisplayPOptions && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_19___default().Select), {
                                                                value: sel_p_remark,
                                                                onChange: (e)=>ChangePComment(e.target.value),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        children: " Select a Comment"
                                                                    }),
                                                                    PrincipalsComments.map((cat, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: `${Firstname} ${cat}`,
                                                                            children: `${Firstname} ${cat}`
                                                                        }, index))
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Row__WEBPACK_IMPORTED_MODULE_21___default()), {
                                        className: "justify-content-around",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap_Col__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            lg: 12,
                                            md: 12,
                                            xs: 11,
                                            sm: 11,
                                            className: "text-center",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                variant: "success",
                                                style: buttonBackground,
                                                className: (_Compute_Reports_module_css__WEBPACK_IMPORTED_MODULE_18___default().SubmitButton),
                                                onClick: SaveTheReport,
                                                children: "SAVE REPORT"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalsAndAlerts_Processing_Modal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                Show: showProcessing,
                message: Message,
                variant: "success",
                size: "sm"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Compute_Reports);


/***/ }),

/***/ 9201:
/***/ ((module) => {

// Exports
module.exports = {
	"mylabel": "Compute_Reports_mylabel__4LAfE",
	"myvalue": "Compute_Reports_myvalue__bPxR4",
	"myvalueName": "Compute_Reports_myvalueName__KLOHD",
	"Tables": "Compute_Reports_Tables__Yj2hc",
	"RotatedHeading": "Compute_Reports_RotatedHeading__lI9j3",
	"theTableCol": "Compute_Reports_theTableCol__GuDWo",
	"TheSubjects": "Compute_Reports_TheSubjects__bEmEj",
	"TheAttributes": "Compute_Reports_TheAttributes__zOtI_",
	"BoldTableHeading": "Compute_Reports_BoldTableHeading__7MjDz",
	"scores_td": "Compute_Reports_scores_td__UEp_J",
	"scores_td2": "Compute_Reports_scores_td2__B5UR_",
	"InfoTableRight": "Compute_Reports_InfoTableRight__svdCv",
	"InfoTableLeft": "Compute_Reports_InfoTableLeft__7tLiL",
	"PlusButton": "Compute_Reports_PlusButton__FMFza",
	"CommentsGroupHolder": "Compute_Reports_CommentsGroupHolder__8LPtd",
	"ClassTeacherName": "Compute_Reports_ClassTeacherName__GomiY",
	"SubmitButton": "Compute_Reports_SubmitButton__xb6by",
	"ListHeading": "Compute_Reports_ListHeading__Npf69",
	"MainCardContainer": "Compute_Reports_MainCardContainer__vjbG9",
	"PanelContainer": "Compute_Reports_PanelContainer__SRHeH"
};


/***/ }),

/***/ 36277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/Compute_Reports.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\wamp64\www\next-app\components\Compute_Reports.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Compute_Reports = (__default__);
// EXTERNAL MODULE: ./app/api/checkloggedstatus.js
var checkloggedstatus = __webpack_require__(82616);
// EXTERNAL MODULE: ./components/Login_Page.jsx
var Login_Page = __webpack_require__(83236);
;// CONCATENATED MODULE: ./app/computereports/page.js




const ComputeScores = async ()=>{
    const Stat = await (0,checkloggedstatus/* default */.Z)();
    return Stat ? /*#__PURE__*/ jsx_runtime_.jsx(Compute_Reports, {}) : /*#__PURE__*/ jsx_runtime_.jsx(Login_Page/* default */.ZP, {
        Redirection: true
    });
};
/* harmony default export */ const page = (ComputeScores);


/***/ }),

/***/ 40063:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(74937);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4937,4642,1934,7341,1589,4232,8505,8804,5528,541], () => (__webpack_exec__(93686)));
module.exports = __webpack_exports__;

})();