import Login_Page from "@/components/Login_Page";

const LoginPage = async () => {
  return <Login_Page />;
};

export default LoginPage;
