import Login_Page from "@/components/Login_Page";
// import { Container } from "react-bootstrap";

export default function Home() {
  return <Login_Page />;
}
